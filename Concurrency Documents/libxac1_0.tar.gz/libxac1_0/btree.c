/*************************************************************************
 *
 *  B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Bradley C. Kuszmaul
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * btree.c
 *
 */


/* -*- mode: c; c-basic-offset:  4 -*- */

/* A btree.
 * Operations:
 *   insert, delete, search
 *
 * Implementation:  This btree is memory mapped.
 * Parameters:
 *   Block size
 *   Key size (this implementation has a single key size)
 *
 *  Modified using Libxac to support transactional inserts and deletes.
 */
#include <assert.h>
#include <fcntl.h>
#include <limits.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
/* this one is needed on the mac os X, but not on linux.*/
#include <sys/stat.h>
#include <unistd.h>

#include "btree.h"


#include "libxac.h"

int numXactionsAborted = 0;
int reportNumInsertsAborted(void) {
    return numXactionsAborted;
}

#define DO_BACKOFF

enum { BLOCK_SIZE = 4096,
       KEY_SIZE = TEST_KEY_SIZE,
};



typedef unsigned short     KEYNUM;
typedef unsigned short     HEIGHT;

typedef struct padded_key {
  ACTUAL_KEY    actual_key;
    //  char padding  [KEY_SIZE-sizeof(ACTUAL_KEY)];
} PADDED_KEY;

typedef struct page_header {
  KEYNUM n_keys __attribute__ ((packed));
  HEIGHT height __attribute__ ((packed)); /* height==0 iff this page is a leaf. */
} PAGE_HEADER;

enum { BYTES_LEFT_AFTER_HEADER  = BLOCK_SIZE-sizeof(PAGE_HEADER),
       SIZEOF_KEY_VALUE_PAIR    = KEY_SIZE+sizeof(BLOCKNUM),
       KEYS_PER_LEAF_PAGE       = BYTES_LEFT_AFTER_HEADER/SIZEOF_KEY_VALUE_PAIR,
       VALUES_PER_LEAF_PAGE     = KEYS_PER_LEAF_PAGE,
       KEYS_PER_INTERIOR_PAGE   = (BYTES_LEFT_AFTER_HEADER-sizeof(BLOCKNUM))/SIZEOF_KEY_VALUE_PAIR,
       VALUES_PER_INTERIOR_PAGE = KEYS_PER_INTERIOR_PAGE+1,
};
			       
/* for interior pages, the n_keys value is the number of keys.  There is always one more block than key */
struct interior_page {
  PADDED_KEY keys[KEYS_PER_INTERIOR_PAGE] __attribute__((packed));
  BLOCKNUM   blocks[VALUES_PER_INTERIOR_PAGE] __attribute__((packed));
};

struct leaf_page {
  PADDED_KEY keys[KEYS_PER_LEAF_PAGE]  __attribute__((packed));
  BLOCKNUM   blocks[VALUES_PER_LEAF_PAGE]  __attribute__((packed));
};

typedef struct page {
  struct page_header header; //__attribute__((packed));
  union {
    struct interior_page inter; // __attribute__((packed));
    struct leaf_page     leaf; //  __attribute__((packed));
    struct {
	BLOCKNUM next; /* FREELIST_NULL is the end */
    }                    list;
  } u;
} PAGE;

#if 0
int main (int argc __attribute__((__unused__)), const char *argv[] __attribute__((__unused__))) {
  printf("sizeof(interior_page)=%d\n", sizeof(struct interior_page));
  printf("sizeof(leaf_page)    =%d\n", sizeof(struct leaf_page));
  printf("page size = %d\n", sizeof(PAGE));
  assert(KEY_SIZE==sizeof(struct padded_key));
  return 0;
};
#endif

enum { DATABASE_MAGIC = 0xDADABACE }; /* phonetically "database" */
// enum { FREELIST_NULL = ULONG_MAX }; /* problematic with 64-bit machines */
enum { FREELIST_NULL = UINT_MAX };

struct database_header {
  unsigned int       magic;
  BLOCKNUM first_never_alloced; /* the block number of the first page that has never been allocated */
  BLOCKNUM free_list;           /* a freelist linked through the list. */
  HEIGHT   height;
  BLOCKNUM root;
  BLOCKNUM block_number_limit;  /* how many blocks can the enclosing file hold? */
};

struct database {
  int fd;
  struct database_header *h;
};

DATABASE open_db(const char *fname) {
    DATABASE r = malloc(sizeof(*r));
    struct stat buf;
    r->fd = open(fname, O_RDWR);
    assert(r->fd>=0);
    if (fstat(r->fd, &buf)!=0) {
	printf("Cannot stat %s\n", fname);
	exit(1);
    }

    // The normal mmap command.
    //    r->h = mmap(0, (size_t)buf.st_size, PROT_READ|PROT_WRITE, MAP_SHARED, r->fd, (off_t)0);


    // Replace with Libxac commands.
    xInit(LIBXAC_DEFAULT_PATH, TRUE);          // With durability on.
    r->h = xMmap(fname, MAX_PAGES);

    assert(r->h!=MAP_FAILED);
    //madvise(r->h, (size_t)buf.st_size, MADV_RANDOM);
    printf("Padded key is %u bytes, value is %zd bytes\n", KEY_SIZE, sizeof(BLOCKNUM));
    return r;
}

void init_db(DATABASE db) {
    struct stat buf;
    int error = FAILURE;

    while (error != SUCCESS) {
      xbegin();

      if (fstat(db->fd, &buf)!=0) {
	printf("Cannot stat the open db\n");
	exit(1);
      }
      db->h->magic = DATABASE_MAGIC;
      db->h->first_never_alloced = 2;
      db->h->free_list = FREELIST_NULL;
      db->h->height = 0;
      db->h->root = 1;
      db->h->block_number_limit = buf.st_size/BLOCK_SIZE;
      {
	PAGE *p = (PAGE*)(((char*)db->h)+BLOCK_SIZE);
	p->header.n_keys = 0;
	p->header.height = 0;
      }

      error = xend();
    }
}

/* do all the writes now */
void sync_db (struct database *db) {
    printf("%f MB\n", ((double)db->h->first_never_alloced)/(1024*1024/BLOCK_SIZE));
    msync(db->h, db->h->first_never_alloced*BLOCK_SIZE, MS_SYNC);
}
/* schedule all the writes */
void async_db (struct database *db) {
    msync(db->h, db->h->first_never_alloced*BLOCK_SIZE, MS_ASYNC);
}

void close_db (struct database *db) {
    sync_db(db);
    close(db->fd);
}

inline PAGE *blocknum2page (struct database *db, BLOCKNUM b);
inline PAGE *blocknum2page (struct database *db, BLOCKNUM b) {
  return (PAGE*)(((char*)(db->h))+b*BLOCK_SIZE);
}
inline BLOCKNUM page2blocknum (struct database *db, PAGE*p);
inline BLOCKNUM page2blocknum (struct database *db, PAGE*p) {
    return ((char*)p-(char*)db->h)/BLOCK_SIZE;
}

static BLOCKNUM alloc_page (struct database *db) {
  BLOCKNUM  r = db->h->free_list;
  if (r != FREELIST_NULL) {
      PAGE     *p = blocknum2page(db, r);
      db->h->free_list = p->u.list.next;
      return r;
  }
  r = db->h->first_never_alloced;
  if (r<db->h->block_number_limit) {
    db->h->first_never_alloced++;
    return r;
  }
  printf("Ran out of database\n");
  close_db(db);
  exit(1);
}

typedef enum findkind { FIND_EXACT, FIND_BOUND } FINDKIND;

static FINDKIND btree_find_keynum_leaf (PAGE *page, ACTUAL_KEY key, KEYNUM *keynum) {
  KEYNUM i;
  KEYNUM n_keys = page->header.n_keys;
  for (i=0; i<n_keys; i++) {
    ACTUAL_KEY found_key = page->u.leaf.keys[i].actual_key;
    if (found_key==key) {
      *keynum = i;
      return FIND_EXACT;
    } else if (key<found_key) {
      *keynum = i;
      return FIND_BOUND;
    }
  }
  *keynum = i;
  return FIND_BOUND;
}

static KEYNUM btree_find_keynum_interior (PAGE *page, ACTUAL_KEY key) {
  KEYNUM i;
  KEYNUM n_keys = page->header.n_keys;
  for (i=0; i<n_keys; i++) {
    ACTUAL_KEY found_key = page->u.inter.keys[i].actual_key;
    if (key<=found_key) {
      return i;
    }
  }
  return i;
}

int btree_search (struct database *db, ACTUAL_KEY key, BLOCKNUM *stored_value)
     /* return 0 if the value is found.
      * return 1 if no such value
      */
{

  int returnValue;
  int result = FAILURE;

  while (result != SUCCESS) {
    xbegin();
    {
      HEIGHT  height = db->h->height;
      PAGE   *p      = blocknum2page(db, db->h->root);
      xAdvisory(p, TRUE);
      //printf("\n");
      //print_btree (db);
      //printf("Initial height is %d\n", height);
      //printf("Searching for %lld\n", key);
      while (height>0) {
	KEYNUM  keynum = btree_find_keynum_interior(p, key);
	assert(height==p->header.height);
	//printf("Found key# %d\n", keynum);
	//if (p->u.inter.blocks[keynum]>db->h->first_never_alloced) {
	//  printf(" height=%d p->h->height=%d\n", height, p->header.height);
	//	printf(" block %d in tree, but %d is first never alloced\n", p->u.inter.blocks[keynum], db->h->first_never_alloced);
	//	assert(p->u.inter.blocks[keynum]<db->h->first_never_alloced);
	//}
	assert(p->u.inter.blocks[keynum]<db->h->first_never_alloced);
	p = blocknum2page(db, p->u.inter.blocks[keynum]);
	height--;
      }
      {
	KEYNUM keynum;
	switch (btree_find_keynum_leaf(p, key, &keynum)) {
	case FIND_EXACT:
	  *stored_value = p->u.leaf.blocks[keynum];
	  returnValue = 0;
	  break;
	case FIND_BOUND:
	  returnValue = 1;
	  break;
	default:
	  returnValue = 2;
	}         
      }
    }
    result = xend();
  }

  if (returnValue == 2) {
    abort();
  }
  else {
    return returnValue;
  }
}

inline static void move_keys (PADDED_KEY *dest, PADDED_KEY *src, int n) {
  /* move_keys works even if they overlap */
  memmove(dest, src, n*sizeof(*dest));
}
inline static void move_blocks (BLOCKNUM *dest, BLOCKNUM *src, int n) {
  /* move_keys works even if they overlap */
  memmove(dest, src, n*sizeof(*dest));
}

static void __attribute__((__unused__)) dump_node (struct database *db, PAGE *p, int recurse) {
    printf("%*s%u:<%d:", db->h->height-p->header.height, "", page2blocknum(db, p), p->header.height);
    if (p->header.height==0) {
	KEYNUM i;
	for (i=0; i<p->header.n_keys; i++) {
	    printf(" %llu,%u", p->u.leaf.keys[i].actual_key, p->u.leaf.blocks[i]);
	}
	printf(">\n");
    } else {
	KEYNUM i;
	for (i=0; i<p->header.n_keys; i++) {
	    printf(" %llu,%u", p->u.inter.keys[i].actual_key, p->u.inter.blocks[i]);
	}
	printf(" %u", p->u.inter.blocks[i]);
	printf(">\n");
	if (recurse) {
	    for (i=0; i<p->header.n_keys+1; i++) {
		dump_node(db, blocknum2page(db, p->u.inter.blocks[i]), recurse);
	    }
	}
    }
}

static void insert_into_interior (struct database *db, PAGE *stack[], unsigned n_in_stack, ACTUAL_KEY key, BLOCKNUM block) {
    assert(block>0);
    if (0) {
	printf("insert_into_interior([");
	{ unsigned i; for (i=0; i<n_in_stack; i++) {
	    assert(page2blocknum(db,stack[i])>0);
	    printf(" %d", page2blocknum(db,stack[i]));
	}}
	printf("], %llu,%u)\n", key, block);
    }
    while (n_in_stack>0) {
	PAGE *p = stack[n_in_stack-1];
	KEYNUM keynum = btree_find_keynum_interior(p, key);
	//printf("in block %d keynum of %llu is %u\n", ((char*)p-(char*)(db->h))/BLOCK_SIZE, key, keynum);
	//dump_node(db,p);
	if (p->header.n_keys<KEYS_PER_INTERIOR_PAGE) {
	    /* we can simply insert it here. */
	    move_keys  (&p->u.inter.keys[keynum+1],  &p->u.inter.keys[keynum],     p->header.n_keys-keynum);
	    p->u.inter.keys[keynum].actual_key = key;
	    move_blocks(&p->u.inter.blocks[keynum+1],&p->u.inter.blocks[keynum], 1+p->header.n_keys-keynum);
	    p->u.inter.blocks[keynum] = block;
	    p->header.n_keys++;
	    return;
	}
	/* otherwise, we have to split this node, and move up the tree. */
	{
	    BLOCKNUM newblock = alloc_page(db);
	    PAGE    *newp     = blocknum2page(db, newblock);
	    BLOCKNUM   allblocks[VALUES_PER_INTERIOR_PAGE+1];
	    PADDED_KEY allkeys  [KEYS_PER_INTERIOR_PAGE+1];
      
	    enum { half = (KEYS_PER_INTERIOR_PAGE+1)/2 };

	    xAdvisory(newp, FALSE);
	    /* set up a single array holding everying */
	    move_blocks(&allblocks[0], &p->u.inter.blocks[0], keynum);
	    allblocks[keynum] = block;
	    move_blocks(&allblocks[keynum+1], &p->u.inter.blocks[keynum], VALUES_PER_INTERIOR_PAGE-keynum);

	    move_keys(&allkeys[0], &p->u.inter.keys[0], keynum);
	    allkeys[keynum].actual_key = key;
	    move_keys(&allkeys[keynum+1], &p->u.inter.keys[keynum], KEYS_PER_INTERIOR_PAGE-keynum);

	    /* now break it into the two pieces */
	    move_blocks(&newp->u.inter.blocks[0], &allblocks[0], half);
	    move_blocks(&p->u.inter.blocks[0],    &allblocks[half], VALUES_PER_INTERIOR_PAGE+1-half);

	    move_keys  (&newp->u.inter.keys[0],   &allkeys[0],   half-1);
	    // One doesn't get copied, it is used for the parent. */
	    move_keys  (&p->u.inter.keys[0],      &allkeys[half], KEYS_PER_INTERIOR_PAGE+1-half);

	    newp->header.n_keys = half-1;
	    newp->header.height = p->header.height;
	    p->header.n_keys    = KEYS_PER_INTERIOR_PAGE+1-half;

	    //msync(p, BLOCK_SIZE, MS_ASYNC);

	    // Tail call
	    n_in_stack--;
	    key = allkeys[half-1].actual_key;
	    block = newblock;
	}
    }
    /* We got up to the root of the tree, we need to create a node with two children, the old root and the block */
    //printf("Got to root, key=%llu block=%u\n", key, block);
    //dump_node(db,blocknum2page(db,block));
    //dump_node(db,blocknum2page(db,db->h->root));
    {
	BLOCKNUM newblock = alloc_page(db);
	PAGE    *newp = blocknum2page(db, newblock);
	xAdvisory(newp, TRUE);
	newp->header.n_keys = 1;
	newp->header.height = db->h->height+1;
	newp->u.inter.keys[0].actual_key = key;
	newp->u.inter.blocks[0] = block;
	newp->u.inter.blocks[1] = db->h->root;
	db->h->height++;
	db->h->root = newblock;
	//dump_node(db,blocknum2page(db,newblock));
    }
}

static void __attribute__((__unused__)) maybe_swap_out (BLOCKNUM b, void *p) {
    if (b>1000) {
	/* make a circular queue of pages.
	 * When putting something into the queue, schedule its I/O with an aynchronous msync()
	 * When removing something from the queue, make sure its I/O is complete with synchronous msync, and then invalidate it.
	 */
	enum { N_SWAPPING=128 };
	static void* buf[N_SWAPPING];
	int next_out=0; int n_in_buf=0;
	msync(p, BLOCK_SIZE, MS_ASYNC);
	if (n_in_buf==N_SWAPPING) {
	    msync(buf[next_out], BLOCK_SIZE, MS_SYNC | MS_INVALIDATE);
	    next_out = (next_out+1)&(N_SWAPPING-1);
	    n_in_buf--;
	}
	buf[(next_out+n_in_buf)&(N_SWAPPING-1)]=p;
	n_in_buf++;
    }
}

void btree_insert (struct database *db, ACTUAL_KEY key, BLOCKNUM value) {

  int how_many_aborts = 0;
  int status = FAILURE;

#ifdef DO_BACKOFF
  long long loopCount = 1;
#endif
  

  while (status == FAILURE) {
      xbegin();
    
      {
	  PAGE  *stack[db->h->height];
	  HEIGHT n_in_stack=0;
	  HEIGHT height    = db->h->height;
	  BLOCKNUM  b = db->h->root; 
	  PAGE  *p         = blocknum2page(db, b);
	  assert(insideTransaction());
	  xAdvisory(p, TRUE);
	  assert(db->h->root>0);
	  stack[n_in_stack++] = p;
	  while (height>0) {
	      KEYNUM kn = btree_find_keynum_interior(p, key);
	      b = p->u.inter.blocks[kn];
	      //printf("Found block %u in\n", b); dump_node(db, p);
	      p = blocknum2page(db, b);
	      xAdvisory(p, TRUE);
	      assert(b>0);
	      stack[n_in_stack++] = p;
	      height--;
	  }

	  xAdvisory(p, FALSE);
	  n_in_stack--; // Don't need to worry about the top element in the stack.
	  {
	      KEYNUM keynum;
	      switch (btree_find_keynum_leaf(p, key, &keynum)) {
	      case FIND_EXACT:
		  p->u.leaf.blocks[keynum] = value;
		  //if (b>8000) msync(p, BLOCK_SIZE, MS_ASYNC);
		  goto theXend;
	      case FIND_BOUND:
		  if (p->header.n_keys < KEYS_PER_LEAF_PAGE) {
		      move_blocks(&p->u.leaf.blocks[keynum+1], &p->u.leaf.blocks[keynum], p->header.n_keys-keynum);
		      move_keys  (&p->u.leaf.keys  [keynum+1], &p->u.leaf.keys[keynum],   p->header.n_keys-keynum);
		      p->u.leaf.blocks[keynum] = value;
		      p->u.leaf.keys[keynum].actual_key = key;
		      p->header.n_keys++;
		      //maybe_swap_out(b, p);
		      goto theXend;
		  }
		  /* must actually split it. */
		  {
		      BLOCKNUM   newblock = alloc_page(db);
		      PAGE      *newp     = blocknum2page(db, newblock);
		      BLOCKNUM   allblocks[KEYS_PER_LEAF_PAGE+1];
		      PADDED_KEY allkeys  [KEYS_PER_LEAF_PAGE+1];

		      enum { half = (KEYS_PER_LEAF_PAGE+1)/2,	};

		      xAdvisory(newp, FALSE);

		      move_blocks(&allblocks[0], &p->u.leaf.blocks[0], keynum);
		      allblocks[keynum] = value;
		      move_blocks(&allblocks[keynum+1], &p->u.leaf.blocks[keynum], (KEYS_PER_LEAF_PAGE-keynum));
	
		      move_keys(&allkeys[0], &p->u.leaf.keys[0], keynum);
		      allkeys[keynum].actual_key = key;
		      move_keys(&allkeys[keynum+1], &p->u.leaf.keys[keynum], (KEYS_PER_LEAF_PAGE-keynum));

		      /* set up the new pages */
		      move_blocks(&newp->u.leaf.blocks[0], &allblocks[0], half);
		      move_blocks(&p->u.leaf.blocks[0],    &allblocks[half], KEYS_PER_LEAF_PAGE+1-half);

		      move_keys(  &newp->u.leaf.keys[0],   &allkeys[0], half);
		      move_keys(  &p->u.leaf.keys[0],      &allkeys[half], KEYS_PER_LEAF_PAGE+1-half);

		      newp->header.n_keys = half;
		      newp->header.height = p->header.height;
		      p->header.n_keys    = KEYS_PER_LEAF_PAGE+1-half;

		      /* Must insert newp */
		      insert_into_interior(db, stack, n_in_stack, newp->u.leaf.keys[half-1].actual_key, newblock);
		  }
	      }
	  }
      }
  theXend:
      status = xend();
#ifdef DO_BACKOFF
      if (status == FAILURE) {
	  if (how_many_aborts == 0) {
	      numXactionsAborted++;
	  }
	  how_many_aborts++;
	  usleep(loopCount);
	  if (loopCount > 256) {
	      sched_yield();
	  }
	  else {
	      loopCount *= 2;
	  }
	  //	    printf("Loopcount is %d\n", loopCount);
      }
#endif
  }
}
  


static unsigned long btree_range_internal (struct database *db,  BLOCKNUM b, unsigned long *n_leaves) {
    unsigned long result=0;
    result=0;
    PAGE *p = blocknum2page(db, b);
    KEYNUM n_keys = p->header.n_keys;
    int i;
    if (p->header.height>0) {
	for (i=0; i<n_keys+1; i++) {
	    result+=btree_range_internal(db, p->u.inter.blocks[i], n_leaves);
	}
    }
    else {
	for (i=0; i<n_keys; i++) {
	    result+=p->u.leaf.blocks[i];
	}
	(*n_leaves)+=n_keys;
    }

    return result;
}

unsigned long btree_range_query_all_sum (struct database *db, unsigned long *n_leaves) {
    int status = FAILURE;
    unsigned long result = 0;

    *n_leaves = 0;
    while (status != SUCCESS) {
	xbegin();
	result = btree_range_internal(db, db->h->root, n_leaves);
	status = xend();
    }
    return result;
}

static unsigned long verify_btree_node (struct database *db, char *page_map, BLOCKNUM block, unsigned int height, ACTUAL_KEY upper_limit,
					struct btree_pair *pairs, unsigned long n_pairs, unsigned long *next_pair) {
    PAGE *p = blocknum2page(db, block);
    unsigned long result = 0;
    KEYNUM i;
    //printf("%u:<%d:", block, height);
    assert(block<db->h->first_never_alloced);
    assert(p->header.height==height);
    assert(page_map[block]==0);
    page_map[block]=1;
    if (height==0) {
	/* Could have no keys in an any database. */
	assert(p->header.n_keys>0 || db->h->root==block);
	for (i=0; i<p->header.n_keys; i++) {
	    if (pairs) {
		assert(*next_pair < n_pairs);
		//printf(" %llu,%u", p->u.leaf.keys[i].actual_key, p->u.leaf.blocks[i]);
		assert(pairs[*next_pair].k == p->u.leaf.keys[i].actual_key);
		assert(pairs[*next_pair].v == p->u.leaf.blocks[i]);
		(*next_pair)++;
	    }
	    if (i+1<p->header.n_keys) {
		assert(p->u.leaf.keys[i].actual_key <= p->u.leaf.keys[i+1].actual_key);
	    }
	}
	if (p->header.n_keys>0) {
	    assert(p->u.leaf.keys[p->header.n_keys-1].actual_key <= upper_limit);
	}
    } else {
	assert(p->header.n_keys>0);
	for (i=0; i<p->header.n_keys; i++) {
	    if (i+1<p->header.n_keys)
		assert(p->u.inter.keys[i].actual_key <= p->u.inter.keys[i+1].actual_key);
	    result += verify_btree_node(db, page_map, p->u.inter.blocks[i], height-1, p->u.inter.keys[i].actual_key,
					pairs, n_pairs, next_pair);
	}
	assert(p->u.inter.keys[p->header.n_keys-1].actual_key <=upper_limit);
	result += verify_btree_node(db, page_map, p->u.inter.blocks[p->header.n_keys], height-1, upper_limit,
				    pairs, n_pairs, next_pair);
    }
    //printf(">\n");
    return result;
}

// verify many invariants of btrees:
//    every block is either in the freelist or in the btree, and only used once
//    the keys are in order within each node, and within the tree
//    the heights are all consistent
int verify_database (struct database *db, struct btree_pair *pairs, unsigned long n_pairs) {

  int result = FAILURE;

  char *page_map = malloc(db->h->first_never_alloced);
  unsigned long n_nodes;
  unsigned long next_pair=0;

  while (result != SUCCESS) {
    xbegin();
    assert(page_map);  
    assert(db->h->magic==DATABASE_MAGIC);
    { BLOCKNUM i; for(i=0; i<db->h->first_never_alloced; i++) page_map[i]=0; }
    n_nodes = verify_btree_node (db, page_map, db->h->root, db->h->height, 0xFFFFFFFFFFFFFFFFLL, pairs, n_pairs, &next_pair);
    assert(next_pair==n_pairs);
    // Todo:  add every node in the freelist to the page_map
    //        Make sure the page map is all accounted for (every page either in the freelist  or in the tree)
    free(page_map);
    result = xend();
  }
  return n_nodes;
}

void show_database_size (struct database *db) {
    printf("%d pages ever used\n", db->h->first_never_alloced);
}

static void print_btree_node (struct database *db, BLOCKNUM block, HEIGHT height, HEIGHT depth) {
    int i;
    PAGE *p = blocknum2page(db, block);
    if (height==0) {
	printf("%*sLeaf %d:", 2*depth, "", block);
	for (i=0; i<p->header.n_keys; i++) {
	    printf(" (%llu,%u)", p->u.leaf.keys[i].actual_key, p->u.leaf.blocks[i]); 
	}
	printf("\n");
    } else {
	printf("%*sNode %d:\n", 2*depth, "", block);
	for (i=0; i<p->header.n_keys; i++) {
	    print_btree_node(db, p->u.inter.blocks[i], height-1, depth+1);
	    printf("%*s%llu\n", 2*depth+1, "", p->u.inter.keys[i].actual_key);
	}
	print_btree_node(db, p->u.inter.blocks[p->header.n_keys], height-1, depth+1);
    }
}

void print_btree (struct database *db) {
  int result = FAILURE;
  while (result != SUCCESS) {
    xbegin();
    print_btree_node(db, db->h->root, db->h->height, 0);
    result = xend();
  }
}
