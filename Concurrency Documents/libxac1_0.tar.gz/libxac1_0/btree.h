/*************************************************************************
 *
 *  B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Bradley C. Kuszmaul
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * btree.h
 *
 *  B-tree implemented using Libxac
 */

typedef struct database *DATABASE;

typedef unsigned long long ACTUAL_KEY;
typedef unsigned int       BLOCKNUM;     /* 32-bit signed integer for block numbers gives us a 8TB datbase for 4K blocks. */
                                         /* The values stored at the leaves are also block_numbers. */
struct btree_pair { /* used only for testing */
    ACTUAL_KEY k;
    BLOCKNUM   v;
};

DATABASE open_db(const char *string);
void init_db(DATABASE db);
void sync_db (DATABASE db);
void async_db (DATABASE db);
void close_db (DATABASE db);


int btree_search (DATABASE db, ACTUAL_KEY key, BLOCKNUM *stored_value);
void btree_insert (DATABASE db, ACTUAL_KEY key, BLOCKNUM value);
unsigned long btree_range_query_all_sum (struct database *db, unsigned long *n_leaves);
int verify_database (DATABASE db, struct btree_pair *pairs, unsigned long n_pairs);
void show_database_size (struct database *db);
void print_btree (struct database *db);


int reportNumInsertsAborted(void);

// The key size that we are using in our B-tree.
//#define TEST_KEY_SIZE ((size_t)sizeof(ACTUAL_KEY))
#define TEST_KEY_SIZE  ((size_t)512)
