/*************************************************************************
 *
 *  Search tree test code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * btTester.h
 *
 *  Test program performing insertions on multiple processes.
 *  Can be run on three different B-trees:
 *   1. Normal Btree (btree.h, btree.c)
 *   2. COB-tree: (pma_module.h, pma_module.c)
 *       use #define USE_PMA when compiling
 *   3. Berkeley DB B-tree
 *       use #define USE_BDB when compiling
 */

#ifndef __BT_TESTER_H
#define __BT_TESTER_H

#include "basics.h"
#include "commitBuffer.h"
#include "cycle_counter.h"
#include "libxac.h"
#include "utillib.h"

#ifdef USE_BDB
#include <db.h>
#include <sys/stat.h>
#endif


#define COMMENT_STRING  "## "
#define USE_ADVISORY
#define START_EMPTY             
#define BASE_INSERTS 100000

//#define VERIFY_INSERTS


#ifdef NO_CONFLICT_TEST
void performOperation(int myPNum, int numProcs);
#endif


#define INSERTS_PER_XACTION 1
#define K 1
#define MAX_NUM_PROCS 128
#define MAX_NAME_LENGTH 400


typedef struct myArgs {
  char dataFileName[MAX_NAME_LENGTH];
  int n;
  int numProcs;
  int createOutputFile;
  char outputFileName[MAX_NAME_LENGTH];
} expArgs;


void initBtree(expArgs* theArgs);
void doActualInsert(unsigned long r);
void perProcessCleanup(expArgs* theArgs);
void cleanupBtree(expArgs* theArgs);
void doBulkInserts(unsigned long* dataArray, int n);
void verify_inserts(expArgs* theArgs);

#endif
