/*************************************************************************
 *
 *  Cache-oblivious B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004       Massachusetts Institute of Technology
 * Copyright (c) 2004       Zardosht Kasheff
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * veblib.h 
 */



#ifndef __VEBLIB_H
#define __VEBLIB_H

#include <sys/types.h>

size_t ridBits(size_t x, unsigned int i, unsigned int j);
unsigned int hyperceil_int(unsigned int num);

size_t normToBoas(size_t val, unsigned int hght, unsigned int depth);
//val is index in stadard layout starting from 1
//given height h, number of nodes is 2^(h)-1
//root node is 1, not 0
//depth is the depth of val
//root node has depth 1
//height of tree with 16 nodes 4
//depth is a function of val that can be evaluated, but is passed for speed purposes
//depth is something like lg(val)

size_t normToBoasVar(size_t val, unsigned int hght, unsigned int depth, size_t nodeSize, size_t leafSize);
// Similar to normToBoas, except that it tells you where in the file you can find a node if the internal nodes are of size nodeSize and the leaves are of size leafSize

size_t getBoasValue(size_t val, unsigned int hght, unsigned int depth, int* table, unsigned int baseCase);
void setValues(int* table, unsigned int baseCase);


#endif
