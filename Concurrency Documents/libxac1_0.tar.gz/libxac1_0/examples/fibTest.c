/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * fibTest.c
 *
 *  Computes fib. numbers by an iterative method.
 *  Each transaction touches 4 pages.
 *
 */



#include "libxac.h"
#include <assert.h>
#include <stdio.h>
/**
 * Computes the correct value of fib.
 */
static int correctFib(int n) {
  int x = 0;
  int y = 1;

  int count, temp;

  if (n < 1) {
    return n;
  }
  else {
    for (count = 0; count < n; count++) {
      temp = y;
      y = y + x;
      x = temp;
    }

    return x;
  }
}

int main(int argc __attribute__((__unused__)), char* argv[]) {
  int answer;
  int count;
  int* test;
  int a0 = 0;
  //  int a1 = PAGESIZE/4;
  //  int a2 = PAGESIZE/2;
  //  int a3 = 3*PAGESIZE/4;
  int a1 = PAGESIZE/4;
  int a2 = PAGESIZE;
  int a3 = 3*PAGESIZE/2;
  
  int correctAnswer;
  fprintf(stderr, "Running %s ... \n", argv[0]);

  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);

  printf("Returned address of %p for test. \n", test);
  for (count = 0; count < 10; count++) {
    xbegin();

    //          printf("done with coutn 1\n");

    if (count == 0) {
      //      printf("done with coutn 2\n");
      test[a0] = 0;
      //      printf("done with coutn 3\n");
      test[a1] = 1;
      test[a2] = test[a1] + test[a0];
      test[a3] = test[a2] + test[a1];

    }
    else {
      printf("My initial values are: %d %d %d %d\n",
	     test[a0], test[a1], test[a2], test[a3]);
      test[a0] = test[a2] + test[a3];
            printf("My first values are: %d %d %d %d\n",
	     test[a0], test[a1], test[a2], test[a3]);
      test[a1] = test[a3] + test[a0];
            printf("My second values are: %d %d %d %d\n",
	     test[a0], test[a1], test[a2], test[a3]);
      test[a2] = test[a1] + test[a0];
            printf("My third values are: %d %d %d %d\n",
	     test[a0], test[a1], test[a2], test[a3]);
      test[a3] = test[a2] + test[a1];
    }

    printf("After iteration %d:   %d %d %d %d\n",
	   count,
	   test[a0],
	   test[a1],
	   test[a2],
	   test[a3]);
    answer = test[a3];
    xend();
  }

  printf("Final answer:  fib(%d) = %d\n", count*4-1, answer);

  correctAnswer = correctFib(count*4-1);

  reportStatsOnProcess();

  xMunmap(NULL);
  xShutdown();

  if (answer != correctAnswer) {
    printf("%s returned incorrect answer %d.  Answer should be %d\n",
	   argv[0],
	   answer,
	   correctAnswer);
    assert(FALSE);
    return 1;
  }
  else {
    printf("%s is correct.\n", argv[0]);
    return 0;
  }
}
