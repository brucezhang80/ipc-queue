/**
 * nestXactions.c
 *
 *   Creates two processes that increment the same counter.
 */

// Creates two processes that each increment a
//  shared variable MAX/2 times.

#include "../xactionLib.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define DEFAULT 100000




void recursiveIncrement(int* test, int n) {
  int result = FAILURE;

  while (result != SUCCESS) {
    xbegin();
    if (n > 0) {
      test[0]++;
      recursiveIncrement(test, n-1);
    }
    result = xend();
  }
}

int main(int argc, char* argv[]) {

  int answer;
  int count;
  int* test;
  int a0 = 0;
  int value;
  int status;
  int error;

  int numAborts = 0;
  int n = DEFAULT;
  int split;
  int finalAnswer;
  
  fprintf(stderr, "Running %s ... \n", argv[0]);


  if (argc >= 2) {
    n = atoi(argv[1]);
  }
  
  test = (int*)setupXactionSystem(TRUE);

  
  fprintf(stderr, "Running on input size %d\n", n);
  
  error = 1;
  while (error != 0) {
    xbegin();
    test[a0] = 0;
    error = xend();
  }

  
  value = fork();

  
  if (value != 0) {
    split = n/2;
  }
  else {
    split = n - n/2;
  }
  
  recursiveIncrement((int*)test, split);


  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "Interior final value for process %d: %d\n", value, test[a0]);
    answer = test[a0];
    error = xend();
  }
    

  fprintf(stderr, "Final value for process %d: %d\n", getpid(), answer);
  fprintf(stderr, "Process %d aborted %d times. \n", getpid(), numAborts);

  if (value == 0) exit(0);

  if (waitpid(value, &status, 0) == -1) {
    perror("did waitpid, but did not work");
  }

  
  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "\nTotal final value: %d\n", test[a0]);
    finalAnswer = test[a0];
    error = xend();
  }
  
  //    printf("Errno is %d\n", errno);
  //    printf("ECHILD is %d\n", ECHILD);
  //    printf("EINTR is %d\n", EINTR);

  cleanupXactionSystem();

  if (finalAnswer != n) {
    fprintf(stderr, "%s returned Incorrect answer for %s. Answer is %d instead of %d\n",
	    argv[0],
	    finalAnswer,
	    n);
    assert(FALSE);
    return 1;
  }
  else {

    fprintf(stderr, "%s returned CORRECT value of %d.\n", argv[0], finalAnswer);
    return 0;
  }
}



