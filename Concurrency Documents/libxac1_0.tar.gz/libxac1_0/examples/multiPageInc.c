/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * multiPageInc.c
 *
 *   Creates two processes that increment the counters on
 *   multiple pages.
 */


#include "libxac.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define DEFAULT 50000


int main(int argc, char* argv[]) {


  int answer;
  int count;
  int* test;
  int value;
  int status;
  int error;

  int numAborts = 0;


  int a0 = 0; 
  int a1 = PAGESIZE/4;
  int a2 = 2*PAGESIZE/4;
  int a3 = 3*PAGESIZE/4;
  int a4 = 4*PAGESIZE/4;

  int n = DEFAULT;
  int finalAnswer;
  
  fprintf(stderr, "Running %s ... \n", argv[0]);

  if (argc >= 2) {
    n = atoi(argv[1]);
    n = 10*(n/10);
  }

  fprintf(stderr, "Running on input size %d\n", n);
  

  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);

  error = 1;
  while (error != 0) {
    xbegin();
    test[a0] = 0;
    test[a1] = 0;
    test[a2] = 0;
    test[a3] = 0;
    test[a4] = 0;
    error = xend();
  }

  

  fprintf(stderr, "Before the fork... \n");
  value = fork();


  //  xbegin();
  for (count = 0; count < n/10; count++) {

    error = 1;
    while (error != 0) {
      xbegin();
      test[a0]++;
      test[a1]++;
      test[a2]++;
      test[a3]++;
      test[a4]++;
      error = xend();

      if (error != 0) {
	//	fprintf(stderr, "Process %d has aborted %d times. PID is %d\n", value, numAborts, getpid());
	numAborts++;
      }
      //      else {
	//	fprintf(stderr,
	//		"Successful attempt on proc %d at count %d. Keeping aborts at %d\n",
	//		getpid(),
	//		count,
	//		numAborts);
      //      }
    }
  }

  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr,
	    "Interior final values for process %d: %d %d %d %d %d\n",
	    value,
	    test[a0],
	    test[a1],
	    test[a2],
	    test[a3],
	    test[a4]);
    answer = test[a0] + test[a1] + test[a2] + test[a3] + test[a4];
    error = xend();
  }
    
    //  xend();

  fprintf(stderr, "Final value for process %d: %d\n", value, answer);
  fprintf(stderr, "Process %d aborted %d times. \n", value, numAborts);


  if (value != 0) {

    while (wait(&status) == -1) {
    }

    error = 1;
    while (error != 0) {
      xbegin();
      finalAnswer = test[a0] + test[a1] + test[a2] + test[a3] + test[a4];
      fprintf(stderr, "Total final answer is: %d\n", finalAnswer);
      error = xend();
    }


    if (finalAnswer != 10*(n/10)) {
      fprintf(stderr,
	      "%s is INCORRECT. final answer is %d instead of %d\n",
	      argv[0],
	      finalAnswer,
	      10*(n/10));
      assert(FALSE);
    }
    else {
      fprintf(stderr,
	      "%s is CORRECT. Final answer is %d\n",
	      argv[0],
	      finalAnswer);
    }

    xMunmap(NULL);
    xShutdown();
    //    cleanupXactionSystem();
  }
  else {
    xMunmap(NULL);
  }


  return 0;
}

