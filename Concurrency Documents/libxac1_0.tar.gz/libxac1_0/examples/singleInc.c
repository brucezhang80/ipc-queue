/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * singleInc.c
 *   Increments a counter on a single page n times.
 *   This uses only one process.
 */

#include "libxac.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

//#define DEFAULT 100000
#define DEFAULT 1000


int main(int argc, char* argv[]) {

  int answer;
  int count;
  int* test;
  int a0 = 0;
  int error;
  int numAborts = 0;
  int n = DEFAULT;
  

  fprintf(stderr, "Running %s ... \n", argv[0]);

  if (argc >= 2) {
    n = atoi(argv[1]);
  }




  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);


  xbegin();
  test[a0] = 0;
  xend();


  fprintf(stderr, "Running on input size %d\n", n);

  
  for (count = 0; count < n; count++) {
    error = 1;
    while (error != 0) {
      xbegin();
      test[a0]++;
      error = xend();
      if (error != 0) {
	numAborts++;
      }
    }
  }

  error = 1;
  while (error != 0) {
    xbegin();
    //    fprintf(stderr, "Final value for process %d: %d\n", getpid(), test[a0]);
    answer = test[a0];
    error = xend();
  }

  
  fprintf(stderr, "Final value for process %d: %d\n", getpid(), answer);
  fprintf(stderr, "Number of aborts was: %d\n", numAborts);

  reportStatsOnProcess();

  xMunmap(NULL);
  xShutdown();


  if (answer != n) {
    fprintf(stderr,
	    "%s failed. INCORRECT Final value was %d, correct is %d\n",
	    argv[0],
	    answer,
	    n);
    assert(FALSE);
    return 1;
  }
  else {
    fprintf(stderr, "%s returned CORRECT value of %d\n", argv[0], answer);
    return 0;
  }
}



