/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * singleRandFill2.c
 *
 *   Creates two processes that each fill
 *      a random page with numbers, and then computes check sum.
 *   This version should actually have concurrency.  But we don't
 *    call fork.
 */



#include "libxac.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define DEFAULT 1000

#define ENDOFREGION 5*PAGESIZE/4


static int fillPageAndCheckXaction(int* test) {
  int count = 0;
  int answer = 0;
  int check = 0;
  int temp;

  int pageNum = rand() %5;
  int startCount = pageNum*PAGESIZE/4;
  int endCount = startCount + PAGESIZE/4;
  
  xbegin();

  // Fill the array.
  for (count = startCount; count < endCount; count+=4) {
    temp = rand();
    answer += temp;
    test[count] = temp;
  }

  // Check to see that we are correct.
  for (count = startCount; count < endCount; count+=4) {
    temp = test[count];
    check += temp;
  }


  //  fprintf(stderr, "The random sum is %d\n", answer);
  if (check != answer) {
    return FALSE;
  }

  
  check = 0;
  // Check again..
  for (count = startCount; count < endCount; count+=4) {
    temp = test[count];
    check += temp;
  }
  xend();

  return (check == answer);
}




int main(int argc, char* argv[]) {

  int answer;
  int count;
  int* test;

  int error;
  int failed = FALSE;

  //  int numAborts = 0;
  int n = DEFAULT;


/*   int a0 = 0;  */
/*   int a1 = PAGESIZE/4; */
/*   int a2 = 2*PAGESIZE/4; */
/*   int a3 = 3*PAGESIZE/4; */
/*   int a4 = 4*PAGESIZE/4; */


  fprintf(stderr, "Running %s ... \n", argv[0]);
  
  if (argc >= 2) {
    n = atoi(argv[1]);
  }

  fprintf(stderr, "Running on input size %d\n", n);



  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);



  error = 1;

  while (error != 0) {
    
    xbegin();

    for (count = 0; count < 5*PAGESIZE/4; count+=4) {
      test[count] = 0;
    }
    error = xend();
  }

  


  for (count = 0; count < n; count++) {
    answer = fillPageAndCheckXaction(test);
    if (answer == TRUE) {
      //      fprintf(stderr, "Process %d passed trial %d\n", getpid(), count);
    }
    else {
      fprintf(stderr, "Process %d FAILED trial %d\n", getpid(), count);
      failed = TRUE;
    }
  }


  if (failed) {
    fprintf(stderr, "In %s, parent process is wrong.\n", argv[0]);
    assert(FALSE);
  }
  else {
    fprintf(stderr, "Parent process of %s is CORRECT. \n", argv[0]);
  }
  
  //    printf("Errno is %d\n", errno);
  //    printf("ECHILD is %d\n", ECHILD);
  //    printf("EINTR is %d\n", EINTR);

  xMunmap(NULL);
  xShutdown();

  //  printf("Done with this 34. \n");
  return 0;
}

