#include "../xactionLib.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX 1000000



int main(void) {

  int answer;
  int count;
  int* test;
  int a0 = 0;
  int value;
  int status;
  int error;
  int numAborts = 0;

  
  //  int a1 = PAGESIZE/4;
  //  int a2 = PAGESIZE/2;
  //  int a3 = 3*PAGESIZE/4;
  
  fprintf(stderr, "Testing an mmaped version of inc... \n");

  test = (int*)setupXactionSystem(TRUE);


  xbegin();
  test[a0] = 0;

  fprintf(stderr, "Value before the fork is set to %d\n", test[a0]);
  xend();

  fprintf(stderr, "Before the fork... \n");

  value = fork();

  
  error = 1;
  while (error != 0) {
    xbegin();
    for (count = 0; count < MAX/2; count++) {

      test[a0]++;

    }
    error = xend();
    
    if (error != 0) {
      numAborts++;
    }

  }

  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "Interior final value for process %d: %d\n", getpid(), test[a0]);
    answer = test[a0];
    error = xend();
  }

  
  //  xend();

  fprintf(stderr, "Final value for process %d: %d\n", getpid(), answer);
  fprintf(stderr, "Number of aborts for process %d was: %d\n", getpid(), numAborts);

  if (value != 0) {

    //    while (wait(&status) == -1) {
    //    }
    
      printf("Errno is %d\n", errno);
    //    printf("ECHILD is %d\n", ECHILD);
    //    printf("EINTR is %d\n", EINTR);

    cleanupXactionSystem();
  }

  //  printf("Done with this 34. \n");
  return 0;
}



