/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * incQueryTest.c
 *
 *  One process does updates, one does read-only queries.
 */


#include "libxac.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define DEFAULT 1000
//#define DEFAULT 100000


int main(int argc, char* argv[]) {

  int answer;
  int count;
  int* test;
  int a0 = 0;
  int value;
  int status;
  int error;

  int numAborts = 0;
  int n = DEFAULT;
  int finalAnswer;
  int local_val = 0;
  int prev_val = 0;
  int local_sum = 0;
  
  fprintf(stderr, "Running %s ... \n", argv[0]);


  if (argc >= 2) {
    n = atoi(argv[1]);
  }
  

  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);

  fprintf(stderr, "Running on input size %d\n", n);
  
  error = 1;
  while (error != 0) {
    xbegin();
    test[a0] = 0;
    error = xend();
  }

  
  value = fork();

  
  for (count = 0; count < n; count++) {

    error = 1;
    while (error != 0) {

      if (value != 0) {
	xbegin();
	test[a0]++;
	error = xend();
      }
      else {
	xbeginQuery();
	local_val = test[a0];
	local_sum += (local_val != prev_val);
	prev_val = local_val;

	error = xendQuery();
	assert(error == SUCCESS);
      }
      if (count %100 == 0) {
	fprintf(stderr, "Process %d at count %d\n", getpid(), count);
      }
      if (error != 0) {
	//	fprintf(stderr, "Process %d has aborted %d times. PID is %d\n", value, numAborts, getpid());
	numAborts++;
      }
    }
  }
  if (value == 0) {
    printf("The query process observed %d changes\n", local_sum);
  }

  
  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "Interior final value for process %d: %d\n", value, test[a0]);
    answer = test[a0];
    error = xend();
  }
    

  fprintf(stderr, "Final value for process %d: %d\n", getpid(), answer);
  fprintf(stderr, "Process %d aborted %d times. \n", getpid(), numAborts);


  reportStatsOnProcess();
  if (value == 0) {
    xMunmap(NULL);
    exit(0);
  }


  if (waitpid(value, &status, 0) == -1) {
    perror("Error doing waitpid");
  }

  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "\nTotal final value: %d\n", test[a0]);
    finalAnswer = test[a0];
    error = xend();
  }


  xMunmap(NULL);
  xShutdown();
  
  if (finalAnswer != n) {
    fprintf(stderr, "%s returned Incorrect answer for %s. Answer is %d instead of %d\n",
	    argv[0],
	    argv[0],
	    finalAnswer,
	    n);
    assert(FALSE);
    return 1;
  }
  else {

    fprintf(stderr, "%s returned CORRECT value of %d.\n", argv[0], finalAnswer);
    return 0;
  } 
}



