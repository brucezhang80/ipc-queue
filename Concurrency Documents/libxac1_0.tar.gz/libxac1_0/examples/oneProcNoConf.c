/*************************************************************************
 *
 *  Test Examples for Libxac
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * oneProcNoConf.c
 *
 * Running transactions with no conflicts.
 * This is the version of noConfIncTest.c, but running only on one process.
 */

#include "libxac.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>



#define DEFAULT 10000

int main(int argc, char* argv[]) {

  int answer = 0;
  int count;
  int* test;
  int a0 = 0;
  int a1 = PAGESIZE/4;
  int value = 0;
  int error, split;
  int n = DEFAULT;

  int numAborts = 0;

  fprintf(stderr, "Running %s ... \n", argv[0]);


  if (argc > 1) {
    n = atoi(argv[1]);
  }

  printf("here... \n");


  xInit(LIBXAC_DEFAULT_PATH, IS_DURABLE);
  test = (int*)xMmap(NULL, MAX_PAGES);
  fprintf(stderr, "Running on input size %d\n", n);

  
  error = 1;

  while (error != 0) {
    xbegin();
    test[a0] = 0;
    test[a1] = 0;
    fprintf(stderr, "Value before the fork is set to %d\n", test[a0]);
    error = xend();
  }

  fprintf(stderr, "Before the fork... \n");
  //  value = fork();

  split = n;

  
  //  if (value != 0) {
  //    split = n/2;
  //  }
  //  else {
  //    split = n - n/2;
  //  }
  

  for (count = 0; count < split; count++) {
    
    error = 1;
    while (error != 0) {
      xbegin();
      if (value == 0) {
	test[a0]++;
      }
      else {
	test[a1]++;
      }
      error = xend();
      
      if (error != 0) {
       numAborts++;
      }
    }
  }

    

  fprintf(stderr, "Final value for process %d: %d\n", getpid(), answer);
  fprintf(stderr, "Process %d aborted %d times. \n", getpid(), numAborts);


  reportStatsOnProcess();
  //  if (value == 0) exit(0);


  //  if (waitpid(value, &status, 0) == -1) {
  //    perror("Error with waitpid");
  //  }

  
  error = 1;
  while (error != 0) {
    xbegin();
    fprintf(stderr, "Interior final values for process %d: %d and %d\n", getpid(), test[a0], test[a1]);
    answer = test[a0] + test[a1];
    error = xend();
  }



  xMunmap(NULL);
  xShutdown();
  
  if (answer != n) {
    fprintf(stderr, "%s returned Incorrect answer. Answer is %d instead of %d\n",
	    argv[0],
	    answer,
	    n);
    assert(FALSE);
  }
  else {
    fprintf(stderr, "%s returned CORRECT value of %d.\n", argv[0], answer);
  }
  
  return !(answer == n);
}



