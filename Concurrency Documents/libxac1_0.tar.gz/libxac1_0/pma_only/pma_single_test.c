#include <stdio.h>
#include <stdlib.h>
#include "pma_module.h"

int main(int argc, char* argv[]) {
  printf("Executing %s...\n", argv[0]);
  return test_main(argc, argv);
}
