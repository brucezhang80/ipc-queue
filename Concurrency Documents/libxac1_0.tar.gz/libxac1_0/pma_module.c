/*************************************************************************
 *
 *  Cache-oblivious B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004       Zardosht Kasheff
 * Copyright (c) 2004       Bradley C. Kuszmaul
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * pma_module.c
 *
 * 2006:  Jim Sukha 
 *      Modified to use Libxac instead of normal memory mapping.
 *      Also fixed a few bugs with search and insert.     
 */

#include <math.h>
#include <sys/time.h>

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
//#include <popt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>

#include "veblib.h"
#include "utillib.h"

#include "cycle_counter.h"
#include "libxac.h"

#include "pma_module.h"


//General notes
//root node is 1, not 0
//depth indexed at 1
//height of tree with 15 nodes 4


// Jim: I'm not entirely sure what these are.. I think they are
// density threshholds.  But they seem to be constants...
// p0 and pd don't seem to be initialized anywhere...?

static const double t0 = 0.5;
static const double p0;
static const double pd;




// Prototypes foe helper methods...
long long int getValue(cobtree* ctree, node* tree, size_t location, int depth, pair* array, long long int key, size_t* place);
void crunch(pair* array, size_t start, size_t end, size_t* startelt, size_t* endelt);
void deleteArray(cobtree* ctree, pair** array, node** tree);

void deleteKeyRebalance(pair* array, size_t start, size_t end, long long int key);
void rebalance(pair* array, size_t start, size_t end);
double density(pair* array, int start, size_t end);
int insertAtBeginningInSection(pair* array, size_t start, size_t end, long long int key, long long int value);

long long int updateTree(cobtree* ctree, node* tree, size_t indx, size_t boasloc, int depth, pair* arr);
void initArray(cobtree* ctree, pair** array, size_t start, size_t end);
inline void delete(pair* array, int element);


long long int getMaxKeySection(cobtree* ctree, pair* array, size_t section);






/**************************LOG STUFF***********************/

//stuff for getting sectionsize
static double lg(double num) {
  return ((log10(num))/(log10(2.0)));
}

static int getHeight(size_t leaves){
  //int temp;
  int x = 1;
  while(leaves != 0){
    leaves = leaves>>1;
    x++;
  }
  return x-1;
}


//gets power of 2 closest to lg^2(totalArraySize)
static size_t getSectionSize(size_t total){
  double ideal;
  size_t option1, option2;
  double num;
  ideal = lg((double)total);
  //printf("lg: %f\n", ideal);
  


  ideal *= ideal;
  //ideal= 10*ideal;


  //ideal *=2;

  //printf("lg^2: %f\n", ideal);

  num = floor(lg(ideal));
  //printf("num: %f\n", num);
  //db = pow(2.0,num);
  //printf("db: %f\n", db);
  option1 = pow(2.0,num);
  //printf("op1: %d\n", option1);
  option2 = 2*option1;
  //printf("op2: %d\n", option2);
  return ( (option2-ideal) > (ideal - option1) ) ? option1 : option2;
}



/***********************TREE STUFF*******************************/


//tested and works
//indexes start at 1, NOT 0
//sections are indexed at 0, very first section is 0
static inline size_t getSection(cobtree* ctree, size_t indx, int depth){
  int shift = ctree->height-depth;
  indx = indx&((1<<(depth-1)) - 1);
  return indx<<shift;
}

//normal indexing, tested
static inline int isLeaf(cobtree* ctree, size_t indx){
  return ( (indx>>(ctree->height-1)) & 1);
}

//normal indexing, returns Boas index of left child
static inline int leftChild(cobtree* ctree, size_t indx, int depth){
#ifdef TABLE_LOOKUP
  return getBoasValue(indx<<1, (unsigned)ctree->height-1, (unsigned)depth+1,ctree->table, ctree->baseCase);
#else
  return normToBoas(indx<<1, ctree->height-1, depth+1);
#endif
}

//normal indxing, returns Boas index of right child
static inline int rightChild(cobtree* ctree, size_t indx, int depth){
#ifdef TABLE_LOOKUP
  return getBoasValue((indx<<1)+1, (unsigned)ctree->height-1, (unsigned)depth+1,ctree->table, ctree->baseCase);
#else
  return normToBoas((indx<<1)+1, ctree->height-1, depth+1);
#endif
}


inline int empty(pair* array, size_t indx);

//returns -1 if section empty
long long int getMaxKeySection(cobtree* ctree, pair* array, size_t section){
  size_t least;
  size_t curr = (section+1)*ctree->sectionSize;
  least = curr - ctree->sectionSize;
  curr--;
  while(empty(array, curr) && curr>=least) curr--;
  return (curr>=least) ? array[curr].key : -1;
}


long long int updateTree(cobtree* ctree, node* tree,
			 size_t indx, size_t boasloc, int depth, pair* arr){
  long long int left, right;

  //  printf("Updateing tree at depth %d\n", depth);
  if(isLeaf(ctree, indx)) {
    return getMaxKeySection(ctree, arr, getSection(ctree, indx, depth));
  }
  else {
    //if(indx<(1<<10))printf("indx boasloc depth %d %d %d\n", indx, boasloc, depth);
    left = updateTree(ctree, tree, 2*indx, leftChild(ctree, indx,depth), depth+1, arr);
    right = updateTree(ctree, tree, 2*indx+1, rightChild(ctree, indx,depth), depth+1, arr);
    tree[boasloc].val = left;
    //printf("left %d right %d\n",tree[boasloc],right);
    return right;
  }
}


/**************************array stuff that is independent of trees******************/


/*initializing array by setting it to -1 for now*/
void initArray(cobtree* ctree, pair** array, size_t start, size_t end){
  size_t i;
  ctree->pma_size=end*sizeof((*array)[0]);
  for(i=start; i<end; i++){
    (*array)[i].key = -1ll;
    //printf("i %d array[i].key %d\n", i, array[i].key);
  }
}

inline void delete(pair* array, int element){
  array[element].key = -1ll;
  //array[element].value = -1ll;
}

inline int empty(pair* array, size_t indx){
  //if(key >= totalArraySize)printf("key: %d totalArraySize: %d\n", key, totalArraySize);
  return (array[indx].key == -1ll);
}

double density(pair* array, int start, size_t end){
  size_t i;
  size_t count;
  count = 0;

  
  for(i=start; i<end; i++){
    if(!empty(array, i)){
      count++;
    }
  }
  
  /*
  for(i=(start/sectionSize); i<(end/sectionSize); i++){
    count += ctrs[i];
  }
  */
  //printf("count %d, totalArraySize %d\n", count, end-start);
  //printf("%f\n",(count*1.0)/((end-start)*1.0));
  return (count*1.0)/((end-start)*1.0);
}


/*rebalances array for elements from start to end-1*/
void rebalance(pair* array, size_t start, size_t end){
  size_t i;
  size_t lastEmpty;
  size_t numElements;
  size_t capacity;
  double factor;
  size_t currPlace;
  //size_t numSections;
  //short int amt;
  lastEmpty = start;
  /*crunch everything to left*/
  for(i=start; i < end; i++){
    if(!empty(array,i)){
      /*crunch array[i] over to left*/
      array[lastEmpty].key = array[i].key;
      array[lastEmpty].value = array[i].value;
      /*empty or delete array[i]*/
      if(i > lastEmpty) delete(array, i);
      /*increment lastEmpty*/
      lastEmpty++;
    }
  }
  numElements = lastEmpty - start;
  capacity = end - start;
  factor = (double)(capacity*1.0/numElements);
  //printf("numElements: %d\n", numElements);
  //printf("capacity: %d\n", capacity);
  //printf("factor: %f\n", factor);
  /*not doing til i>=0 cause we dont want to delete that element after moving it nowhere*/
  for(i = numElements-1; i > 0; i--){
    /*NEED TO MAKE SURE THIS TAKES AN IMPLICIT FLOOR*/
    currPlace = factor*i;
    if(currPlace != i) {
      //printf("start + i: %d\n", start + i);
      //printf("start + currPlace: %d\n", start + currPlace);
      array[start + currPlace].key = array[start+i].key;
      array[start + currPlace].value = array[start+i].value;
      delete(array, start+i);
    }
  }

  

  /*
  numSections = (end-start)/sectionSize;
  amt = numElements/numSections;
  for(i=(start/sectionSize); i < (end/sectionSize); i++){
    ctrs[i] = amt;
  }
  */

}

/*used for deleting a key in subsection from start to end
  nothing happens if key is not there*/
void deleteKeyRebalance(pair* array, size_t start, size_t end, long long int key){
  size_t i;
  size_t lastEmpty;
  size_t numElements;
  size_t capacity;
  double factor;
  size_t currPlace;
  //size_t numSections;
  //short int amt;
  lastEmpty = start;
  /*crunch everything to left*/
  for(i = start; i < end; i++){
    if(!empty(array,i)){

      /*Deleting code*/
      if(array[i].key == key){
	delete(array, i);
	continue;
      }

      /*crunch array[i] over to left*/
      array[lastEmpty].key = array[i].key;
      array[lastEmpty].value = array[i].value;
      /*empty or delete array[i]*/
      if(i > lastEmpty)delete(array, i);
      /*increment lastEmpty*/
      lastEmpty++;
    }
  }

  //variable contract is for very special case, when contract is 1, I assume
  // start is 0 and end = totalArraySize
  /*
  if(contract) {
    //REALLY HOPING TOTAL IS EVEN...
    array = (pair *)realloc(array, .5*totalArraySize*sizeof(pair));
    totalArraySize *= .5;
  }
  */
  numElements = lastEmpty - start;
  capacity = end - start;


  //if(contract) capacity /= 2;


  factor = (double)(capacity*1.0/numElements);
 
  /*not doing til i>=0 cause we dont want to delete that element after moving it nowhere*/
  for(i = numElements-1; i > 0; i--){
    /*NEED TO MAKE SURE THIS TAKES AN IMPLICIT FLOOR*/
    currPlace = factor*i;
    if(currPlace != i) {
      array[start + currPlace].key = array[start+i].key;
      array[start + currPlace].value = array[start+i].value;
      delete(array, start+i);
    }
  }


  /*
  numSections = (end-start)/sectionSize;
  amt = numElements/numSections;
  for(i=(start/sectionSize); i < (end/sectionSize); i++){
    ctrs[i] = amt;
  }
  */


}


/* Return 1 for unsuccessful insert, -1 for successful insert. */
int insertAtBeginningInSection(pair* array, size_t start, size_t end, long long int key, long long int value){
  size_t i,j;

  i = start;


  //printf("status: i %d start %d end %d\n", i, start, end);

  while(!empty(array, i) && i < end) i++;
  //if true, means unsuccessful insert
  if(i==end) return 1;
  //if(key==TEST)printf("status before loop: i %d start %d end %d\n", i, start, end);

  for(j=i;j>start;j--){
    //printf("status: j %d i %d start %d end %d\n", j, i, start, end);
    array[j].key = array[j-1].key;
    array[j].value = array[j-1].value;
#ifdef COUNT_MOVES    
    numMoves++;
#endif
  }
  array[start].key = key;
  array[start].value = value;
  //means successful insert
  return -1;
}


static double deleteInSectionBinary(pair* array, size_t start, size_t end, long long int key,size_t currSection __attribute__((__unused__))){
  size_t low;
  size_t high;
  size_t leftmid; 
  size_t rightmid;
  double currDens;
  

  //MIGHT HAVE PROBLEMS
  /*
  currDens = (ctrs[currSection]*1.0)/sectionSize;
  */
  currDens = density(array,start,end);
  if(currDens < p0) return currDens;
  

  low = start;
  high = end;
  
  
  while(1){
    leftmid = (low + high)>>1;
    rightmid = leftmid+1;
    if(low == high){
      if(empty(array, low)){
	
	return -1.0;
      
      }
      else if(array[low].key == key){
	array[low].key = -1ll;
	//ctrs[currSection]--;
	return -1.0;
      }
      else{
	return -1.0;
      }
    }
    //what if we are empty to the borders?
    while(empty(array, leftmid) && (leftmid > low))leftmid--;
    while(empty(array, rightmid) && (rightmid < high))rightmid++;
    
    //takes care of case where both ends are empty
    if(empty(array, leftmid) && empty(array, rightmid)){
      return -1.0;
    }
    
    if( (key > array[leftmid].key) && (key < array[rightmid].key)){
      //if(key == TESTVAL) printf("should be fine.... leftmid: %lld rightmid: %lld\n",leftmid, rightmid);
      //this is if there is empty space between the two
      return -1.0;
    }
    
    else if(key < array[leftmid].key){
      high = leftmid;
      //if(key == TESTVAL) printf("high: %lld\n", high);
    }
    //gets little hairy if high is empty it MIGHT work just because emptiness is
	//key being -1 and all our keys are positive for now
    else if(key > array[rightmid].key){
      low = rightmid;
    }
    else if(key == array[leftmid].key) {
      array[leftmid].key = -1ll;
      return -1.0;
    }
    else if(key == array[rightmid].key){
      array[rightmid].key = -1ll;
      return -1.0;
    }  
  }
  

}


static int insertBetween(pair* array, size_t a, size_t b, size_t start, size_t end, long long int key, long long int value);
static int insertAtEndInSection(pair* array, size_t start, size_t end, long long int key, long long int value);

static
int insertInSectionBinaryBetter(pair* array, size_t start, size_t end, long long int key, long long int value,
				size_t* leftelt, size_t* rightelt){
  int val;
  size_t low;
  size_t high;
  size_t leftmid; 
  size_t rightmid;
  //is high supposed to be end-1
  low = start;
  high = end-1;
  while(1){
    //    printf("Start of loop: low = %zd, high = %zd\n", low, high);
    leftmid = (low + high)>>1;
    rightmid = leftmid+1;
    if(low == high){
      //SPECIAL INSERTION CODE
      if(empty(array, low)){
	array[low].key = key;
	array[low].value = value;
	//	printf("Storing key = %llu at low = %zd\n", key, low);
#ifdef COUNT_MOVES	
	numMoves++;
#endif
	return -1;
      }
      else if(array[low].key >= key){
	if(low == end-1){
	  *leftelt=end-1;
	  *rightelt=end;
	  return insertAtEndInSection(array, start, end-1, key, value);
	}
	else if (low == start){
	  *leftelt = start;
	  *rightelt = start;
	  return insertAtBeginningInSection(array, start, end, key, value);
	}
	else {
	  *leftelt = low;
	  *rightelt = low+1;
	  return insertBetween(array, low, low+1, start, end, key, value);
	}
      }
      else{
	if(low == start){
	  *leftelt = start;
	  *rightelt = start;
	  return insertAtBeginningInSection(array, start, end, key, value);
	}	
	else if(low == end-1){ 
	  *leftelt=end-1;
	  *rightelt=end;
	  return insertAtEndInSection(array, start, end-1, key, value);
	}	
	else{
	  *leftelt = low-1;
	  *rightelt = low;
	  return insertBetween(array, low-1, low, start, end, key, value);
	}
      }
    }
    //what if we are empty to the borders?
    while(empty(array, leftmid) && (leftmid > low))leftmid--;
    while(empty(array, rightmid) && (rightmid < high))rightmid++;

    //takes care of case where both ends are empty
    if(empty(array, leftmid) && empty(array, rightmid)){
      //printf("EMPTY!!!!!!!!!!!!");

      //      printf("Storing key when both ends are empty... key = %llu at low = %zd\n", key, (leftmid + rightmid + 1)>>1);
      array[(leftmid + rightmid + 1)>>1].key = key;
      array[(leftmid + rightmid + 1)>>1].value = value;
    }

    if( (key >= array[leftmid].key) && (key <= array[rightmid].key)){
      if((leftmid +1) != rightmid){
	array[(leftmid + rightmid + 1)>>1].key = key;
	array[(leftmid + rightmid + 1)>>1].value = value;
#ifdef COUNT_MOVES    
	numMoves++;
#endif
	return -1;
      }
      else{
	*leftelt = leftmid;
	*rightelt = rightmid;
	val = insertBetween(array, leftmid, rightmid, start, end, key, value);
	return val;
      }
    }

    else if(key <= array[leftmid].key){
      high = leftmid;
    }
    //gets little hairy if high is empty it MIGHT work just because emptiness is
    //key being -1 and all our keys are positive for now
    else if(key >= array[rightmid].key){
      low = rightmid;
    }
  }
}


static int insertAtEndInSection(pair* array, size_t start, size_t end, long long int key, long long int value){
  size_t i,j;
  i = end;
  //printf("status: i %d start %d end %d\n", i, start, end);
  

  //THIS CAN SCREW THINGS UP!!!!
  //not sure if start is inclusive or not, i believe it is inclusive, but so is end here
  //whereas in all other functions, end is exclusive
  while((!empty(array, i)) && (i > start)) {
    i--;
  }
  
  //printf("i: %d start: %d  %lld\n",i,start, array[start].key);
  //printf("empty... %d %d\n", (!empty(array,start)), (i==start));
  if((i==start) && (!empty(array,start)) ) {
        return 1;
  }


  //if(key==TEST)printf("status before loop: i %d start %d end %d\n", i, start, end);

  for(j=i;j<end;j++){
    array[j].key = array[j+1].key;
    array[j].value = array[j+1].value;
#ifdef COUNT_MOVES    
    numMoves++;
#endif
  }

  array[end].key = key;
  array[end].value = value;
  return -1;

}


static int insertBetween(pair* array, size_t a, size_t b, size_t start, size_t end, long long int key, long long int value){
  int x;
  x = insertAtBeginningInSection(array, b, end, key, value);
  if(x==-1) return x;
  else return insertAtEndInSection(array, start, a, key, value);
 
}

static void sync_all (void) {
#if DO_SYNC
    struct timeval tv0,tv1,tv2;
    gettimeofday(&tv0, 0);
    msync(mmap_start, mmap_size, MS_ASYNC);
    gettimeofday(&tv1, 0);
    fdatasync(mmap_fd);
    gettimeofday(&tv2, 0);
#if 0
    printf("Synced (%.6fs) + (%.6fs)\n",
	   tv1.tv_sec-tv0.tv_sec+(tv1.tv_usec-tv0.tv_usec)*1e-6,
	   tv2.tv_sec-tv1.tv_sec+(tv2.tv_usec-tv1.tv_usec)*1e-6);
#endif
#endif /*DO_SYNC*/
}

/**************************array stuff that is independent of trees******************/



/**************************new attempt at rebalancing*******************************/

static int insertRedistribution(pair* array, size_t start, size_t end, 
			 size_t startelt, size_t endelt,
			 size_t leftelt, size_t rightelt,
			 long long int key, long long int value){
  
  size_t readIndex, writeIndex;
  size_t secondRead, secondWrite;
  size_t first, second;
  double factor;
  readIndex = startelt;
  writeIndex = start;

  factor = (double)((end-start)*1.0/(endelt - startelt+1)); 
  //  printf("readIndex: %zd writeIndex %zd factor %f\n", readIndex, writeIndex, factor);
 
  //currPlace = factor*i;




  while((readIndex > writeIndex) && (readIndex < end)){

    //    printf("read index %zd, writeindex %zd\n", readIndex, writeIndex);

    //write the value
    array[writeIndex].key = array[readIndex].key;
    array[writeIndex].value = array[readIndex].value;

    // Jim:  I added this if clause here.  Otherwise, we clobber the
    //  element that "moves"
    if (readIndex != writeIndex) {
      array[readIndex].key = -1ll;
      array[readIndex].value = -1ll;
    }


    
    //update values
    readIndex++;
    writeIndex = (factor*(readIndex-startelt)) + start;

    //printf("readIndex: %d write %d\n", readIndex, writeIndex);

  }

  secondWrite = factor*(endelt-startelt) + start;
  secondRead = endelt;
  //printf("secondRead: %d secondWrite %d\n", secondRead, secondWrite);
  
  while((secondRead >= readIndex) && (secondRead > 0)){
    //write the value
    array[secondWrite].key = array[secondRead].key;
    array[secondWrite].value = array[secondRead].value;

    // Jim: Same thing here...
    if (secondRead != secondWrite) {
      array[secondRead].key = -1ll;
      array[secondRead].value = -1ll;
    }

    //update values
    secondRead--;
    secondWrite = (factor*(secondRead-startelt)) + start;    
  }

  //printf("end-start=%lu total=%lu\n", (unsigned long)(end-start), (unsigned long) totalArraySize);
  sync_all();
  //msync(array+(start/4096)*4096, ((end-start+4095)/4096)*4096, MS_ASYNC);

  //TIME TO INSERT ELEMENT
  first = factor*(leftelt-startelt) + start;
  second = factor*(rightelt-startelt) + start;
  
  if (first+1 < second){
    array[(first+second)>>1].key = key;
    array[(first+second)>>1].value = value;
    return -1;
  }
  

  //WATCH OUT WITH THIS, MAKE SURE IF AT BEGINNING OF SECTION, 
  //start is second, if at end, end-1 is first...
  
  //THIS WILL NEED SOME HELP
  else if (second == start) return insertAtBeginningInSection(array, start, end, key, value);
  else if(first == end-1) return insertAtEndInSection(array, start, end-1, key, value);
  else return insertBetween(array, first,second, start, end, key, value);
}


//endelt is INCLUSIVE, startelt til endelt INCLUSIVE are where rest of crunched stuff
//is
void crunch(pair* array, size_t start, size_t end, size_t* startelt, size_t* endelt){
  size_t i;
  size_t lastEmpty;

  //case we move stuff in right direction
  if(end <= *startelt){
    lastEmpty = *startelt-1;
    /*crunch everything to left*/
    for(i=end-1; i >= start; i--){
      if(!empty(array,i)){
	/*crunch array[i] over to left*/
	if(i != lastEmpty){ 
	  array[lastEmpty].key = array[i].key;
	  array[lastEmpty].value = array[i].value;
	  /*empty or delete array[i]*/
	  delete(array, i);
	}
	/*increment lastEmpty*/
	lastEmpty--;
	if(i==0) break;
      }
      //if (0==((unsigned long)(&array[i]))%(4096*64)) msync(&array[i], (end-i)*sizeof(pair), MS_ASYNC);
    }
    *startelt = lastEmpty+1;
  }
  //case we move stuff in left direction
  else{
    lastEmpty = *endelt+1;
    /*crunch everything to left*/
    for(i=start; i < end; i++){
      if(!empty(array,i)){
	/*crunch array[i] over to left*/
	if(i!= lastEmpty){
	  array[lastEmpty].key = array[i].key;
	  array[lastEmpty].value = array[i].value;
	  /*empty or delete array[i]*/
	  delete(array, i);
	}
	/*increment lastEmpty*/
	lastEmpty++;
      }
    }
    *endelt = lastEmpty-1;
  }
}


/**************************end of new attempt at rebalancing*******************************/

void pma_print_array(cobtree* ctree) {

  int status = FAILURE;
  size_t i;

  while (status != SUCCESS) {
    xbegin();
  printf("PMA: Array size is %zd\n", ctree->totalArraySize);
  for (i = 0; i < ctree->totalArraySize; i++) {
    if (empty(ctree->array, i)) {
      printf("- ");
    }
    else {
      printf("(%zd, %lld, %lld) ", i, ctree->array[i].key, ctree->array[i].value);    
    }
  }
  printf("\n");
  status = xend();
  }
}

static void pma_print_tree_helper(cobtree* ctree, int indx, size_t boasloc, int depth) {

  // boasloc is the actual place where the child is..
  printf("Current value at index %d, boas loc %zd,  is %llu\n", indx, boasloc, ctree->tree[boasloc].val);
  if (!isLeaf(ctree, indx)) {

    printf("left:\n");
    pma_print_tree_helper(ctree, 2*indx, leftChild(ctree, 2*indx, depth+1), depth+1);

    printf("right:\n");
    pma_print_tree_helper(ctree, 2*indx+1, rightChild(ctree, 2*indx+1, depth+1), depth+1);        
  }
}

void pma_print_tree(cobtree* ctree) {  
  pma_print_tree_helper(ctree, 1, 0, 1);
}



//THIS NEEDS TO BE TESTED
//returns 1 if sectionSize changes, 0 otherwise
static int increaseArray(cobtree* ctree, pair** array, node** tree){
  size_t temp;
  //  printf("trying to increase array\n");

#ifdef MMAPPING
  
#else
  *array = (pair *)realloc(*array, (2*ctree->totalArraySize)*sizeof(pair));
#endif
  initArray(ctree, array, ctree->totalArraySize, 2*ctree->totalArraySize);

  ctree->totalArraySize *= 2;
  temp = ctree->sectionSize;
  ctree->sectionSize = getSectionSize(ctree->totalArraySize);

#ifdef MMAPPING
  //  printf("Old tree.. something new? %p\n", *tree);
  *tree = (node *)((*array) + ctree->totalArraySize);
  //  printf("Chaning tree to be something new? %p\n", *tree);
  //ctrs = (short int *)((*tree) + (ctree->totalArraySize/sectionSize) );
#endif

  if(temp != ctree->sectionSize){
    //this means sectionSize has doubled and memory
    //of tree is fine
    //printf("tree same\n");
    return 1;
  }
  else{
    //this means tree has added another layer of height
    ctree->height++;
    //need to double tree size


#ifdef MMAPPING
#else
    *tree = (node *)realloc(*tree, ( (1<<(ctree->height-1)) - 1) * sizeof(node));
    //ctrs = (short int *)realloc(ctrs, ((ctree->totalArraySize/sectionSize) * sizeof(short int) ));
#endif
    return 0;
  }
}



void deleteArray(cobtree* ctree, pair** array, node** tree){
  size_t temp;
  //printf("trying to increase array\n");


#ifdef MMAPPING
  
#else
  *array = (pair *)realloc(*array, (.5*ctree->totalArraySize)*sizeof(pair));
#endif
  //initArray(array, ctree->totalArraySize, .5*ctree->totalArraySize);

  ctree->totalArraySize *= .5;
  temp = ctree->sectionSize;
  ctree->sectionSize = getSectionSize(ctree->totalArraySize);

#ifdef MMAPPING
  *tree = (node *)((*array) + ctree->totalArraySize);
  //ctrs = (short int *)((*tree) + (ctree->totalArraySize/ctree->sectionSize) );
#endif

  if(temp != ctree->sectionSize){
    //this means sectionSize is half of before, memory
    //of tree is fine
    //printf("tree same\n");
  }
  else{
    //this means tree has added another layer of height
    ctree->height--;
    //need to double tree size


#ifdef MMAPPING
#else
    *tree = (node *)realloc(*tree, ( (1<<(ctree->height-1)) - 1) * sizeof(node));
    //ctrs = (short int *)realloc(ctrs, ((ctree->totalArraySize/sectionSize) * sizeof(short int) ));
#endif
  }
}

//root node is 1, not 0
//depth indexed at 1
//height of tree with 15 nodes 4
//depth manipulations will need debugging, need another wrapper for top level case where need to rebalance all
static
double insertBetter(cobtree* ctree,
		    node* tree, pair* array,
		    size_t element, long long int key, long long int value, int depth, 
		    size_t* startelt, size_t* endelt, size_t *leftelt, size_t *rightelt){
  long long int currKey;
  size_t currSection;
  size_t size;
  double currThreshold;
  double success, currDens;
  double x;

  int currLoc;
#ifdef TABLE_LOOKUP
  currLoc = getBoasValue(element, ctree->height-1, depth, ctree->table, ctree->baseCase);
#else
  currLoc = normToBoas(element, ctree->height-1, depth);
#endif
  currKey = tree[currLoc].val;
  //if(key==TEST)printf("currKey is %d key is %d\n", currKey, key);
  currSection = getSection(ctree, element, depth);

  //  printf("currSection here is %zd\n", currSection);
  if(isLeaf(ctree, element)){
    size = ctree->sectionSize;
    currThreshold = 1;
    //MAKE THIS BETTER
    *startelt = currSection*size;
    *endelt = (currSection+1)*size - 1;
    //    printf("size was %zd\n", ctree->sectionSize);
    //    printf("Startelt is %zd, endelt is %zd\n", *startelt, *endelt);
    x = insertInSectionBinaryBetter(array, *startelt, *endelt+1, key, value, leftelt, rightelt);
    //    printf("Insert in section binary now... start is %zd, end is %zd\n", *startelt, *endelt);
    return x;
  }
  //pass along to right subtree
  else if(key > currKey){
    //    printf("Pass along to right subtree..., depth is %d\n", depth);
    success = insertBetter(ctree, tree, array, 2*element+1, key, value, depth+1, startelt, endelt, leftelt, rightelt);
    if(success == -1.0){
      return -1.0;
    }
    else{
      //GOTTA TRY AGAIN...
      currThreshold = 1 - (t0)*((ctree->height-depth)*1.0)/((ctree->height-1)*1.0);
      size = ctree->sectionSize*( 1 << ((ctree->height-depth)-1) );
      
      crunch(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+size, startelt, endelt);

      /*
      currDens = density(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+size);
      currDens = (currDens + success)/2.0;
      */

      currDens = (1.0*(*endelt - *startelt +1))/(2*size);

      if(currDens < currThreshold){

	//insertKeyRebalance(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), key, value);
	insertRedistribution(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), 
			     *startelt, *endelt, 
			     *leftelt, *rightelt,
			     key, value);

	updateTree(ctree, tree, element, currLoc, depth, array);

	//INTERVAL COUNTING
#ifdef COUNT_INTERVALS
	intervalCount += 2*size;
#endif


	return -1;
      }
      else{
	return currDens;
      }
    }
  }


  //pass along to left subtree
  else{
    //    printf("Pass along to left subtree..., depth is %d\n", depth);
    success = insertBetter(ctree, tree, array, 2*element, key, value, depth+1, startelt, endelt, leftelt, rightelt);
    if(success == -1.0){
      return -1.0;
    }
    else{
      currThreshold = 1 - (t0)*((ctree->height-depth)*1.0)/((ctree->height-1)*1.0);
      size = ctree->sectionSize*(1<<(ctree->height-depth-1));
 
      crunch(array, (currSection*ctree->sectionSize)+size, (currSection*ctree->sectionSize)+(2*size), startelt, endelt);

      
      /*
      currDens = density(array, (currSection*ctree->sectionSize)+size, (currSection*ctree->sectionSize)+(2*size));
      currDens = (currDens + success)/2.0;
      */
      currDens = (1.0*(*endelt - *startelt +1))/(2*size);


      if(currDens < currThreshold){
	//insertKeyRebalance(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), key, value);
	insertRedistribution(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), 
			     *startelt, *endelt, 
			     *leftelt, *rightelt,
			     key, value);

	updateTree(ctree, tree, element, currLoc, depth, array);

	//INTERVAL COUNTING
#ifdef COUNT_INTERVALS
	intervalCount += 2*size;
#endif



	return -1.0;
      }
      else{
	return currDens;
      }
    }
  }
}

static void ins(cobtree* ctree, node** tree, pair** array, long long int key, long long int value){
  double success;
  int increase;
  size_t startelt, endelt, leftelt, rightelt;
  //if(key == TESTVAL) printf("***************gonna insert\n");


  //element and depth are both 1 to start
  //if(key==TEST)printf("in ins\n");


  success = insertBetter(ctree, *tree, *array, 1, key, value, 1, &startelt, &endelt, &leftelt, &rightelt);

  if(success != -1.0){


/*     printf("WE HERE?\n"); */
/*     printf("attempting to increase array\n"); */
    increase = increaseArray(ctree, array, tree);
    //    printf("done increasing array\n");
    



    //insertKeyRebalance(*array,0,ctree->totalArraySize,key,value);



/*     printf("------------------\n"); */
/*     printf("Just finished before ins redist.... pma looks like...\n"); */
/*     pma_print_array(ctree); */
/*     printf("------------------\n"); */

/*     printf("Performing insert redistribution.\n");    */
    insertRedistribution(*array, 0, ctree->totalArraySize, 
			 startelt, endelt, 
			 leftelt, rightelt,
			 key, value);


    //    printf("------------------\n");
    //    printf("Just after ins redist.... pma looks like...\n");
    //    pma_print_array(ctree);
    //
    printf("------------------\n");

/*     pma_print_array(ctree); */
/*     printf("1......................\n"); */

    //for(increase = 0; increase < ctree->totalArraySize; increase++){
    //  printf("%lld ", (*array)[increase].key);
    //}
    //printf("\n");
    //abort();

    //if(TEST == key)printf("ctree->totalArraySize now %d\n", ctree->totalArraySize);
    //for(i=0;i<ctree->totalArraySize;i++){
    //if(key==TEST)printf("%d ", (*array)[i].key);
    //}
    //if(key==TEST)printf("\n");
    
    updateTree(ctree, *tree, 1, 0, 1, *array);
    
    //in height or not
  }
}



static double deleteElement(cobtree* ctree, node* tree, pair* array, size_t element, long long int key, int depth){
  long long int currKey;
  size_t currSection;
  size_t size;
  double currThreshold;
  double success, currDens;
  double x;

  int currLoc;
#ifdef TABLE_LOOKUP
  currLoc = getBoasValue(element, ctree->height-1, depth, ctree->table, ctree->baseCase);
#else
  currLoc = normToBoas(element, ctree->height-1, depth);
#endif
  currKey = tree[currLoc].val;
  //if(key==TEST)printf("currKey is %d key is %d\n", currKey, key);
  currSection = getSection(ctree, element, depth);


  if(isLeaf(ctree, element)){

    size = ctree->sectionSize;
    currThreshold = pd;

    //NEED TO CHANGE THIS
    x = deleteInSectionBinary(array, currSection*size, (currSection+1)*size, key,  currSection);
    
    
    return x;
  }

  
  //pass along to right subtree
  else if(key > currKey){
    success = deleteElement(ctree, tree, array, 2*element+1, key, depth+1);
    if(success == -1.0){
      return success;
    }
    else{
      //GOTTA TRY AGAIN...
      currThreshold = pd + (p0)*((ctree->height-depth)*1.0)/((ctree->height-1)*1.0);
      //printf("depth %d height %d currThreshold %f\n", depth, height, currThreshold);
      //old size was size of what node represented, instead, will now make it 
      //half of what node represents, because we got other half of density in the recursive call and no need
      //to do that calculation again
      size = ctree->sectionSize*( 1 << ((ctree->height-depth)-1) );
      //we got density of right subtree, now will get left and average the two
      currDens = density(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+size);
      currDens = (currDens + success)/2.0;
      if(currDens > currThreshold){
	//insertKeyRebalance(array, currSection*size, (currSection+1)*size, key, value);
	deleteKeyRebalance(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), key);
	//MEANS WE DELETED!!
	updateTree(ctree, tree, element, currLoc, depth, array);
	//if(TEST == key)printf("inserted at depth %d ctree->height %d\n", depth, ctree->height);
	



	//INTERVAL COUNTING
#ifdef COUNT_INTERVALS
	intervalCount += 2*size;
#endif


	return -1.0;
      }
      else{
	//means we are not successful, we return failing density
	//printf("failed inserting, currDens, currThreshold %f %f\n",currDens,currThreshold);
	return currDens;
      }
    }
  }


  //pass along to left subtree
  else{
    success = deleteElement(ctree, tree, array, 2*element, key, depth+1);
    if(success == -1.0){
      return success;
    }
    else{
      //GOTTA TRY AGAIN...
      currThreshold = pd - (p0)*((ctree->height-depth)*1.0)/((ctree->height-1)*1.0);
      //printf("depth %d ctree->height %d currThreshold %f\n", depth, ctree->height, currThreshold);
      //old size was size of what node represented, instead, will now make it 
      //half of what node represents, because we got other half of density in the recursive call and no need
      //to do that calculation again
      
      //size = ctree->sectionSize*(1<<(ctree->height-depth+1));
      //currDens = density(array, currSection*size, (currSection+1)*size);

      size = ctree->sectionSize*(1<<(ctree->height-depth-1));
      //we got density of left subtree, now will get right and average the two


      currDens = density(array, (currSection*ctree->sectionSize)+size, (currSection*ctree->sectionSize)+(2*size));
      currDens = (currDens + success)/2.0;
      if(currDens > currThreshold){
	deleteKeyRebalance(array, currSection*ctree->sectionSize, (currSection*ctree->sectionSize)+(2*size), key);
	updateTree(ctree, tree, element, currLoc, depth, array);
	//MEANS WE INSERTED!!
	//if(TEST == key)printf("inserted at depth %d ctree->height %d\n", depth, ctree->height);


	//INTERVAL COUNTING
#ifdef COUNT_INTERVALS
	intervalCount += 2*size;
#endif



	return -1.0;
      }
      else{
	//means we are returning from a leaf
	//printf("failed inserting, currDens, currThreshold %f %f\n",currDens,currThreshold);
	return currDens;
      }
    }
  }
}

long long int getValue(cobtree* ctree,
		       node* tree, size_t location, int depth, pair* array, long long int key, size_t* place){
  size_t boasLoc;
  size_t section;
  size_t low, high, leftmid, rightmid;
#ifdef TABLE_LOOKUP
  boasLoc = getBoasValue(location, ctree->height-1, depth,ctree->table,ctree->baseCase);
#else
  boasLoc = normToBoas(location, ctree->height-1, depth);
#endif
  while(1){
    if(isLeaf(ctree, location)){
      section = getSection(ctree, location,depth);
      low = section*ctree->sectionSize;
      high = (section+1)*ctree->sectionSize - 1;

     /*  { */
/* 	size_t j; */
/* 	printf("getValue at location %zd, searching for key %llu\n", */
/* 	       location, key); */
/* 	printf("low is %zd, high is %zd\n", low, high); */
/* 	for (j = low; j <= high; j++) { */

/* 	  if (empty(ctree->array, j)) { */
/* 	    printf("- "); */
/* 	  } */
/* 	  else { */
/* 	    printf("(%zd, %lld, %lld) ", j, ctree->array[j].key, ctree->array[j].value);     */
/* 	  }	   */
/* 	} */
/* 	printf("\n"); */
/*       } */

	     
      while(1){	

	// Move low and high inward, until they are equal or until we
	//  hit a non-blank.
	while(empty(array, low) && (low < high)) low++;
	while(empty(array, high) && (high > low)) high--;


	leftmid = (low + high)>>1;
	rightmid = leftmid+1;
	if(low == high){
	  if(empty(array, low)){
	    *place = low;
	    //	    printf("Low is %zd\n", low);
	    //	    printf("Not found 1\n");
	    goto not_found;
	    //	    return -1ll;
	  }
	  else if(array[low].key == key){
	    *place = low;
	    return array[low].value;
	  }
	  else{
	    *place = low;
	    //	    printf("Not found 2\n");
	    goto not_found;
	    //	    return -1ll;
	  }
	}
	//what if we are empty to the borders?
	while(empty(array, leftmid) && (leftmid > low))leftmid--;
	while(empty(array, rightmid) && (rightmid < high))rightmid++;
	
	//takes care of case where both ends are empty
	if(empty(array, leftmid) && empty(array, rightmid)){
	  *place = rightmid;
	  //	  printf("Not found 3\n");
	  goto not_found;
	  //	  return -1ll;
	}
	
	if( (key > array[leftmid].key) && (key < array[rightmid].key)){
	  //if(key == TESTVAL) printf("should be fine.... leftmid: %lld rightmid: %lld\n",leftmid, rightmid);
	  //this is if there is empty space between the two
	  *place = rightmid;
	  //	  printf("Not found 4\n");
	  goto not_found;
	  //	  return -1ll;
	}
	else if(key < array[leftmid].key){
	  high = leftmid;
	  //if(key == TESTVAL) printf("high: %lld\n", high);
	}
	//gets little hairy if high is empty it MIGHT work just because emptiness is
	//key being -1 and all our keys are positive for now
	else if(key > array[rightmid].key){
	  low = rightmid;
	}
	else if(key == array[leftmid].key){
	  *place = leftmid;
	  return array[leftmid].value;
	}
	else if(key == array[rightmid].key){
	  *place = rightmid;
	  return array[rightmid].value;
	}
      }
            
      
      /*
      for (i = section*ctree->sectionSize; i < (section+1)*ctree->sectionSize; i++){
	if(array[i].key == key) return array[i].value;
      }
      return -1ll;
      */
    }
    //go to right subtree
    else if (key > tree[boasLoc].val){

      //printf("GOING RIGHT: key %lld treeval %lld\n", key, tree[boasLoc].val);

      //if(key==TEST)printf("RIGHT? key %d nodeVal %d\n",key,tree[boasLoc].val);
      location = 2*location + 1;
      depth++;
#ifdef TABLE_LOOKUP
      boasLoc = getBoasValue(location, ctree->height-1, depth,ctree->table,ctree->baseCase);
#else
      boasLoc = normToBoas(location, ctree->height-1, depth);
#endif
    }
    //go to left subtree
    else{
      //printf("GOING LEFT key %lld treeval %lld\n", key, tree[boasLoc].val);
      //if(key==TEST)printf("LEFT? key %d nodeVal %d\n",key,tree[boasLoc].val);
      location = 2*location;
      depth++;
#ifdef TABLE_LOOKUP
      boasLoc = getBoasValue(location, (unsigned)ctree->height-1, (unsigned)depth,ctree->table,ctree->baseCase);
#else
      boasLoc = normToBoas(location, ctree->height-1, depth);
#endif
    }
  }


 not_found:
/*   { */
/*     size_t j; */
/*     printf("getValue at location %zd, searching for key %llu\n", */
/* 	   location, key); */
/*     printf("low is %zd, high is %zd\n", low, high); */
/*     for (j = low; j <= high; j++) { */

/*       if (empty(ctree->array, j)) { */
/* 	printf("- "); */
/*       } */
/*       else { */
/* 	printf("(%zd, %lld, %lld) ", j, ctree->array[j].key, ctree->array[j].value);     */
/*       }	   */
/*     } */
/*     printf("\n"); */
/*   } */
  return -1ll;
}

#ifdef RANGE
/* static long long int getRangeSum(cobtree* ctree, node* tree, pair* array, long long int smallKey, long long int largeKey){ */
/*   size_t place; */
/*   long long int value; */
/*   getValue(ctree, tree, 1, 1, array, smallKey, &place); */
/*   value = 0; */
/*   while(1){ */
/*     if(place >= ctree->totalArraySize) break; */
/*     if(!empty(array, place)){ */
/*       if(array[place].key > largeKey) break; */
/*       value += array[place].value; */
/*     } */
/*     place++; */
/*   } */
/*   return value; */
/* } */

static long long int getRangeValues(cobtree* ctree, node* tree, pair* array, long long int smallKey, int num_more){
  size_t place;
  long long int value;
  getValue(ctree, tree, 1, 1, array, smallKey, &place);
  value = 0;
  while(num_more >= 0){
    if(place >= ctree->totalArraySize) break;
    if(!empty(array, place)){
      //printf("%lld \n", array[place].value);
      value += array[place].value;
      num_more--;
    }
    place++;
  }
  abort();
}
#endif


long long int getRangeSum(cobtree* ctree, long long int smallKey, long long int largeKey){
  size_t place;
  long long int value;
  int status = FAILURE;

  while (status != SUCCESS) {
    xbegin();
    getValue(ctree, ctree->tree, 1, 1, ctree->array, smallKey, &place);
    value = 0;
    while(1){
      if(place >= ctree->totalArraySize) break;
      if(!empty(ctree->array, place)){
	//	printf("KEy found: %llu \n", ctree->array[place].key);
	if(ctree->array[place].key > largeKey) break;


	value += ctree->array[place].value;
      }
      place++;
    }
    status = xend();
  }
  return value;
}


static long long int randomLong(void){
  long long int x;
  long long int y;
  x = random();
  y = random();
  return (x + (y<<30));
}





#define CONTROL_SEGMENT_SIZE 1
#define MAX_TABLE_SIZE 1
#define DEFAULT_BASE_CASE 20

#define MAX_TESTS 2500

cobtree* init_cob_tree(char* filename) {

  cobtree* ctree;
  size_t file_size;
  int status;
  int fd;

  int array_page_offset;
  size_t num;
  int i = 0;
  char emptyArray[PAGESIZE];

  fd = open(filename, O_RDWR, 0666);
  assert(fd != -1);

  file_size = (size_t)lseek(fd, 0, SEEK_END);
  printf("Fize size of %s is %zd bytes, or %zd pages\n", filename, file_size, file_size/PAGESIZE);
  assert((file_size / PAGESIZE) > CONTROL_SEGMENT_SIZE + MAX_TABLE_SIZE);

  memset(emptyArray, PAGESIZE, 0);
  lseek(fd, 0, SEEK_SET);

  for (i = 0; i < (int)file_size / PAGESIZE; i++) {
    write(fd, &emptyArray, PAGESIZE);
  }
  printf("Cleared file to %d zero-pages.\n",(int)file_size / PAGESIZE);  
  close(fd);

  // Initialize the file.
  xInit(LIBXAC_DEFAULT_PATH, TRUE);
  //  xInit(LIBXAC_DEFAULT_PATH, FALSE);

  printf("COBtree key struct size?  %zd\n", sizeof(pair));

  // Mmap the entire file.
  ctree = xMmap(filename, (int)file_size / PAGESIZE);

  // Now we need to set pointers to the right places in the file...

  
  xbegin();
  ctree->pma_size = 0;
  ctree->totalArraySize = 1<<6;
  ctree->baseCase = DEFAULT_BASE_CASE;


  ctree->table = (int*) ((size_t)ctree + CONTROL_SEGMENT_SIZE * PAGESIZE);


  // I don't know what happens here yet from this point down...
  //  ctree->table = (int *)malloc(( ( 1<< (ctree->baseCase+1) ) - ctree->baseCase - 2)*sizeof(int));
  
  // Initialize the table...
  setValues(ctree->table, ctree->baseCase);
  
  // Initialize the array...

  // Jim: I'm not sure how big this was...
  //  To be safe, I'll just add an extra page in there for padding.
  
  //  array = (pair *)(ctree->table + ( ( 1<< (ctree->baseCase+1) ) - ctree->baseCase - 2 ) );


  array_page_offset =  (1 + ((( 1<< (ctree->baseCase+1) ) - ctree->baseCase - 2)*sizeof(int))/ PAGESIZE);
  ctree->array = (pair*)((size_t)ctree->table + PAGESIZE*array_page_offset);
  

  printf("array is %p  table is %p\n",ctree->array,ctree->table);
  ctree->sectionSize = getSectionSize(ctree->totalArraySize);
  num = ctree->totalArraySize/ctree->sectionSize;

  initArray(ctree, &ctree->array,
	    0, ctree->totalArraySize);

  // Put minimum and maximum values into the cobtree
  ctree->array[0].key = 0LL;
  ctree->array[0].value = 0LL;
  ctree->array[ctree->totalArraySize-1].key = 1LL<<61;
  ctree->array[ctree->totalArraySize-1].value = 1LL<<61;

  printf("After initialization, PMA is...\n");
  pma_print_array(ctree);
  printf("***************************\n");
  
  /********************ALLOCATE INITIAL TREE**********************/
  ctree->tree = (node*)(ctree->array + ctree->totalArraySize);
  ctree->height = getHeight(num);

  printf("tree allocated with height %d\n",ctree->height);


  /*******************update tree******************/
  updateTree(ctree, ctree->tree, 1, 0, 1, ctree->array);


  printf("Now Trying to print the tree? \n");
  pma_print_tree(ctree);

  status = xend();
  assert(status == SUCCESS);
  

  //  xbegin();
  //  rebalance(ctree->array, 0, ctree->totalArraySize);
  //  status = xend();
  //  assert(status == SUCCESS);
  //  printf("rebalanced\n");

  return ctree;
}

static void destroy_cob_tree(char* filename) {
  xMunmap(filename);
  assert(errno == 0);
  xShutdown();
}


// Start from an empty cobtree, do searches/inserts:
void test_search_insert_cobtree(cobtree* ctree) {
  unsigned long long y;
  int i;
  const int MAX_BAD_VALUES = 20;
  unsigned long long values_not_to_insert[MAX_BAD_VALUES];
  unsigned long long inserted_values[MAX_TESTS];

  printf("Testing cobtree...\n");

  // Pick some values not to insert.
  for (i = 0; i < MAX_BAD_VALUES; i++) {
    values_not_to_insert[i] = randomLong();
    printf("Bad value %d: %llu\n", i, values_not_to_insert[i]);
  }

  for (i = 0; i < MAX_TESTS; i++) {
    int j;
    int bad_value = TRUE;
    int result = -1;
    long long answer;

    // Pick a value y to actually insert.
    while (bad_value) {      
      y = randomLong();
      bad_value = FALSE;      
      for (j = 0; j < 20; j++) {
	if (y == values_not_to_insert[j]) {
	  bad_value = TRUE;
	  break;
	}
      }
    }

    inserted_values[i] = y;
    printf("Inserting value %d...: %llu\n", i, inserted_values[i]);

    result = pma_search(ctree, inserted_values[i], &answer);
    assert(result != 0);

    // Insert the value
    pma_insert(ctree, inserted_values[i], inserted_values[i]);

    for (j = 0; j < MAX_BAD_VALUES; j++) {
      result = pma_search(ctree, values_not_to_insert[j], &answer);
      assert(result != 0);
    }
    for (j = 0; j <= i; j++) {
      result = pma_search(ctree, inserted_values[i], &answer);
      assert(result==0);
      assert((unsigned long long)answer == inserted_values[i]);
    }

    printf("Successfully performed %d insert,  value is %llu\n",
	   i, inserted_values[i]);   
  }

  printf("********************************DONE TESTING\n");
}


// Jim: I'm not sure how to use this function any more.
void test_cobtree(cobtree* ctree) {
  long long int y;
  int i;
  int num_errors = 0;

  unsigned long long inserted_values[MAX_TESTS];

  printf("testing...\n");
  for(i=0; i < MAX_TESTS; i++){
    long long x;
    size_t place;
    int status;
    y = randomLong();

    inserted_values[i] = y;
    //y = y%ctree->totalArraySize;
    //printf("y %d\n",y);

    xbegin();
    if (i % 10000 == 0) {
      printf("i = %d: array size is %zd \n",  i, ctree->totalArraySize);
    }

    if((getValue(ctree, ctree->tree, 1, 1, ctree->array, y, &place)) == -1ll) {
      //      printf("Inserting y: %lld .... ", y);
      ins(ctree,&ctree->tree,&ctree->array,y,y);

      //printf("KEYS:\n");
      //for(count=0; count < ctree->totalArraySize; count++){
      //printf(" %lld",array[count].key);
      //}
      //printf("\n");
      //checkArray(array);
      //printf("no\n");
      x = getValue(ctree, ctree->tree, 1, 1, ctree->array, y, &place);
      //      printf("Found x = %lld\n", x);
      if(x == -1ll){
	//	printf("Inserting y: %lld .... ", y);
	//	printf("Found x = %lld\n", x);
	printf("TOTALARRAYSIZE: %zd\n", ctree->totalArraySize);
	printf("***********key value: %lld %lld\n", y,x);
	break;
      }
      else {
	//printf("TOTAL: %d\n", ctree->totalArraySize);
	if (y==x){
	  //printf("key value: %lld %lld\n", y,x);
	}
	else{
	  printf("CRAP %lld %lld\n", y,x);
	  break;
	}
      }

      {
	int j;
	int answer;
	long long val;

	for (j = 0; j < i; j++) {
	  answer = pma_search(ctree, inserted_values[j], &val);
	  if (answer != 0) {
	    printf("ERROR at (j, i) = (%d, %d)\n", j, i);
	  }
	  else {
	    if ((unsigned long long)val != inserted_values[j]) {
	      printf("ERROR!  at (j, i) = (%d, %d), val = %llu, actual shoudl be %llu\n",
		     j, i, val, inserted_values[j]);
	    }
	  }	  
	}
      }
    }
    else {
      // In thoery we might have dups...but how likely is that?
      num_errors++;
    }
    status = xend();
    assert(status == SUCCESS);
  }

  printf("Num Errors/ dups in the end: %d\n", num_errors);
  
  printf("********************************DONE TESTING\n");
  printf("Final i is %d\n", i);
  abort();    
}

void pma_insert(cobtree* ctree,  unsigned long long key, long long int value){
  int status = FAILURE;
  // Just the wrapper...

  while (status != SUCCESS) {
    xbegin();
    ins(ctree, &ctree->tree, &ctree->array, key, value);
/*     printf("After insert.. tree = %p, array is %p\n", */
/* 	   ctree->tree, ctree->array); */
/*     { */
/*       long long int test; */
/*       int answer; */
/*       printf("Searching for %llu? \n", key); */
/*       answer = pma_search(ctree, key, &test); */

/*       printf("answer = %d, value = %llu, test = %llu\n", */
/* 	     answer, value, test); */
/*     } */	   


//    printf("After insert...\n");
    //    pma_print_array(ctree);
    //    printf("Now Trying to print the tree? \n");
    //    pma_print_tree(ctree);

    status = xend();
  }
}


int pma_search(cobtree* ctree, unsigned long long key, long long int* value) {

  int answer = 1;
  long long x;
  size_t place;
  int status = FAILURE;

  while (status != SUCCESS) {
    xbegin();
    x = getValue(ctree, ctree->tree, 1, 1, ctree->array, key, &place);
    if (x != -1ll) {
      answer = 0;
      *value = ctree->array[place].value;
    }
    else {
      //      printf("DIDN't find  key  %llu\n", key);
    }
    status = xend();
  }
  return answer;
}

int test_main(int argc, char* argv[]) {

  int num_procs = 1;
  int N = 2500;
  char* filename;
  cobtree* ctree;

  if (argc > 1) {
    filename = argv[1];

    printf("About to initialize cob tree for file %s...\n", filename);
    printf("N is %d, P = %d\n", N, num_procs);
    ctree = (cobtree*) init_cob_tree(filename);

    test_search_insert_cobtree(ctree);
    printf("completed initialization.\n");
    destroy_cob_tree(filename);
  }
  else {
    printf("Usage: %s <filename>\n", argv[0]);
  }
  return 0;      
}



