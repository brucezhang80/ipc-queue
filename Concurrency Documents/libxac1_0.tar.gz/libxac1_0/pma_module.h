/*************************************************************************
 *
 *  Cache-oblivious B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004       Massachusetts Institute of Technology
 * Copyright (c) 2004       Bradley C. Kuszmaul
 * Copyright (c) 2004       Zardosht Kasheff
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * pma_module.h
 *
 */


#ifndef __PMA_MODULE_H
#define __PMA_MODULE_H

#include <stdlib.h>

/***************structs***********/
struct keyval{
  long long int key;

#ifdef NUM_CHAR
  char pad[NUM_CHAR];
#endif

  long long int value;
};
typedef struct keyval pair;

struct nd{
  //trees will be represented in an array

  //value of node
  long long int val;

#ifdef NUM_CHAR
  char pad[NUM_CHAR];
#endif

};
typedef struct nd node;

/***************structs***********/


typedef struct {

  size_t totalArraySize;
  size_t sectionSize;

  int height;

#ifdef TABLE_LOOKUP
  unsigned long baseCase;
  int* table;
#endif

  unsigned long pma_size;

  node* tree;
  pair* array;

} cobtree;



cobtree* init_cob_tree(char* filename);
void pma_print_array(cobtree* ctree);
void pma_print_tree(cobtree* ctree);

void pma_insert(cobtree* ctree,  unsigned long long key, long long int value);
int pma_search(cobtree* ctree, unsigned long long key, long long int* value);

void test_search_insert_cobtree(cobtree* ctree);
void test_cobtree(cobtree* ctree);
int test_main(int argc, char* argv[]);
long long int getRangeSum(cobtree* ctree, long long int smallKey, long long int largeKey);

#endif
