/*************************************************************************
 *
 *  Cache-oblivious B-tree code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004       Massachusetts Institute of Technology
 * Copyright (c) 2004       Zardosht Kasheff
 * Copyright (c) 2004       Bradley C. Kuszmaul
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * veblib.c
 *
 *   Van Emde Boas library of useful functions. 
 */

/* Zardosht wrote most of this. */


#include <assert.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include "veblib.h"

//rid bits i through j(not including j)
//gets rid of j-i bits
inline size_t ridBits(size_t x, unsigned int i, unsigned int j) {
  unsigned long y = (x>>j)<<i;
  unsigned long z = x&((1<<i)-1);
  return y+z;
}

//returns hyperceil, tested and works
// This one works on ints (i.e., not too big.)  It would be easy to make it work on unsigned long  by changing a few decls.
inline unsigned int hyperceil_int(unsigned int num) {
  unsigned int option = 1;
  unsigned int temp = num;
  while(temp != 1){
    temp = temp>>1;
    option = option<<1;
  }
  return (option == num) ? option : (option<<1);
}

/* Effect:  Compute the position of a node in the Van Emde Boas layout.
 *  The result returned starts with 0.
 *  VAL is the index in the standard layout (starting with 1)  [This is a conceptual BUG!  The result and val should be indexed the same way.*
 *    In the standard layout, the root is at index 1.
 *    If a node is at position I then its children are at 2*I and 2*I+1
 *    [The conceptual bug:  This should be that the root is at position 2, and the children are at 2*I+1 and 2*I+2
 *     fixing this conceptual bug is going to be a lot of work because of all the users.]
 *  HGHT is the hght of the entire tree.  The total number of nodes in the tree is 2^HGHT-1
 *   The number of leaves is 2^(HGHT-1)
 *   Thus a tree with 15 nodes and 8 leaves is of HGHT 4.
 *  DEPTH is the depth of node at index VAL, where the root is at DEPTH 1.
 *    In principal, DEPTH ould be computed from VAL, but we pass it in to make things faster.
 *    DEPTH is something like LG(VAL)
 *    For example, VAL=1    --> DEPTH=1
 *                 VAL=2-3  --> DEPTH=2
 *                 VAL=4-7  --> DEPTH=3
 *    so generally DEPTH = FLOOR(LG(VAL))+1
 */
size_t normToBoas(size_t val, unsigned int hght, unsigned int depth){
  size_t offset = 0;
  //printf("normToBoas(%lu, %u, %u)\n", val, hght, depth);
  if(hght<depth) return -1;
  while(hght > 0){

    if (hght <= 3){
      return offset + val-1;
    }
    else{
      //bottom half base cases
      unsigned int half = hyperceil_int((hght+1)/2);
      //top half
      unsigned int rest = hght-half;
      //if(HUH)printf("rest %d half %d\n", rest, half);
      /*
      if(val <= ((1UL<<(rest))-1)){
	hght = rest;
      }
      */
      if(depth <= rest){
	hght = rest;
      }
      else{

	//beta is number of leading zeroes of target
	unsigned int beta = half-1;
	//alpha is number of leading zeroes of val
	unsigned int alpha = hght - depth;
	
	//soFar is node of subtree we will recurse into
	size_t soFar = val>>(beta-alpha);
	//if(HUH)printf("soFar: %d\n", soFar);
	
	size_t x = 1<<rest;
	
	offset += x - 1 + (soFar - x)*((1<<half) - 1); 
	//newNum is the new number
	//want to get rid of "rest" bits
	//index starts at depth-(rest+1)
	{
	  size_t newNum = ridBits(val, depth-(rest+1), depth-1);
	  //if(HUH)printf("newNum: %d\n", newNum);
	  hght = half;
	  depth -= rest;
	  val = newNum;
	}
      }
    }
  }
  return UINT_MAX;
}



// Come on Zardosht.  Write down what the arguments to these functions mean.
// Should normToBoasVar(x,y,z,1,1)==normToBoas(x,y,z) ?
// If so, then this is broken, because it is not true when x=8,y=3,z=4
size_t normToBoasVar(size_t val, unsigned int hght, unsigned int depth, size_t nodeSize, size_t leafSize) {
  size_t offset = 0;
  assert(hght>=depth);
  while(hght > 0){

    if (hght <= 3){
      if(val ==1) return offset;
      if(hght == 3){
	if(val <= 3) return offset + (val-1)*nodeSize;
	else if (val <= 4) return offset + 2*nodeSize + leafSize;
	else if (val <= 6) return offset + (val-3)*nodeSize + 2*leafSize;
	else return offset + 3*nodeSize + 3*leafSize;
	return offset + val-1;
      }
      else if (hght==1) return offset;
      else{
	//we know hght = 2
	if(val == 2) return offset + nodeSize;
	else return offset + nodeSize + leafSize;
      }
    }
    else{
      //bottom half base cases
      unsigned int half = hyperceil_int((hght+1)/2);
      //top half
      unsigned int rest = hght-half;
      //if(HUH)printf("rest %d half %d\n", rest, half);
      if(val <= ((1UL<<(rest))-1)){
	hght = rest;
	return offset + (normToBoas(val,hght,depth)*nodeSize);
      }
      else{

	//beta is number of leading zeroes of target
	unsigned int beta = half-1;
	//alpha is number of leading zeroes of val
	unsigned int alpha = hght - depth;
	
	//soFar is node of subtree we will recurse into
	size_t soFar = val>>(beta-alpha);
	//if(HUH)printf("soFar: %d\n", soFar);
	
	size_t x = 1<<rest;
	
	offset += (x - 1 + (soFar - x)*((1<<half) - 1))*nodeSize;

	offset += (soFar-x)*(1<<(rest-1))*(leafSize-nodeSize);



	//newNum is the new number
	//want to get rid of "rest" bits
	//index starts at depth-(rest+1)
	{
	  size_t newNum = ridBits(val, depth-(rest+1), depth-1);
	  //if(HUH)printf("newNum: %d\n", newNum);
	  hght = half;
	  depth -= rest;
	  val = newNum;
	}
      }
    }
  }
  return UINT_MAX;
}

//uses table lookup
size_t getBoasValue(size_t val, unsigned int hght, unsigned int depth, int* table, unsigned int baseCase){
  unsigned int half;
  unsigned int rest;
  size_t soFar;
  //int i;
  size_t newNum;
  int alpha;
  int beta;
  size_t offset;
  int x;
  offset = 0;

  while(hght > 0){

    if (hght <= baseCase){
      return offset + table[ (1<<hght) - 1 - hght + val-1];
    }
    else{
      //bottom half base cases
      half = hyperceil_int((hght+1)/2);
      //top half
      rest = hght-half;
      //if(HUH)printf("rest %d half %d\n", rest, half);
      if(val <= ((1UL<<(rest))-1)){
	hght = rest;
      }
      else{
	
	//beta is number of leading zeroes of target
	beta = half-1;
	//alpha is number of leading zeroes of val
	alpha = hght - depth;
	
	//soFar is node of subtree we will recurse into
	soFar = val>>(beta-alpha);
	//if(HUH)printf("soFar: %d\n", soFar);
	
	x = 1<<rest;
	
	offset += x - 1 + (soFar - x)*((1<<half) - 1); 
	//newNum is the new number
	//want to get rid of "rest" bits
	//index starts at depth-(rest+1)
	newNum = ridBits(val, depth-(rest+1), depth-1);
	//if(HUH)printf("newNum: %d\n", newNum);
	hght = half;
	depth -= rest;
	val = newNum;
      }
    }
  }
  return ULONG_MAX;
}

//normToBoas returns a long, but I know it is an int
void setValues(int* table, unsigned int baseCase){
  unsigned int i,j,k;
  size_t currVal;
  unsigned int currPtInTable = 0;
  for(i=1; i <= baseCase; i++){
    //printf("HEIGHT: %d\n",i);
    currVal = 1;
    for(j=0;j<i;j++){
      for(k=0;k< 1U<<j; k++){
	table[currPtInTable] = normToBoas(currVal,i,j+1);
	//if(currPtInTable < 256)printf("%d     %d %d %d\n",currPtInTable, currVal,i,j+1);
	currVal++;
	currPtInTable++;
      }      
    }
  }
}
