/*************************************************************************
 *
 *  Search tree test code
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * btTester.c
 *
 *  Test program performing insertions on multiple processes.
 */

#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
 
#include "basics.h"
#include "btree.h"
#include "btTester.h"

#include "pma_module.h"


#ifdef VERIFY_INSERTS
unsigned long* btree_keys_inserted;
#endif

// The actual keys we are going to insert.
#ifndef START_EMPTY
unsigned long firstInserts[BASE_INSERTS];
#endif

unsigned long* keysToInsert;


// Gets the arguments and makes sure they are valid.
static void getArgs(int argc, char* argv[], expArgs* theArgs) {
  int n = 2500;
  int numProcs = 1;

  time_t today;
  struct tm* now;
  char timeString[100];
  char eventLogName[100];


  // The arguments are:
  //   <fileName>   <num inserts>  <num procs>  <outputFilePrefix>

  theArgs->createOutputFile = FALSE;
  if (argc > 1) {
    strncpy(theArgs->dataFileName, argv[1], MAX_NAME_LENGTH);
  }
  theArgs->n = ((argc > 2) ? atoi(argv[2]) : n);
  theArgs->numProcs = ((argc > 3) ?  atoi(argv[3]) : numProcs);

  if (theArgs->n < 0) {
    theArgs->n = n;
  }
 
  if ((theArgs->numProcs <= 0) || (theArgs->numProcs > MAX_NUM_PROCS)) {
    theArgs->numProcs = MAX_NUM_PROCS;
  }

  printf("The data file is %s\n", theArgs->dataFileName);
  printf("n is %d\n", theArgs->n);
  printf("numProcs is %d\n", theArgs->numProcs);
  printf("#inserts perXaction: %d\n", INSERTS_PER_XACTION);
  printf("K is %d\n", K);
  printf("Key size for b-trees: %zd\n", TEST_KEY_SIZE);


  snprintf(eventLogName, 100, "evP_%dLog", theArgs->numProcs);

  setEventLogName(eventLogName);

  if (argc > 4) {
    theArgs->createOutputFile = TRUE;

    today = time(NULL);
    now = localtime(&today);
    strftime(timeString, (size_t)100, "%d_%m_%Y_%H_%M", now);
    printf("Today is %s\n", timeString);


//    snprintf(theArgs->outputFileName, MAX_NAME_LENGTH, "%sN%2d_%dP_%s.m",
    snprintf(theArgs->outputFileName, MAX_NAME_LENGTH, "%sN%d_%.2dP_.m",
	     argv[4],
	     theArgs->n,
	     theArgs->numProcs);

    // drop the time string for now...
//	     timeString);


    printf("Time:  %s\n", timeString);
    printf("The output filename is %s\n", theArgs->outputFileName);
  }


}


static void generateInsertData(expArgs* theArgs) {
    int i, j;
  keysToInsert = (unsigned long*) malloc(sizeof(long) * (theArgs->n)*INSERTS_PER_XACTION);
  assert(keysToInsert != NULL);

#ifndef START_EMPTY
  for (i = 0; i < BASE_INSERTS; i++) {
      firstInserts[i] = rand();
  }
#endif

  for (i = 0; i < theArgs->n; i++) {
      for (j = 0; j < INSERTS_PER_XACTION; j++) {
	  keysToInsert[i*INSERTS_PER_XACTION + j] = rand();
      }
  }

/*   printf("First 100 elements: \n"); */
/*   for (i = 0; i < 100; i++) { */
/*     printf("%ld, ", keysToInsert[i]); */
/*   } */
/*   printf("\n\n"); */
}

static void cleanupInsertData(void) {

  free(keysToInsert);
}


typedef long long timeUnit;
typedef struct testMetaData {
    int mypid[MAX_NUM_PROCS];
    int n;
    timeUnit startTime;
    timeUnit endTime;
    timeUnit zeroInsertTime[MAX_NUM_PROCS];
    timeUnit lastInsertTime[MAX_NUM_PROCS];
    struct rusage rusageBeforeArray[MAX_NUM_PROCS];
    struct rusage rusageAfterArray[MAX_NUM_PROCS];
} testMetaData;


typedef struct sharedRegion {
  int globalShmId;
  size_t regionSize;
  void* globalRegionPtr;

  expArgs testArgs;

  int* ready;
  unsigned long* keysToInsert;
  timeUnit* timings;
  long long* systemTimes;
  long long* userTimes;

  testMetaData* tmData;
} sharedRegion;

sharedRegion dataRegion;



static int createSHMRegion(expArgs testArgs) {

  dataRegion.regionSize = (testArgs.n*(sizeof(int) +
				       sizeof(timeUnit)) +
			   sizeof(testMetaData)  +
			   (sizeof(int)*(testArgs.numProcs))+
			   2*(sizeof(long long)*testArgs.n) +
			   1024);
/*   printf("Finalsize should be %zd + %zd + %zd + %zd + 1024 = %zd\n", */
/* 	 testArgs.n*sizeof(int), */
/* 	 testArgs.n*sizeof(double), */
/* 	 sizeof(testMetaData), */
/* 	 sizeof(int)*testArgs.numProcs, */
/* 	 testArgs.n*sizeof(int) + testArgs.n*sizeof(double)+ sizeof(testMetaData) +  sizeof(int)*testArgs.numProcs + 1024); */

  dataRegion.regionSize = PAGESIZE* ((dataRegion.regionSize/PAGESIZE) +1);
  dataRegion.globalShmId = shmget(IPC_PRIVATE, dataRegion.regionSize, IPC_CREAT | IPC_EXCL | 0777);

  if (dataRegion.globalShmId == -1) {
    perror("Error in shmget here! ");    
    printf("size is %zd\n", dataRegion.regionSize);
    printf("errno is %d , and einval is %d\n", errno, EINVAL);

    return -1;
  }
  else {
/*     printf("Process %d created region with shmId = %d, size = %zd\n", */
/* 	   getpid(), */
/* 	   dataRegion.globalShmId, */
/* 	   dataRegion.regionSize); */


    dataRegion.globalRegionPtr = shmat(dataRegion.globalShmId, NULL, 0);
    dataRegion.testArgs = testArgs;

    if (((ssize_t)dataRegion.globalRegionPtr == -1)) {
      printf("Error in detaching to shared region.\n");
      assert(FALSE);
    }
    else {
      int i;
//      printf("Attached to shared region.\n");
      dataRegion.keysToInsert = (unsigned long*)dataRegion.globalRegionPtr;
      dataRegion.timings = (timeUnit*)((size_t)(dataRegion.keysToInsert) + (sizeof(int) * dataRegion.testArgs.n));
      dataRegion.ready = (int*)((size_t)(dataRegion.timings) + (sizeof(timeUnit)*dataRegion.testArgs.n));
      dataRegion.tmData = (testMetaData*)((size_t)(dataRegion.ready) + (sizeof(int)*dataRegion.testArgs.numProcs));

      dataRegion.systemTimes = (long long*)((size_t)(dataRegion.tmData) + (sizeof(testMetaData)));
      dataRegion.userTimes = (long long*)((size_t)(dataRegion.systemTimes) + (sizeof(long long) * dataRegion.testArgs.n));
					    

      for (i = 0; i < dataRegion.testArgs.n; i++) {
	dataRegion.timings[i] = 0;
	dataRegion.systemTimes[i] = 0;
	dataRegion.userTimes[i] = 0;
      }
      for (i = 0; i < dataRegion.testArgs.numProcs; i++) {
	dataRegion.ready[i] = -1;
      }

      // Initialize the tmData struct
      dataRegion.tmData->n = dataRegion.testArgs.n;
      for (i = 0; i < MAX_NUM_PROCS; i++) {
	dataRegion.tmData->zeroInsertTime[i] = 0;
	dataRegion.tmData->lastInsertTime[i] = 0;
      }

      
    }
    return 0;
  }
}


// This is called on every process.
static int detachFromSharedRegion(void) {
  int error;
/*   printf("Process %d about to detach from shared region with id %d\n", */
/* 	 getpid(), */
/* 	 dataRegion.globalShmId); */

  error = shmdt(dataRegion.globalRegionPtr);

  if (error != 0) {
    printf("ERROR in detaching! \n");
    return -1;
  }

  return 0;
}


static int destroySHMRegion(void) {
  struct shmid_ds shm_desc;


  detachFromSharedRegion();
/*   printf("Process %d about to destroy region with shmId = %d\n", */
/* 	 getpid(), */
/* 	 dataRegion.globalShmId); */

  
  if (shmctl(dataRegion.globalShmId, IPC_RMID, &shm_desc) == -1) {
    perror("Error destroying control region with shmctl");
    return -1;
  }
  return 0;
}



int rootPid;
int myPid = -1;
int myProcNum = 0;
int myChildren[MAX_NUM_PROCS];
int numChildren;


static void startProcessesHelper(int baseId, int n) {

  int value;
  int childSplit, parentSplit;
  
  if (n > 1) {
    myPid = getpid();

    parentSplit = n/2;
    childSplit = n - parentSplit;

    //    printf("Process %d plants to split %d into parent:%d, child:%d\n", myPid, n, parentSplit, childSplit);    

    value = fork();
    if (value == -1) {
      perror("Error calling fork! \n");
      perror("What is wrong? ");
      assert(FALSE);
    }

    if (value == 0) {
      // This is the child.
      myProcNum = baseId + parentSplit;
      numChildren = 0;
      //      printf("Child of %d recursively splitting to generate %d procs....\n", myPid, childSplit);
      startProcessesHelper(myProcNum, childSplit);
    }
    else {
      // This is the parent.
      myProcNum = baseId;
      myChildren[numChildren] = value;
      numChildren++;
      
      //      printf("Parent %d recursively splitting more to generate %d procs...\n", myPid, parentSplit);
      startProcessesHelper(myProcNum, parentSplit);
    }
  }
  else {
    if (n == 1) {

      //      int i;

      // The only thing here that we HAVE To do...
      myPid = getpid();

/*       printf("*******************\n"); */
/*       printf("I am process %d.   MyProcNum = %d, have %d children:\n", */
/* 	     myPid, myProcNum, numChildren); */

      
/*       for (i = 0; i < numChildren; i++) { */
/* 	printf("Child %d: %d\n", i, myChildren[i]); */
/*       } */
/*       printf("*******************\n\n"); */
    }
  }
}

static void startProcesses(int n) {
  int i;


  myPid = getpid();
  rootPid = myPid;    // This is the one global process.
  numChildren = 0;
  for (i = 0; i < MAX_NUM_PROCS; i++) {
    myChildren[i] = -1;
  }  
  myProcNum = 0;
  startProcessesHelper(myProcNum, n);
}


static void waitForChildrenToFinish(void) {

  int i = 0;
  int error = 0;
  int status;
  
  for (i = 0; i < numChildren; i++) {
    /*     printf("Process %d (myProcNum %d) waiting on child %d to finish. \n", */
    /* 	   getpid(), */
    /* 	   myProcNum, */
    /* 	   myChildren[i]); */
    error = waitpid(myChildren[i], &status, 0);
    //    printf("What is status? %d.  Is it WIFEXITED? %d\n", status, WIFEXITED(status));
    if (!WIFEXITED(status) && (error == -1)) {
      perror("Waiting failed...");
      printf("Process %d == %d tried to wait for pid = %d\n",
	     myPid, getpid(),
	     myChildren[i]);      
    }
    //    printf("Process %d (myProcNum %d) done waiting on %d\n", myPid, myProcNum, myChildren[i]);
  }

}

static int everyoneReady(int numProcs) {
  int i;

  for (i = 0; i < numProcs; i++) {
    if (!dataRegion.ready[i]) return FALSE;
  }

  return TRUE;  
}


static int doInserts(int myPNum, expArgs* theArgs) {

  int i;
  int n = theArgs->n;
  int numP = theArgs->numProcs;
  int numInserts;
  rtimeStruct t1, t2;
  //  timeStruct mt1, mt2;

  struct rusage currentRUsage;

  int error;
  
  assert(myPid == getpid());
  //  printf("Process %d (myPNum = %d) doing inserts.\n", myPid, myPNum);
  assert((myPNum >=0) && (myPNum < numP));




  // Store the initial time and resource usage
  error  = getrusage(RUSAGE_SELF, &(dataRegion.tmData->rusageBeforeArray[myPNum]));
  if (error != 0) {
    perror("Error with rusage here!");
  }


  dataRegion.tmData->mypid[myPNum] = getpid();

  //  checkTimer(&mt1);
  checkCycleCount(&t1);
  dataRegion.tmData->zeroInsertTime[myPNum] = t1;

  for (i = 0; i < (n)/(numP); i++) {

      //      gettimeofday(&tTemp, NULL);
      //      gettimeofday(&tTemp, NULL);
      
    //    dataRegion.keysToInsert[numP*i+myPNum] = keysToInsert[numP*i+myPNum];

#ifndef NO_CONFLICT_TEST
      if (INSERTS_PER_XACTION == 1) {
	  doActualInsert(keysToInsert[(numP*i + myPNum) * INSERTS_PER_XACTION  + 0]);
      }
      else {
	  doBulkInserts(keysToInsert + ((numP*i+myPNum)*INSERTS_PER_XACTION),
			INSERTS_PER_XACTION);
      }
#else
    performOperation(myPNum, theArgs->numProcs);
#endif

    if (theArgs->createOutputFile) {
	// grab the time for the next insert.
	checkCycleCount(&t2);
	dataRegion.timings[numP*i+myPNum] = t2;

	// Store the initial time and resource usage
	error  = getrusage(RUSAGE_SELF, &currentRUsage);
	if (error != 0) {
	    perror("Error with rusage here!");
	}
	dataRegion.systemTimes[numP*i+myPNum] =
	    currentRUsage.ru_stime.tv_sec*(1000000) +
	    currentRUsage.ru_stime.tv_usec;

	dataRegion.userTimes[numP*i+myPNum] =
	    currentRUsage.ru_utime.tv_sec*(1000000) +
	    currentRUsage.ru_utime.tv_usec;
    }
    
    //    dataRegion.timings[numP*i+myPNum] = clockTimeDiff(t1, t2);
    //    totalTime += clockTimeDiff(t1, t2);
      
  }
  numInserts = n/(numP);

  if (numP* (n/numP) + myPNum < n) {
    i = n/numP;

    //    dataRegion.keysToInsert[numP*i+myPNum] = keysToInsert[numP*i+myPNum];

#ifndef NO_CONFLICT_TEST
    if (INSERTS_PER_XACTION == 1) {
	doActualInsert(keysToInsert[(numP*i + myPNum) * INSERTS_PER_XACTION  + 0]);
    }
    else {
	doBulkInserts(keysToInsert + ((numP*i+myPNum)*INSERTS_PER_XACTION),
		      INSERTS_PER_XACTION);
    }
#else
    performOperation(myPNum, theArgs->numProcs);
#endif

    if (theArgs->createOutputFile) {
      checkCycleCount(&t2);
      dataRegion.timings[numP*i+myPNum] = t2;


      // Store the initial time and resource usage
      error  = getrusage(RUSAGE_SELF, &currentRUsage);
      if (error != 0) {
	  perror("Error with rusage here!");
      }
      dataRegion.systemTimes[numP*i+myPNum] =
	  currentRUsage.ru_stime.tv_sec*(1000000) +
	  currentRUsage.ru_stime.tv_usec;

      dataRegion.userTimes[numP*i+myPNum] =
	  currentRUsage.ru_utime.tv_sec*(1000000) +
	  currentRUsage.ru_utime.tv_usec;
    }
    
    //    checkCycleCount(&t2);
    //    dataRegion.timings[numP*i+myPNum] = clockTimeDiff(t1, t2);
    //    totalTime += clockTimeDiff(t1, t2);
    numInserts++;
  }


  // Get the final time/rusage.
  checkCycleCount(&t1);
  dataRegion.tmData->lastInsertTime[myPNum] = t1;
  //  checkTimer(&mt2);

  //  reportTime("!!! AVG TIME TO INSERT: ", timeDiff(mt1, mt2), numInserts);
  

  error  = getrusage(RUSAGE_SELF, &(dataRegion.tmData->rusageAfterArray[myPNum]));
  if (error != 0) {
    perror("Error with rusage here!");
  }


  //  printf("Avg. time per insert for Process %d,  %d inserts:  %0.4f us! \n", myPNum, numInserts, 1e6*totalTime/numInserts);

  return 0;
}


#ifdef GENERATE_LONG_OUTPUT

static void printUserSystemTimes(expArgs* theArgs, FILE* f) {
  int i;

  fprintf(f, "\n\n%sUser and system times used by each process. \n", COMMENT_STRING);
  fprintf(f, "%s   Rows are [i,   before.tv_sec,   before.tv_usec,  after.tv_sec, after.tv_usec   Total diff in us:]\n",
	  COMMENT_STRING);
  fprintf(f, "userTime = [\n");
  for (i = 0; i < theArgs->numProcs; i++) {
    fprintf(f, "%d,    %ld,  %ld,   %ld,   %ld,    %0.4f; \n",
	   i,
	   dataRegion.tmData->rusageBeforeArray[i].ru_utime.tv_sec,
	   dataRegion.tmData->rusageBeforeArray[i].ru_utime.tv_usec, 
	   dataRegion.tmData->rusageAfterArray[i].ru_utime.tv_sec,
	   dataRegion.tmData->rusageAfterArray[i].ru_utime.tv_usec,
	    (1.0e6)*(dataRegion.tmData->rusageAfterArray[i].ru_utime.tv_sec - dataRegion.tmData->rusageBeforeArray[i].ru_utime.tv_sec) +
	    dataRegion.tmData->rusageAfterArray[i].ru_utime.tv_usec - dataRegion.tmData->rusageBeforeArray[i].ru_utime.tv_usec);
  }
  fprintf(f, "]; \n\n");

  fprintf(f, "systemTime = [\n");
  for (i = 0; i < theArgs->numProcs; i++) {
    fprintf(f, "%d,    %ld,  %ld,   %ld,   %ld,    %0.6f; \n",
	    i,
	    dataRegion.tmData->rusageBeforeArray[i].ru_stime.tv_sec,
	    dataRegion.tmData->rusageBeforeArray[i].ru_stime.tv_usec,
	    dataRegion.tmData->rusageAfterArray[i].ru_stime.tv_sec,
	    dataRegion.tmData->rusageAfterArray[i].ru_stime.tv_usec,
	    (1.0e6)*(dataRegion.tmData->rusageAfterArray[i].ru_stime.tv_sec - dataRegion.tmData->rusageBeforeArray[i].ru_stime.tv_sec) +
	    dataRegion.tmData->rusageAfterArray[i].ru_stime.tv_usec - dataRegion.tmData->rusageBeforeArray[i].ru_stime.tv_usec); 
  }
  fprintf(f, "]; \n\n");


  fprintf(f, "%s   Rows are [i,   page_reclaim     page_fault    swaps    voluntaryContext   involuntaryContext]\n",
	  COMMENT_STRING);
  
  fprintf(f, "pageFaultData = [\n");
  for (i = 0; i < theArgs->numProcs; i++) {
    fprintf(f, "%d,    %ld,  %ld,   %ld,   %ld    %ld; \n",
	    i,
	    dataRegion.tmData->rusageAfterArray[i].ru_minflt - dataRegion.tmData->rusageBeforeArray[i].ru_minflt,
	    dataRegion.tmData->rusageAfterArray[i].ru_majflt - dataRegion.tmData->rusageBeforeArray[i].ru_majflt,
	    dataRegion.tmData->rusageAfterArray[i].ru_nswap - dataRegion.tmData->rusageBeforeArray[i].ru_nswap,
	    dataRegion.tmData->rusageAfterArray[i].ru_nvcsw - dataRegion.tmData->rusageBeforeArray[i].ru_nvcsw,
	    dataRegion.tmData->rusageAfterArray[i].ru_nivcsw - dataRegion.tmData->rusageBeforeArray[i].ru_nivcsw);
  }
  fprintf(f, "]; \n\n");

}

#endif

#ifdef GENERATE_LONG_OUTPUT

static void generateOutputDataFile(expArgs* theArgs) {

  int i;
  FILE* output = stdout;

  if (theArgs->createOutputFile) {
    output = fopen(theArgs->outputFileName, "w");
    if (output == NULL) {
      printf("Error opening file name %s\n", theArgs->outputFileName);
      theArgs->createOutputFile = FALSE;
      output = stdout;
    }
  }
  
  fprintf(output, "%s  Test parameters \n", COMMENT_STRING);
  fprintf(output, "n = %d; \nnumProcs = %d;  \n", theArgs->n, theArgs->numProcs);
  fprintf(output, "%s  FINAL EXPERIMENT TIME: %lld to %lld:  %0.2f thousand clock cycles\n",
	 COMMENT_STRING,
	 dataRegion.tmData->startTime,
	 dataRegion.tmData->endTime,
	 1.0*(dataRegion.tmData->endTime - dataRegion.tmData->startTime)/1000.0);

  fprintf(output, "\n");
  fprintf(output, "%s  Number of clock cycles per insert: %0.2f clock cycles. \n",
	 COMMENT_STRING,
	 1.0*(dataRegion.tmData->endTime - dataRegion.tmData->startTime)/theArgs->n);


  // Echo the output to stdout if necessary.
  if (output != stdout) {
/*     fprintf(stdout, "%s  FINAL EXPERIMENT TIME: %lld to %lld:  %0.2f thousand clock cycles\n", */
/* 	    COMMENT_STRING, */
/* 	    dataRegion.tmData->startTime, */
/* 	    dataRegion.tmData->endTime, */
/* 	    1.0*(dataRegion.tmData->endTime - dataRegion.tmData->startTime)/1000.0); */

/*     fprintf(stdout, "%s  Number of clock cycles per insert: %0.2f clock cycles. \n", */
/* 	    COMMENT_STRING, */
/* 	    1.0*(dataRegion.tmData->endTime - dataRegion.tmData->startTime)/theArgs->n); */

/*     fprintf(stdout, "%s  Approx. time per insert: %0.6f ms per insert.\n", */
/* 	    COMMENT_STRING, */
/* 	    1000.0*(dataRegion.tmData->endTime - dataRegion.tmData->startTime)/(theArgs->n * 2.4*1e9)); */
  }

  
//  printEventKey(output);
  printUserSystemTimes(theArgs, output);

  fprintf(output, "\n");
  fprintf(output, "%s  Startup overhead on processes in clock cycles \n", COMMENT_STRING);
  fprintf(output, "startupOverhead = [ ");
  for (i = 0; i < theArgs->numProcs; i++) {
    fprintf(output, "%lld,  ", dataRegion.tmData->zeroInsertTime[i] - dataRegion.tmData->startTime);
  }

  fprintf(output, "]; \n");
  fprintf(output, "\n");

  if (theArgs->createOutputFile) {
    fprintf(output, "%s  Timing data:  pid, insert  #  elapsed time (clock cycles) userTime (us)  systemTime(us)  \n", COMMENT_STRING);
    fprintf(output, "timeData = [ \n");
    for (i = 0; i < theArgs->n; i++) {
      fprintf(output, "%3d,  %3d,  %9lld,  %9lld,  %9lld; \n",
	      dataRegion.tmData->mypid[i%theArgs->numProcs],
	      i,
	      dataRegion.timings[i],
	      dataRegion.userTimes[i],
	      dataRegion.systemTimes[i]);
    }
    fprintf(output, "];\n");
      //      assert(dataRegion.keysToInsert[i] == keysToInsert[i]);
  }
  fprintf(output, "\n");

  if (theArgs->createOutputFile) {
    fclose(output);
    if (errno != 0) {
	perror("Waht's teh error here?");
    }
  }
}

#else
//  This generates a more condensed output file...


static void generateOutputDataFile(expArgs* theArgs) {

  int i;
  FILE* output = stdout;


  
  if (theArgs->createOutputFile) {
    output = fopen(theArgs->outputFileName, "w");
    if (output == NULL) {
      printf("Error opening file name %s\n", theArgs->outputFileName);
      theArgs->createOutputFile = FALSE;
      output = stdout;
    }
  }
  
  if (theArgs->createOutputFile) {
      int j;
      timeUnit lastClock;
      long long lastSysTime;
      long long lastUserTime;

      fprintf(output, "%s  Timing data:  pid, insert#, totalElapsed, inc. elapsed time (cycles),  totalUserTime, IncUserTime (us), totalSysTime, incSystemTime(us)  \n", COMMENT_STRING);
      fprintf(output, "timeData = [ \n");

      for (j = 0; j < theArgs->numProcs; j++) {
	  lastClock = dataRegion.tmData->zeroInsertTime[j];
	  lastUserTime = (1000000)*dataRegion.tmData->rusageBeforeArray[j].ru_utime.tv_sec +
	      dataRegion.tmData->rusageBeforeArray[j].ru_utime.tv_usec;
	  lastSysTime = (1000000)*dataRegion.tmData->rusageBeforeArray[j].ru_stime.tv_sec +
	      dataRegion.tmData->rusageBeforeArray[j].ru_stime.tv_usec;

	  for (i = j; i < theArgs->n; i += theArgs->numProcs) {
	      fprintf(output, "%3d,  %3d,  %9lld, %8.3f,   %9lld,  %9lld, %9lld,  %9lld; \n",
		      dataRegion.tmData->mypid[i%theArgs->numProcs],
		      i,
		      dataRegion.timings[i],
		      (1.0e6)*(1.0*dataRegion.timings[i] - lastClock)/(1.4e9), 
		      dataRegion.userTimes[i],
		      dataRegion.userTimes[i] - lastUserTime,
		      dataRegion.systemTimes[i], 
		      dataRegion.systemTimes[i] - lastSysTime);

	      lastClock = dataRegion.timings[i];
	      lastUserTime = dataRegion.userTimes[i];
	      lastSysTime = dataRegion.systemTimes[i];
	  }
      }
      fprintf(output, "];\n");
      //      assert(dataRegion.keysToInsert[i] == keysToInsert[i]);
  }
  fprintf(output, "\n");

  if (theArgs->createOutputFile) {
    fclose(output);
    if (errno != 0) {
	perror("What's teh error here?");
    }
  }
}


#endif



/******************************************************************/
// The section that actually does the b-tree initialization and
//   inserts...


#ifdef USE_BDB

#define ENV_DIRECTORY "TXNAPP"
#define DATABASE "access.db"

DB *dbp;
DB_ENV *global_dbenv;
DB_TXN *global_tid;

static void env_dir_create(void) {
  struct stat sb;

 /* * If the directory exists, we're done. We do not further check * the type of the file, 
 DB will fail appropriately if it's the * wrong type. */
 if (stat(ENV_DIRECTORY, &sb) == 0) return;

 /* Create the directory, read/write/access owner only. */

 if (mkdir(ENV_DIRECTORY, S_IRWXU) != 0) {
   fprintf(stderr, "txnapp: mkdir: %s: %s\n", ENV_DIRECTORY, strerror(errno));
   exit (1);
 }
}

static void env_open(DB_ENV **dbenvp, int isDurable) {
  DB_ENV* tempEnv;
  int ret;
  

 /* Create the environment handle. */
  if ((ret = db_env_create(&tempEnv, 0)) != 0) {
    fprintf(stderr, "txnapp: db_env_create: %s\n", db_strerror(ret));
    exit (1);
  }

 /* Set up error handling. */
  tempEnv->set_errpfx(tempEnv, "txnapp");
  tempEnv->set_errfile(tempEnv, stderr);

  tempEnv->set_cachesize(tempEnv, 0, 10*1024*1024, 2);

 //  dbenv->set_cachesize(dbenv, 0, 1*1024*1024, 2);
//  dbenv->set_mp_mmapsize(dbenv, 100*1024*1024);

  printf("auto_commit enabled\n");
  tempEnv->set_flags(tempEnv, DB_AUTO_COMMIT, 1);

  if (!isDurable) {
    printf("WE have not durable stuff here!!\n");
    
    //      dbenv->set_flags(dbenv, DB_TXN_NOT_DURABLE, 1);
    tempEnv->set_flags(tempEnv, DB_TXN_NOSYNC, 1);
  }


  //Do deadlock detection internally.
  if ((ret = tempEnv->set_lk_detect(tempEnv, DB_LOCK_DEFAULT)) != 0) {
      tempEnv->err(tempEnv, ret, "set_lk_detect: DB_LOCK_DEFAULT");
      exit (1);
  }

 /*
  * Open a transactional environment:
  * create if it doesn't exist
  * free-threaded handle
  * run recovery
  * read/write owner only */
  if ((ret = tempEnv->open(tempEnv, ENV_DIRECTORY, DB_CREATE | DB_INIT_LOCK | DB_INIT_LOG |
			 DB_INIT_MPOOL | DB_INIT_TXN | 
			 DB_RECOVER | DB_THREAD,
			 S_IRUSR | S_IWUSR)) != 0) {
    (void)tempEnv->close(tempEnv, 0);
    fprintf(stderr, "tempEnv->open: %s: %s\n", ENV_DIRECTORY, db_strerror(ret));
    exit (1);
  }

  global_dbenv = *dbenvp = tempEnv; 
}



static int clearDatabase(DB* tempDbp) {
  int ret, numRecs;
  if ((ret = tempDbp->truncate(tempDbp, NULL, &numRecs, 0)) != 0) {
    fprintf(stderr, "db_truncate error: %s\n", db_strerror(ret));
  }
  else {
    printf("Emptied database %s of %d records.\n", DATABASE, numRecs);
  }
  return ret;
}

void initBtree(expArgs* theArgs __attribute__((__unused__))) {
  int ret;
  env_dir_create();
  env_open(&global_dbenv, TRUE);

  if ((ret = db_create (&dbp, global_dbenv, 0)) != 0)    {
      fprintf (stderr, "db_create: %s\n", db_strerror (ret));
      exit (1);
  }
  if ((ret = dbp->open (dbp, NULL, DATABASE, NULL, DB_BTREE, DB_CREATE, 0664)) != 0)   {
      dbp->err (dbp, ret, "%s", DATABASE);
      ret = 1;
      exit(1);
  }
  if ((ret = clearDatabase(dbp)) != 0) {
    exit(1);
  }
  {
      u_int32_t ps;
      dbp->get_pagesize(dbp, &ps);
      printf("What is the default page size?? %d\n", ps);
  }

#ifndef START_EMPTY
 {
     rtimeStruct t1, t2;
     checkCycleCount(&t1);
     doBulkInserts(firstInserts, BASE_INSERTS);
     checkCycleCount(&t2);


     printf("The time to do %d BASE INSERTS: %0.4f ms\n",
	    BASE_INSERTS,
	    (1.0e3 * (t2 - t1)) / 1.4e9);     
 }
#endif
}

void cleanupBtree(expArgs* theArgs __attribute__((__unused__))) {
  int t_ret, ret;

  printf("Clearing the database at the end!\n");
  clearDatabase(dbp);
  if ((t_ret = dbp->close (dbp, 0)) != 0 && ret == 0)
    ret = t_ret;
}

void doActualInsert(unsigned long r) {

#define MAXIMUM_RETRY 100
  int ret, fail;
  ACTUAL_KEY key = (ACTUAL_KEY)r;
  BLOCKNUM value = (BLOCKNUM)r;

//  ACTUAL_KEY* tempKeyPtr = (ACTUAL_KEY*)malloc(sizeof(ACTUAL_KEY));
  ACTUAL_KEY* tempKeyPtr = (ACTUAL_KEY*)malloc(TEST_KEY_SIZE);
  BLOCKNUM* tempBlockPtr = (BLOCKNUM*)malloc(sizeof(BLOCKNUM));
  
  DBT dbkey, dbdata;

  *tempKeyPtr = key;
  *tempBlockPtr = value;
  
  memset (&dbkey, 0, sizeof (dbkey));
  memset (&dbdata, 0, sizeof (dbdata));

  dbkey.data = tempKeyPtr;
//  dbkey.size = sizeof(ACTUAL_KEY);
  dbkey.size = TEST_KEY_SIZE;
  //  dbkey.flags = DB_DBT_REALLOC;

  dbdata.data = tempBlockPtr;
  dbdata.size = sizeof(BLOCKNUM);
  //  dbdata.flags = DB_DBT_REALLOC;


  for (fail = 0; fail++ <= MAXIMUM_RETRY &&
	 (ret = dbp->put(dbp, NULL, &dbkey, &dbdata, DB_AUTO_COMMIT)) == DB_LOCK_DEADLOCK;) {
    printf("Aborted trying to insert (%lld, %u) on count %d\n", key, value, fail);
  }
}

void doBulkInserts(unsigned long* dataArray, int n) {
  // THIS CODE DOESN'T WORK! 
  int ret, fail;
  int i;
  ACTUAL_KEY key; 
  BLOCKNUM value; 
  ACTUAL_KEY* tempKeyPtr; 
  BLOCKNUM* tempBlockPtr; 
  DBT dbkey, dbdata;

  tempKeyPtr = (ACTUAL_KEY*)malloc(sizeof(ACTUAL_KEY) * n);
  tempBlockPtr = (BLOCKNUM*)malloc(sizeof(BLOCKNUM) * n);

//  printf("Bulk insert with dataArray = %p, n = %d\n", dataArray, n);
  for (i = 0; i < n; i++) {
    key = (ACTUAL_KEY) dataArray[i];
    value = (BLOCKNUM) dataArray[i];
    tempKeyPtr[i] = key;
    tempBlockPtr[i] = value;    
  }

  // assert(errno == 0);
  for (fail = 0; fail <= MAXIMUM_RETRY; fail++) {
    ret = global_dbenv->txn_begin(global_dbenv, 0, &global_tid, 0);
    assert(ret==0);

    for (i = 0; i < n; i++) {
      memset (&dbkey, 0, sizeof (dbkey));
      memset (&dbdata, 0, sizeof (dbdata));
      dbkey.data = &tempKeyPtr[i];
      dbkey.size = sizeof(ACTUAL_KEY);
      dbdata.data = &tempBlockPtr[i];
      dbdata.size = sizeof(BLOCKNUM);
      

      ret = dbp->put(dbp, global_tid, &dbkey, &dbdata, 0);
      if (ret != 0) { goto abort; }
    }


    ret = global_tid->commit(global_tid, 0);
    if (ret != 0) { goto again; }
    goto done;
  abort:
    global_tid->abort(global_tid);
  again:
    printf("Aborted trying to insert (%lld, %u) on count %d\n", key, value, fail); 
  }

 done:
    ret = 0;
}

void perProcessCleanup(expArgs* theArgs __attribute__((__unused__))) {
    
}
#endif

#ifdef NO_CONFLICT_TEST

void doActualInsert(unsigned long r __attribute__((__unused__))) {
}


#else

#ifndef USE_BDB
DATABASE db;
cobtree* ctree;

void initBtree(expArgs* theArgs) {

#ifndef START_EMPTY
    rtimeStruct t1, t2;
#endif

#ifndef USE_PMA
  // This function calls openXactionManager inside...
  db = open_db(theArgs->dataFileName);
  init_db(db);
#else
  ctree = (cobtree*) init_cob_tree(theArgs->dataFileName);
  printf("The initial PMA? \n");
  pma_print_array(ctree);
  printf("************************\n");
#endif

#ifndef START_EMPTY
  checkCycleCount(&t1);
  doBulkInserts(firstInserts, BASE_INSERTS);
  checkCycleCount(&t2);

  printf("The time to do %d BASE INSERTS: %0.4f ms\n",
	 BASE_INSERTS,
	 (1.0e3 * (t2 - t1)) / 1.4e9);
#endif
}

void doActualInsert(unsigned long r) {
#ifndef USE_PMA
  btree_insert(db, (ACTUAL_KEY)r, (BLOCKNUM)r);
#else
  pma_insert(ctree, (ACTUAL_KEY)r, (BLOCKNUM)r);

 //  printf("Inserting key %llu\n", (ACTUAL_KEY)r);
/*    printf("PMA ARRAY?  \n");  */
/*    pma_print_array(ctree);  */
/*    printf("*******************\n");  */

#endif
}

void doBulkInserts(unsigned long* dataArray, int n) {
    int i;
    int error = 1;
    while (error != 0) {
	xbegin();
	for (i = 0; i < n; i++) {

//	    printf("Inserting from %lu from address %p\n", dataArray[i], &dataArray[i]);
#ifndef USE_PMA
	    btree_insert(db,
			 (ACTUAL_KEY)dataArray[i],
			 (BLOCKNUM) dataArray[i]);
#else
	    pma_insert(ctree,
		       (ACTUAL_KEY)dataArray[i],
		       (BLOCKNUM) dataArray[i]);
#endif
	}
	error = xend();
//	printf("end of bulk\n");
    }
}

void verify_inserts(expArgs* theArgs) {
  int i;
  int answer;
  int num_errors = 0;

  ACTUAL_KEY min_val, max_val;
  
  unsigned long long range_sum = 0;

  min_val = (ACTUAL_KEY)keysToInsert[0];
  max_val = (ACTUAL_KEY)keysToInsert[0];


  for (i = 0; i < theArgs->n; i++) {

    ACTUAL_KEY temp = (ACTUAL_KEY)keysToInsert[i];
    range_sum += ((BLOCKNUM)keysToInsert[i]);

    if (temp < min_val) min_val = temp;
    if (temp > max_val) max_val = temp;        
  }

  printf("min_val is %llu. Max_val is %llu\n", min_val, max_val);
  printf("The range sum is %llu\n", range_sum);
  
  BLOCKNUM value;
  for (i = 0; i < theArgs->n; i++) {
    //    printf("Searching for key %lu\n", keysToInsert[i]);
#ifndef USE_BDB
#ifdef USE_PMA
    {
      long long int val;
      answer = pma_search(ctree, (ACTUAL_KEY)keysToInsert[i], &val);

      value = (BLOCKNUM)val;
    }
#else

    // Normal btree search:
    answer = btree_search(db, (ACTUAL_KEY)keysToInsert[i], &value);
    // Check that it was found
#endif
    
#else
    // Bekerely DB.  For now, just assume its right...
    answer = 0;
    value = (BLOCKNUM)value;
#endif
    if (answer != 0) {
      printf("ERRROR! key %llu not found...\n", (ACTUAL_KEY)keysToInsert[i]);
      num_errors++;
    }
    else {
      assert(value == ((BLOCKNUM)keysToInsert[i]));    
    }
  }

  printf("ERRORS!!! We found %d errors out of %d\n", num_errors, theArgs->n);

#ifdef USE_PMA
  {
    unsigned long long test_sum = 0;
    test_sum = (unsigned long long)getRangeSum(ctree, min_val-1, max_val+1);
    printf("What is test_sum? %llu\n", test_sum);
    printf("What is range_sum? %llu\n", range_sum);
    assert(test_sum == range_sum);
  }
#else
#ifndef USE_BDB

  // Using the normal btree.
 {
   unsigned long long test_sum = 0;
   unsigned long  number_leaves;
   test_sum = (unsigned long long)(btree_range_query_all_sum(db, &number_leaves));

   printf("How many leaves did we find? %lu.  we should get %d\n",
	  number_leaves, theArgs->n);
   assert((int)number_leaves == theArgs->n);
   printf("What is the test sum? %llu\n", test_sum);
   printf("What should the range_sum be? %llu\n", range_sum);
   assert(test_sum == range_sum);				      
 }

#endif
  
#endif
}

// Run before individual processes exit.
void perProcessCleanup(expArgs* theArgs) {
    reportStatsOnProcess();
    printf("Number of xactions aborted on  process %d:  %d\n",
	   getpid(),
	   reportNumInsertsAborted());
  xMunmap(theArgs->dataFileName);
}

// Run by the last process.
void cleanupBtree(expArgs* theArgs) {
  xMunmap(theArgs->dataFileName);
  assert(errno == 0);
  xShutdown();
}

#endif
#endif

/***************************************************************************/
// The main function that actually runs the test.


int main(int argc, char* argv[]) {
  expArgs theArgStruct;
  expArgs* theArgs = &theArgStruct;
  rtimeStruct tempT;
  timeStruct t1, t2;



  // Get the arguments
  getArgs(argc, argv, theArgs);

  // generate the data to insert.
  generateInsertData(theArgs); 

  createSHMRegion(*theArgs);
  
  // Get the initial time.
  initBtree(theArgs);
  checkTimer(&t1);
  checkCycleCount(&tempT);
  dataRegion.tmData->startTime = tempT;

  
  startProcesses(theArgs->numProcs);
  dataRegion.ready[myProcNum] = 1;

  while (!everyoneReady(theArgs->numProcs)) {
  }

  //  printf("Everyone done. Process %d (myProcNum = %d) .\n", getpid(), myProcNum);
  doInserts(myProcNum, theArgs);
  
  waitForChildrenToFinish();
  if (myPid != rootPid)  {

    perProcessCleanup(theArgs);
    detachFromSharedRegion();
    exit(0);
  }


  // Get the final time.
  checkCycleCount(&tempT);
  dataRegion.tmData->endTime = tempT;
  checkTimer(&t2);

  
  // Generate output data
  generateOutputDataFile(theArgs);

  // Do final verification that we only have one process here...
//  printf("How many processes get here? shouldbe only one... \n");
//  printf("THE PROCESS %d has procNum %d!!! \n", getpid(), myProcNum);


  reportTime("FinalAvgInsertTime", timeDiff(t1, t2), theArgs->n);


#ifdef VERIFY_INSERTS
  printf("Verifying the insertions...\n");
  verify_inserts(theArgs);
#endif  


  printf("####### %d,   %d,   %0.6f,  %0.6f;  \n",
	 theArgs->n,
	 theArgs->numProcs,
	 timeDiff(t1, t2),
	 theArgs->n * 1.0 /timeDiff(t1, t2));
  
  cleanupInsertData();  
  cleanupBtree(theArgs);
  destroySHMRegion();

  return 0;
}
