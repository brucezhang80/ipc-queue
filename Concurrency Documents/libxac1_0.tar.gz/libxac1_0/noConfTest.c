/*************************************************************************
 *
 *  Search tree test code 
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * noConfTest.c
 *
 *  Test program performing a simple transaction.
 *  (in place of a B-tree insert in btTester)
 */


#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>


#include "libxac.h"
#include "btTester.h"



int globalFd; 
void* theFileRegion;

void initBtree(expArgs* theArgs  __attribute__((__unused__))) {
    int i;
    int numPages = K*theArgs->numProcs;
    char emptyPage[PAGESIZE];
    globalFd = creat("noConf.xdt", 0666);
    assert(globalFd != -1);

    memset((void*)emptyPage, 0, PAGESIZE);

    for (i = 0; i < numPages; i++) {
	write(globalFd, emptyPage, PAGESIZE);
    }

    close(globalFd);


    xInit(LIBXAC_DEFAULT_PATH, TRUE);

    theFileRegion = xMmap("noConf.xdt", K*theArgs->numProcs);
    printf("SETUP The file. \n");
    assert((int)(size_t)theFileRegion != -1);
}

int numAborts = 0;

void performOperation(int myPNum, int numProcs) {
    char* temp = (char*)theFileRegion;
#ifdef USE_ADVISORY
    void* addr;
#endif
    int i;
    int error = 1;
    while (error != 0) {
	xbegin();
	for (i = 0; i < K; i++) {
#ifdef USE_ADVISORY

	    addr = (void*)((size_t)temp + PAGESIZE*(i*numProcs + myPNum));
//	    printf("Calling set page acces on addr %p.  SHould be page %zd\n", addr, ((size_t)(addr) - (size_t)temp)/PAGESIZE);
	    xAdvisory(addr, FALSE);
//	    printf("Finished set page acces on addr %p.  SHould be page %zd\n", addr, ((size_t)(addr) - (size_t)temp)/PAGESIZE);
	    assert(errno == 0);
#endif	    
//	    printf("Starting increment at index %d.\n", PAGESIZE*(i*numProcs+myPNum));
	    temp[PAGESIZE*(i*numProcs + myPNum)]++;
//	    printf("Starting increment at index %d.\n", PAGESIZE*(i*numProcs+myPNum));

	}
	error = xend();
	if (error == 1) {
	    numAborts++;
	}
    }

}

// Run before individual processes exit.
void perProcessCleanup(expArgs* theArgs __attribute__((__unused__))) {
    int mypid = getpid();
    printf("Number of aborts on process %d: %d\n", mypid, numAborts);
    xMunmap("noConf.xdt");
    printf("Executing on process %d\n", mypid);
    assert(errno == 0);
}

// Run by the last process.
void cleanupBtree(expArgs* theArgs __attribute__((__unused__))) {
    xMunmap("noConf.xdt");    
    xShutdown();
}

