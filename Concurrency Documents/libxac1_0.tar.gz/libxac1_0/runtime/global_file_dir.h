/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * global_file_dir.h
 *
 */

#ifndef __GLOBAL_FILE_DIR_H
#define __GLOBAL_FILE_DIR_H

#include "file_defs.h"
#include "lbxc_malloc.h"

#include <string.h>

// B parameter -- should be even (and to be safe, at least 4?)
#define GFD_B 8


// A b-tree block..
typedef struct global_file_dblock {
  int num_keys;
  global_file_info keys[GFD_B-1];
  OFFSET_PTR children[GFD_B];
  int is_leaf;  
} global_file_dblock;

typedef struct global_file_directory {
  int num_files;
  OFFSET_PTR root_block;

} global_file_directory;



static inline void key_copy(global_file_info* k1, global_file_info* k2) {
  memcpy((void*)k1, (void*)k2, sizeof(global_file_info));
}


void init_global_file_dir(global_file_directory* gfd);

void insert_key_into_gfd(global_file_directory* gfd,
			 global_file_info* new_key);
void print_global_file_directory(global_file_directory* gfd);

void key_print(global_file_info* k1);



// Returns 1 if file info with key stored in elem is found,
//  0 otherwise.
int find_key_in_gfd(global_file_directory* gfd,
		    global_file_info* elem);


int delete_key(global_file_directory* gfd,
	       global_file_info* key);



#endif
