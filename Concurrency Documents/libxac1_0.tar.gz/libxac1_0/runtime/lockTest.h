/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * lockTest.h
 *
 *  Implements locks used in the Libxac runtime.
 *   These methods were stolen from Cilk... see
 *   cilk-sysdep.h for more info.
 *  
 *  Jim
 */

#ifndef LOCK_TEST_H
#define LOCK_TEST_H

#include "cilk-sysdep.h"
#include <sched.h>

#define ENABLE_LOCKS 1

/*
 *  Ensure that all previous writes are globally visible before any
 *  future writes become visible.
 */
static inline void Cilk_membar_StoreStore(void)
{
     CILK_WMB();
}



/***********************************************************\
 * locks
\***********************************************************/
typedef volatile int Cilk_lockvar[1];

static inline void Cilk_lock_init(Cilk_lockvar v)
{
     v[0] = 0;
}



static inline void Cilk_lock(Cilk_lockvar v)
{
    int numFailures = 0;
#if ENABLE_LOCKS == 1
  //     while (Cilk_xchg((int *)v, 1) != 0) {
     while (Cilk_xchg(v, 1) != 0) {
	  while (v[0]) {
	      numFailures++;
	      if ((numFailures) % 100 == 99) {
		  sched_yield();
	      }
	  }  /* spin using only reads - reduces bus traffic */
     }
#endif
}




static inline void Cilk_unlock(Cilk_lockvar v)
{
#if ENABLE_LOCKS == 1 
     Cilk_membar_StoreStore();
     v[0] = 0;
#endif
}



#endif
