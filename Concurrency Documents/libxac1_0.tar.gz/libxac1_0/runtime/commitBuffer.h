/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * commitBuffer.h
 * 
 *  commitBuffer.h describes the code that manages the buffer
 *   we use when performing a group commit.
 */


#ifndef __COMMIT_BUFFER_H
#define __COMMIT_BUFFER_H



#include "basics.h"
#include "lockTest.h"
#include "xStats.h"

#include <sys/time.h>


#define MAX_GLOBAL_BUFFER MAX_PAGES

#define BUFFER_FILE_NAME_SIZE 35

typedef struct globalCommitBuffer {
  int bufferNumber;   // either 1 or 2
  size_t length;      // The length in the buffer we are actually using
  size_t maxLength;   // The maximum size of the buffer
  
  char bufferName[BUFFER_FILE_NAME_SIZE];  // The name of the file being used as the buffer


  
  Cilk_lockvar primaryBufferLock;
  Cilk_lockvar primaryMetaBufferLock;
  int primaryBufferLockHeld;


  Cilk_lockvar secondaryBufferLock;

  int xQueueWaiting[MAX_XACTIONS+1];
  int xQueueRunning[MAX_XACTIONS+1];


  struct timeval lastSyncTime;
  

} globalCommitBuffer;


void initGlobalBuffer(globalCommitBuffer* gcbf, const char* path, int bufferNum);


#define DEFAULT_NUM_EVENTS 10000

typedef struct {
    eventType etType;
    rtimeStruct ts;  // time stamp
    int xId;       // my transaction id
} eventRecord;


#define MAX_LOCAL_BUFFER (PAGESIZE*10)

typedef struct localCommitBuffer {


  // Links to the global commit buffer
  //  Cilk_lockvar* globalBufferLock;
  int commitBufferFd;  
  void* commitBufferRegion;
  int localMmapLength;



  // Structures for a local buffer...
  size_t currentLength;
  size_t currentMax;
  void* buffer;


    int numEventsRecorded;
    int eventBufferSize;
    eventRecord* allEvents;


#ifdef GATHER_STATS
    int numStatsRecorded;
    int statBufferSize;
    xactionStats* allStats;
#endif

} localCommitBuffer;



localCommitBuffer* createLocalCommitBuffer(globalCommitBuffer* gcbf);
void addDataToLocalBuffer(localCommitBuffer* lcbf, void* data, size_t numBytes);
void* getLocalBufferPointer(localCommitBuffer* lcbf);
int getLocalBufferLength(localCommitBuffer* lcbf);
void clearLocalBuffer(localCommitBuffer* lcbf);
void destroyLocalCommitBuffer(localCommitBuffer* lcbf);


void emptyLocalIntoGlobalBuffer(localCommitBuffer* lcbf,
				globalCommitBuffer* gcbf);




void clearGlobalBuffer(localCommitBuffer* lcbf,
		       globalCommitBuffer* gcbf);


inline void acquireSecondaryBufferLock(globalCommitBuffer* gcbf);
inline void releaseSecondaryBufferLock(globalCommitBuffer* gcbf);

int addIdToWaitersList(globalCommitBuffer* gcbf,
		       int myId);

// These last two functions should be called only
//  when holding the primary buffer lock.

int clearAllRunningIds(globalCommitBuffer* gcbf,
		       localCommitBuffer* lcbf);
void changeStatusOnWaitersToStarted(globalCommitBuffer* gcbf,
				    localCommitBuffer* lcbf);
void printAllWaiters(globalCommitBuffer* gcbf);


int stillWaiting(globalCommitBuffer* gcbf, int myId);

int stillWaitingOrRunning(globalCommitBuffer* gcbf,
			  int myId);
int stillRunning(globalCommitBuffer* gcbf,
		 int myId);



inline int tryToAcquirePrimaryBufferLock(globalCommitBuffer* gcbf);
inline void acquirePrimaryBufferLock(globalCommitBuffer* gcbf );
inline void releasePrimaryBufferLock(globalCommitBuffer* gcbf );



void setEventLogName(char* newName);
void addEventToLocalBuffer(localCommitBuffer* lcbf,
			   int myXid,			
			   eventType e);
void printEventKey(FILE* f);

#ifdef GATHER_STATS
void addStatToLocalBuffer(localCommitBuffer* lcbf,
			  xactionStats* xs);

void setStatLogName(char* newName);

#endif
#endif
