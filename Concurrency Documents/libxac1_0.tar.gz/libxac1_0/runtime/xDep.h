/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xDep.h
 *
 *  Maintains the dependency tree (used for concurrency control
 *   of transactions)
 */

#ifndef XDEP_H
#define XDEP_H

#include "basics.h"
#include "globalTypes.h"

void outputDepList(xDepList* w);
void outputDepTree(xDepTree* t);
void initDepTree(xDepTree* t);

void addPending(xDepTree* t, int id, int parent);
int failXaction(xDepTree* t, int id);
int commitXaction(xDepTree* t, int id);
int abortXaction(xDepTree* t, int id);
int mergeIntoParent(xDepTree* t, int id);
int movePendingDepList(xDepTree*t, int sourceId, int destId);


void addReadOnly(xDepTree* t, int id, int parent);
int commitReadOnly(xDepTree* t, int id);

int validDepList(xDepTree* t, int indx);
int validDepTree(xDepTree* t);

/**
 * If id is a committed transaction, it returns
 *  the committed child of id.
 * If id is a PENDING transaction, it returns the
 *  the committed child of id's parent.
 */
int getCommittedChild(xDepTree* t, int id);
int getCommittedParent(xDepTree* t, int id);

void movePendingListToEnd(xDepTree* t, int id);
int hasActiveChildren(xDepTree* t, int id);


int lastCommittedXaction(xDepTree* t);


/**************************************************************/
// Functions for garbage collection of the tree.

// Returns the youngest (committed) transaction, starting at 
//  id, that has an active child.  This is the transaction 
//  that will get merged into id, if id has no active children.
int forwardActiveChildrenQuery(xactionContext* xc,  int id) ;

// Returns the oldest transaction, starting at id, that
// has no active children.  This corresponds to the transaction
//  we are going to merge id into.
int backwardActiveChildrenQuery(xactionContext* xc, int id); 

void collapseRangeBackward(xactionContext* xc, int id);


#endif
