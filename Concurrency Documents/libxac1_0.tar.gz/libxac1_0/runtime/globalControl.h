/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * globalControl.h
 *
 *  Manages the global control file that Libxac uses.
 */


#ifndef __GLOBAL_CONTROL_H
#define __GLOBAL_CONTROL_H


#include "lbxc_math.h"
#include "lbxc_malloc.h"
#include "globalTypes.h"

typedef struct cfile_ptrs {

  OFFSET_PTR xcGlobalLock;

#ifdef USE_LSN
  OFFSET_PTR lsn_num_lock;
  OFFSET_PTR lsn_counter;
  OFFSET_PTR lsn_last_committed;
  
#endif

  // Transaction record structs.
  OFFSET_PTR actualTransactionArray;
  OFFSET_PTR actualXactionArrayInUse;
  OFFSET_PTR actualXInfoFLStruct;  

  // Page to transaction tables.
  OFFSET_PTR actualPageToXactionReads;
  OFFSET_PTR actualPageToXactionWrites;
 
  // Dependency tree
  OFFSET_PTR actualT;


  // Page directory pointer
  OFFSET_PTR actualMmap;
  OFFSET_PTR actualGLF;
  
  OFFSET_PTR actualLogManagerLock;

  // Global commit buffer
  OFFSET_PTR actualGCBF;

  OFFSET_PTR actualGFileDir;
} cfile_ptrs;



/**
 * This creates a transactional control file for
 *  the file wih the specified name,
 * Returns 0 if completed successfully, -1 on error
 */
int setupControlFile(const char* fileName, int is_durable);


/**
 * Takes in the name of the file we want to work on transactionally.
 * Opens the corresponding control file, and mmaps the control region
 *   so this process can access it.
 * This function assumes the control file has already been initialized.
 * Function returns an xactionContext object containing pointers
 *  into the control file region.
 */
xactionContext* attachControlRegion(void);


/**
 * This function is called after we have finished accessing the control
 *  file.  Munmaps the control region and closes the control file.
 */
void detachControlRegion(xactionContext* xc);


// If I want to malloc or free something from control region.
//  This function returns an offset.
OFFSET_PTR cfile_malloc(size_t size, xactionContext* xc);
int cfile_free(OFFSET_PTR p, xactionContext* xc);


void acquireGlobalLock(xactionContext* xc);
void releaseGlobalLock(xactionContext* xc);
int verifyGlobalIsLocked(xactionContext* xc);


#ifdef USE_LSN
void getNextLSN(xactionContext* xc);
int tryToUpdateLSNLastCommitted(xactionContext* xc);
void updateLSNLastCommitted(xactionContext* xc);
#endif



#endif
