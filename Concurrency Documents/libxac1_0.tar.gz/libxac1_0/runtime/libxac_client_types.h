/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * libxac_client_types.h
 *
 */


#ifndef __LIBXAC_CLIENT_TYPES_H
#define __LIBXAC_CLIENT_TYPES_H



#include "basics.h"
#include "commitBuffer.h"
#include "cycle_counter.h"
#include "file_manager.h"
#include "lockTest.h"
#include "xactionNodeList.h"


//#include "local_file_dir.h"

// Local state information that every process/client stores.

typedef struct xaction_local_context {

  localCommitBuffer* lcbf;  // The local commit buffer
  mappedFileData* mfd;

  int insideXaction;
  int xactionNestCounter;
  TID currentXId;

  unsigned long long myLSN;

  // Trash storage for the queue of pages to unmap
  unmapQueue pagesToUnmap;
  
  int isDurable;
  int isReadOnlyXaction;
  int pid;

  // For collecting statistics....
  int numAborts;


#ifdef COUNT_STATS
  int numXactions;
  int numPagesRead;
  int numPagesWritten;
#endif

#ifdef DO_TIMINGS
  
  timeStruct pageT1;
  timeStruct pageT2;
  double pageTime;
  int numPageCounts;
  double maxWriteTime;

  timeStruct otherT1;
  timeStruct otherT2;
  double otherTime;
  double maxOther;
  int numOthers;

  timeStruct uSync1;
  timeStruct uSync2;
  int numUSyncs;
  double uSyncTime;
  double maxUSyncTime;

  timeStruct syncTS1;
  timeStruct syncTS2;
  double syncTime;
  int numSyncs;
  double maxSyncTime;

  int numLocks;
  double lockTime;
#endif

#ifdef GATHER_STATS
    xactionStats xs;
#endif    


  
} xaction_local_context;


#endif
