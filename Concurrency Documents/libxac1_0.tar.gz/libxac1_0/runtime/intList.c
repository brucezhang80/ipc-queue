/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * intList.c
 *
 *  Maintains a sorted list of integers in a packed array.
 *   Not efficient. (i.e., insert is O(n^2), search is O(lg n))
 */

#include "intList.h"

/**
 * Private helper function.
 * array is an integer array, length is a pointer to its length field.
 * Returns the index in the array where x is,
 *  or the index where it would fit in
 *  sorted order.
 * If the new element x satisfies array[a] < x < array[a+1],
 *  we return the index (a+1).
 */
static inline int findIndexInListHelper(int* array, int* length, int x) {
  int lo = 0;
  int hi = *length;
  int med = (lo + hi)/2;

  while (lo <= hi) {
    med = (lo + hi)/2;
    //    printf("lo,med, hi is %d %d %d\n", lo, med, hi);

    if (array[med] > x) {
      hi = med-1;
    }
    else {
      if (array[med] < x) {
	lo = med+1;
      }
      else {
	return med;
      }
    }
  }

  // The case where we didn't find the value.
  //  Then, return the index in the array where
  //  the new value should go.  
  while ((array[med] < x) &&
	 (med < *length)) {
    med++;
  }

  return med;
}


/**
 * Adds x to the array, if it isn't already there.
 * Returns -1 if there is an error, 0
 *  otherwise.
 * Does not check to see if there is space in the array. This must
 *   be done before.
 */
inline int addIntToList(int* array, int* length, int x) {
  int i;
  int movCount;
  assert(x >= 0);

  i = findIndexInListHelper(array, length, x);
  //    printf("The index when adding number %d: %d\n", x, i);


  // Check to see if we already contain the page.
  if (array[i] == x) {
    // Already have it. Just check to see if it was
    //  on the end of the array (in this case,
    //  we need to increment the length
    if (i == *length) {
      (*length)++;
    }
    return 0;
  }
  

  for (movCount = *length; movCount >= i+1; movCount--) {
    // Shift everything else over by 1.
    array[movCount] = array[movCount-1];
  }
  array[i] = x;
  (*length)++;
  
  return 0;
 
}


// Returns TRUE if the page is in the list. FALSE
//  otherwise.
inline int containsInt(int* array, int* length, int x) {
  int i = findIndexInListHelper(array, length, x);
  //  printf("Finding page index for %d: it is %d\n", x, i);
  return ((i < *length) &&
	  (array[i] == x));

}




/** Returns TRUE if we removed x from the array **/
inline int removeIntFromList(int* array, int* length, int x) {
  int movCount;
  int i = findIndexInListHelper(array, length, x);

  //      printf("Index for removing %d  is: %d\n", x, i);

  if ((array[i] != x)) {
    fprintf(stderr, "Not finding %d\n", x);
    return FALSE;
  }
  else {
    for (movCount = i+1; movCount < *length; movCount++) {
      // Shift everything else over by 1.
      array[movCount-1] = array[movCount];
    }

    (*length)--;
    return TRUE;
  }
}
