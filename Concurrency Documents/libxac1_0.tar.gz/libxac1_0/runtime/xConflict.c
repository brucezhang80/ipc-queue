/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xConflict.c
 *
 *  Implements conflict-resolution functions (i.e.,
 *   decide which transaction to abort)
 */

#include "xConflict.h"

#include "xactionNodeList.h"
#include "xactionHelpers.h"
#include "xDep.h"

extern xactionContext* currentXC;

/**
 * When we fail a transaction, we remove the pages it
 *  has accessed from the page->transaction map, so
 *  it won't conflict with anyone else.
 * Note that this function can be called from any process,
 *  not necessarily the process that is running transaction
 *  "id"
 */
static inline void handleXactionFail(int id) {  

  if (getXactionStatus(currentXC, id) == PENDING) {
    setXactionStatus(currentXC, id, FAILED);
#if XACTION_PRINT == 1
    fprintf(stderr, "Failing transaction %d\n", id);
#endif

    failXaction(currentXC->t, id);
  
    // Iterate through the transaction's read and write sets,
    //  remove all its pages from the page->transaction lists.
    removeReadSetFromPageToReaderMap(currentXC, id);
#if XACTION_PRINT == 1
    fprintf(stderr, "Removed readSet for %d\n", id);
#endif

    removeWriteSetFromPageToWriterMap(currentXC, id);
#if XACTION_PRINT == 1
    fprintf(stderr, "Removed writeSet for %d\n", id);
#endif
  }
  else {
    // Make sure its already failed...
    assert(getXactionStatus(currentXC, id) == FAILED);
  }
}


// Fail the current transaction if there is another writer already.
static inline int simpleReadConflict(int id, int pageNumber) {
  if (getNumWriters(currentXC, pageNumber) != 0) {
#if XACTION_PRINT == 1
    fprintf(stderr, "There is a writer for page %d\n", pageNumber);
    fprintf(stderr, "The list of writers is:");
    printNodeList(getWriters(currentXC, pageNumber));
    fprintf(stderr, "\n");
#endif

    // Fail the transaction if it hasn't failed already.
    //      if (getXactionStatus(currentXId) == PENDING) {
    handleXactionFail(id);
    return TRUE;
    //      }
  }

  return FALSE;
}

static inline int simpleWriteConflict(int id, int pageNumber, int idIsReader) {
  int numReaders = getNumReaders(currentXC, pageNumber);
  int numWriters = getNumWriters(currentXC, pageNumber);

  if ((numWriters >= 1) || (numReaders > (idIsReader==TRUE))) {
    //  if ((getNumReaders(currentXC, pageNumber) + getNumWriters(currentXC, pageNumber)) > 1) {
#if XACTION_PRINT == 1
    fprintf(stderr, "Already reading. There is a writer for page %d\n", pageNumber);

    printf("NumWriters is %d.  NumReaders is %d, isIsReader is %d\n",
	   numWriters, numReaders, idIsReader);
    fprintf(stderr, "The list of writers is:");
    printNodeList(getWriters(currentXC, pageNumber));
    fprintf(stderr, "\n");
#endif

    handleXactionFail(id);
    return TRUE;
  }
  return FALSE;
}


// Returns TRUE if tranaction "id" is the one that fails.
static inline int timeStampReadConflict(int id, int pageNumber) {

  int idFailed = FALSE;
  if (getNumWriters(currentXC, pageNumber) != 0) {
    nodeListIterator  temp;
    nodeListIterator* it = &temp;
    int writerId;

    xactionNodeList* writers = getWriters(currentXC, pageNumber);
    
    assert(getNumWriters(currentXC, pageNumber) == 1);

    resetNodeListIterator(writers, it);
    
    writerId = getCurrentNode(writers, it);


    // Fail whoever came later, except if the other transaction is already committed.
    if ((getXactionFromId(currentXC, id)->timeStamp < getXactionFromId(currentXC, writerId)->timeStamp)
	&& (getXactionStatus(currentXC, writerId) != COMMITTED)) {

      handleXactionFail(writerId);
      return FALSE;
    }
    else {

//      printf("Read: Transaction %d failing on page number %d\n", id, pageNumber);

      handleXactionFail(id);
      return TRUE;
    }      
  }
  
  return idFailed;
}

// Returns TRUE if id is the transaction that fails.
static inline int timeStampWriteConflict(int id, int pageNumber, int idIsReader) {
  if (getNumWriters(currentXC, pageNumber) != 0) {
    // If its another writer, we can do the same thing as
    //  if this were a read: abort the one who came later.
    return timeStampReadConflict(id, pageNumber);
  }
  else {
    // I should be one of the readers.  Check to see if there is more than
    //  one reader.
    if (getNumReaders(currentXC, pageNumber) > (idIsReader == TRUE)) {

      nodeListIterator temp;
      nodeListIterator* it = &temp;
      int myStamp;
      int currentId;
      int writerIsOldest = TRUE;
      int someReaderIsCommitted = FALSE;
      xactionNodeList* readers = getReaders(currentXC, pageNumber);

      myStamp = getXactionFromId(currentXC, id)->timeStamp;

      resetNodeListIterator(readers, it);

      while (!endOfNodeList(readers, it)) {
	currentId = getCurrentNode(readers, it);
	if (getXactionFromId(currentXC, currentId)->timeStamp < myStamp) {
	  // One of the readers is earlier than me.  Fail myself.
	  //  Note that I will be one of the readers, and I won't be
	  //  earlier than myself.
	  writerIsOldest = FALSE;
	  handleXactionFail(id);
	  return TRUE;
	  //	  break;
	}
	else {
	  // If one of the readers is committed.
	  if (getXactionStatus(currentXC, currentId) == COMMITTED) {
	    someReaderIsCommitted = TRUE;
//	    printf("Write: Transaction %d failing on page number %d\n", id, pageNumber);
	    handleXactionFail(id);
	    return TRUE;
	  }
	}

	advanceNodeListIterator(readers, it);
      }

      if ((writerIsOldest) && (!someReaderIsCommitted)) {
	// Fail all the readers instead.
	resetNodeListIterator(readers, it);

	while (!endOfNodeList(readers, it)) {
	  currentId = getCurrentNode(readers,it);
	  if (currentId != id) {
	    handleXactionFail(currentId);
	  }
	  advanceNodeListIterator(readers, it);
	}
      }
      else {
	// One of those should have been true
	assert(FALSE);
      }
    }
    return FALSE;
  }
}

/**
 * Called when transaction "id" is reading the specified
 *  page for the first time.
 * This will fail the appropriate transactions before
 *  going forward.
 */
int findReadConflicts(int id, int pageNumber, AbortPolicy pol) {
  switch (pol) {
  case TIME_STAMP:
    return timeStampReadConflict(id, pageNumber);
    //    break;
  case SIMPLE:
  default:
    return simpleReadConflict(id, pageNumber);
  }
}


/**
 * Called when transaction "id" is writing the specified
 *  page for the first time.
 * This will fail the appropriate transactions before
 *  going forward.
 * Has an additional flag: isIsAReader means the transaction
 *   is known to be a reader of this page.
 */
int findWriteConflicts(int id, int pageNumber, AbortPolicy pol, int idIsReader) {
  switch (pol) {
  case TIME_STAMP:
    return timeStampWriteConflict(id, pageNumber, idIsReader);
    //    break;
  case SIMPLE:
  default:
    return simpleWriteConflict(id, pageNumber, idIsReader);
  }
}


AbortPolicy currentAbortPolicy(xactionContext* xc __attribute__((__unused__))) {
    return TIME_STAMP;
//    return SIMPLE;
}
