/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2006    Massachusetts Institute of Technology
 * Copyright (c) 2006    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * lbxc_math.h
 *
 *     Hyperfloor/hyperceiling, plus some functions to round up/down to
 *     nearest page size.
 */

#ifndef __LBXC_MATH_H
#define __LBXC_MATH_H

#include "basics.h"

// This is 2^k
#define EXP2(k) ((size_t)(1LL << (k)))


// Computes ceiling of (lg (num))
static inline unsigned int lg_ceil(size_t num) {
  unsigned int option = 0;
  size_t temp = num;

  if (num == 0) return 0;

  while (temp != 1) {
    temp = temp >> 1;
    option = option + 1;
  }

  return (EXP2(option) == num) ? option : (option + 1);
}

// Computes 2 ^ (ceil(lg(num)))
static inline size_t hyperceil(size_t num) {
  size_t option = 1;
  size_t temp = num;

  if (num == 0) return 1;

  while(temp != 1){
    temp = temp>>1;
    option = option<<1;
  }
  return (option == num) ? option : (option<<1);
}


// Computes floor of (lg (num))
static inline unsigned int lg_floor(size_t num) {
  unsigned int option = 0;
  size_t temp = num;

  if (num == 0) return 0;

  while (temp != 1) {
    temp = temp >> 1;
    option = option + 1;
  }

  return option;
}

// Computes 2 ^ (floor(lg(num)))
static inline size_t hyperfloor(size_t num) {
  size_t option = 1;
  size_t temp = num;

  if (num == 0) return 0;

  while (temp != 1) {
    temp = temp >> 1;
    option = option << 1;    
  }
  return option;
}


// Rounds a size up to the next page.
static inline size_t page_length_ceil(size_t num) {
  return PAGESIZE * (((size_t)(num / PAGESIZE)) + (num % PAGESIZE != 0));
}

// Rounds a size down to the correct page.
static inline size_t page_length_floor(size_t num) {
  return (size_t)(PAGESIZE) * ((size_t)num/PAGESIZE);
}

#endif
