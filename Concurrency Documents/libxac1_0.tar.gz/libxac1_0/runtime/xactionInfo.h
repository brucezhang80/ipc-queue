/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xactionInfo.h
 *
 *    This file defines the transaction record data structure (i.e.,
 *    maintaining the transaction's readset and writeset).  It also
 *    defines the page-to-transaction table that is used to check for
 *    conflicts.
 */


#ifndef __XACTION_INFO
#define __XACTION_INFO

#include <stdlib.h>
#include "basics.h"
#include "globalTypes.h"



void initPageInfoTable(xactionContext* xc);
void initXactionInfoTable(xactionContext* xc);






void printTransactionInfo(xactionContext* xc, int id);

/**
 * Gets the transaction information corresponding
 *  to a particular id, or NULL if no
 *   transaction matches.
 */
xactionInfo* getXactionFromId(xactionContext* xc, int id);

/**
 * Returns the status of the current transaction 
 *  (PENDING, FAILED, COMMITTED, or ABORTED)
 */
xactionStatus getXactionStatus(xactionContext* xc, int id);

/**
 * Sets the appropriate status field.
 */
void setXactionStatus(xactionContext* xc, int id, xactionStatus newStatus);


/**
 * Creates a new transaction that has status PENDING
 *  and has NULL read and write sets.
 * Returns the id of the transaction created (or -1
 *  if there was an error)
 */
int createTransactionInfo(xactionContext* xc);

/**
 * Deletes the information for the transaction
 *   corresponding to id.
 * Returns 0 if successfully deleted,
 *  or -1 if error (transaction wasn't found)
 */
int deleteTransactionInfo(xactionContext* xc, int id);

int numberOfFreeXactionIds(xactionContext* xc);

inline int getXactionTimeStamp(xactionContext* xc, int id);


/**
 * Returns READING if transaction has pageNumber in readSet
 * Returns WRITING if pageNumbers is in writeSet
 * Otherwise, returns NONE.
 */
accessStatus pageStatusForXaction(xactionContext* xc, int id, int pageNumber);

inline void setPageStatusForXaction(xactionContext* xc, int id, int pageNumber, accessStatus stat);
inline void clearPageStatusForXaction(xactionContext* xc, int id, int pageNumber);


/** Add a page to the read or write set
 *   of a transaction.
 *  A page should either be in the readSet or
 *   writeSet, but not both.
 */
void addToReadSet(xactionContext* xc, int id, int pageNumber);
void addToWriteSet(xactionContext* xc, int id, int pageNumber);

//void removeFromReadSet(int id, int pageNumber);
//void removeFromWriteSet(int id, int pageNumber);

void switchFromReadToWriteSet(xactionContext* xc, int id, int pageNumber);
inline int givePageToOtherXaction(xactionContext* xc, int id, int pageNumber, int newOwner);

/**
 * Iterators for the readset/writeset
 */

inline int firstReadSetIndex(xactionContext* xc, int id);
inline int currentReadSetPage(xactionContext* xc, int id, int currentPtr);
inline int nextReadSetIndex(xactionContext* xc, int id, int currentPtr);
inline int endOfReadSet(xactionContext* xc, int id, int currentPtr);


inline int firstWriteSetIndex(xactionContext* xc, int id);
inline int currentWriteSetPage(xactionContext* xc, int id, int currentPtr);
inline int nextWriteSetIndex(xactionContext* xc, int id, int currentPtr);
inline int endOfWriteSet(xactionContext* xc, int id, int currentPtr);
inline int writeSetLength(xactionContext* xc, int id);




// We also keep track of the reverse direction.
//  For a given page, we can ask who is reading
//   or writing that page.



void printPageAccessors(xactionContext* xc);
void printXactionStatus(xactionStatus status);

// Add returns -1 if there is an error.
int addReaderForPage(xactionContext* xc, int id, int pageNumber);
int addWriterForPage(xactionContext* xc, int id, int pageNumber);
int removeReaderForPage(xactionContext* xc, int id, int pageNumber);
int removeWriterForPage(xactionContext* xc, int id, int pageNumber);

xactionNodeList* getReaders(xactionContext* xc, int pageNumber);
int getNumReaders(xactionContext* xc, int pageNumber);


xactionNodeList* getWriters(xactionContext* xc, int pageNumber);
int getNumWriters(xactionContext* xc, int pageNumber);


/**
 * For the specified transaction, this function
 *  goes through the transaction's readSet and
 *  removes those pages from the page->reader table.
 *
 * This means that the pages the transaction reads
 *  will no longer generate conflicts.
 */
void removeReadSetFromPageToReaderMap(xactionContext* xc, int id);


/**
 * For the specified transaction, this function
 *  goes through the transaction's writeSet and
 *  removes those pages from the page->writer table.
 *
 * This means that the pages the transaction writes
 *  will no longer generate conflicts.
 */
void removeWriteSetFromPageToWriterMap(xactionContext* xc, int id);


#endif
