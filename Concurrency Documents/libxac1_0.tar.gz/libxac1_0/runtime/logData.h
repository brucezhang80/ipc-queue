/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * logData.h
 *  
 *  (Eventually) will contain information about the structure
 *   of the log file.
 *  We haven't implemented recovery yet, so the log file
 *   structure isn't decided on yet...
 */

#ifndef __LOG_DATA_H
#define __LOG_DATA_H

#include "basics.h"


#define NULL_FILE_ID -8
#define UNMAPPED_PAGE -2

/***
 *  All files on disk are given unique ids. 
 */
typedef struct dpPtr {
  int dp;      // The disk page in the file
  int fileId;  // The id of the file 
} dpPtr;


// The different types of log pages we can have
typedef enum {INVALID,
	      XBEGIN,
	      XCOMMIT_START,
	      XCOMMIT_FINISH,
	      XABORT,
	      CHECKPT_START,
	      CHECKPT_FINISH,
	      EXTRA,
	      DATA}
logPageType;

// Returns a pointer to a null page. 
static inline dpPtr nullPagePtr(void) {
  dpPtr answer;
  answer.fileId = NULL_FILE_ID;
  answer.dp = UNMAPPED_PAGE;
  return answer;
}

static inline int isNullPagePtr(dpPtr testPtr) {
  return ((testPtr.fileId == NULL_FILE_ID) &&
	  (testPtr.dp = UNMAPPED_PAGE));
}

/* typedef struct xactionMetaDataPtr { */
/*   int numMetaDataPages; */
/*   dpPtr xbeginPage; */
/*   void* xbeginAddr; */
  
/*   dpPtr extraPage; */
/*   void* extraAddr; */

/*   dpPtr xendPage1; */
/*   dpPtr xendPage2; */
/*   void* xendAddr1; */
/*   void* xendAddr2; */

/*   dpPtr checkPtPage1; */
/*   dpPtr checkPtPage2;   */
/*   void* checkPtAddr1; */
/*   void* checkPtAddr2; */
  
/* } xactionMetaDataPtr; */




/* typedef long long logPageTag; */

/* typedef struct logPageHeader { */
/*   logPageTag checkTag; */
/*   int xactionId; */
/*   int timeStamp; */
/*   //  dpPtr prevPage; */
/*   dpPtr nextPage; */
/*   int dataLength; */
/* } logPageHeader; */


/* typedef struct { */
/*   int xPage;   // The virtual page in the transactional region. */
/*   dpPtr page;  // The actual page on disk, in a file. */
/* } dataPageInLog; */

/* enum {PAGE_PTRS_PER_LOG_PAGE = (PAGESIZE - sizeof(logPageHeader) - sizeof(logPageTag)) / sizeof(dataPageInLog)}; */

/* typedef struct logPageContents { */
/*   logPageTag tag; */
/*   logPageHeader header; */
/*   dataPageInLog pages[PAGE_PTRS_PER_LOG_PAGE]; */
/* } logPageContents; */




/* // Returns the size of the logPageContents structure (in bytes) */
/* int logPageContentsSize(void); */


/* logPageTag createLogTag(logPageType tp); */
/* logPageType lpTypeFromTag(logPageTag tag); */
/* logPageType getLogPageType(logPageContents* lpc); */


/* // Creates a log page of the specified type. */
/* void initLogPageContents(logPageContents* lpc, logPageType pageType, int xactionId, int timeStamp); */


/* // Adds a data page pointer to the log page. */
/* void addPageToLPC(logPageContents* lpc, int xactionPage, dpPtr newPage); */
/* // Returns TRUE if we have filled up the log page with data page pointers. */
/* int lpcIsFull(logPageContents* lpc); */


/* // Functions to point the log pages to each other. */
/* void setNextLP(logPageContents* lpc, dpPtr nextPage); */
/* //void setPrevLP(logPageContents* lpc, dpPtr nextPage); */


/* int getXactionIdFromLP(logPageContents* lpc); */
/* dpPtr getLPNextPage(logPageContents* lpc); */
/* //dpPtr getLPPrevPage(logPageContents* lpc); */


/* // For debugging purposes */
/* void printLogType(logPageType type); */
/* void sprintLogType(logPageType tempType, char* buffer); */
/* void printLPC(logPageContents* lpc); */


/* // Clears all the addresses and disk page pointers in the */
/* //   xmdPtr structure */
/* void resetXactionMDPtr(xactionMetaDataPtr* xmdPtr); */

/* // Sets the address and disk page pointers for the specified type. */
/* //  If numPages is not 0, then we assume that the type is XBEGIN, and */
/* //   we are trying to add extra xbegin pages */
/* void updateXactionMDPtr(xactionMetaDataPtr* xmdPtr, logPageType lpType, dpPtr diskPage, void* addr, int numPages); */
/* void* getCorrectAddr(xactionMetaDataPtr* xmdPtr, logPageType lpType); */
/* dpPtr getCorrectDiskPage(xactionMetaDataPtr* xmdPtr, logPageType lpType); */

/* int firstLogFile(xactionMetaDataPtr* xmdPtr); */
/* int lastLogFile(xactionMetaDataPtr* xmdPtr); */
#endif 
