/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xStats.c
 *
 */


#include <stdlib.h>
#include "xStats.h"

#include "basics.h"

void clearXactionStats(xactionStats* xstat) {

    xstat->myId = -3;
    xstat->pagesRead = 0;
    xstat->pagesWritten = 0;
    xstat->bytesLogged = 0;
    xstat->numXactionsSynched = 0;

    xstat->commitStatus = FALSE;



//    xstat->compressStartTime = 0;
//    xstat->compressEndTime = 0;
    xstat->totalCompressTime = 0;
    xstat->writeStartTime = 0;
    xstat->writeEndTime = 0;
    xstat->fsyncStartTime = 0;
    xstat->fsyncEndTime = 0;
    xstat->totalSyncStartTime = 0;
    xstat->totalSyncEndTime = 0;

#ifdef USE_COMPRESSED_LOGS
    xstat->compression = TRUE;
#else
    xstat->compression = FALSE;
#endif
    // Not clearing the start/end times...
}



void printXStatsKey(FILE* f) {

    fprintf(f, "## Pid  Id  PagesRead  PagesWritten  Committed? ");
    fprintf(f, "BytesLogged  CompressTime Compressed?  ");
    fprintf(f, "WriteTime  ");
    fprintf(f, "NumXactionsSynched   SyncTime   ");
    fprintf(f, "TotalSyncTime");
    fprintf(f, "\n");
}


#define ALF_CPU (1.4e9)
void printXStats(FILE* f, int mypid,  xactionStats* xs) {

    if (xs->commitStatus) {
	fprintf(f, "%5d  %2d  %2d  %3d  %1d  ",
		mypid,
		xs->myId,
		xs->pagesRead, xs->pagesWritten,
		xs->commitStatus);

/* 	fprintf(f, "%7zd  %9llu   %1d  ", */
/* 		xs->bytesLogged, */
/* 		xs->compressEndTime - xs->compressStartTime, */
/* 		xs->compression); */


	fprintf(f, "%7zd  %6.2f   %1d  ",
		xs->bytesLogged,
		((1.0e6)*xs->totalCompressTime / ALF_CPU),
//		((1.0e6)*(xs->compressEndTime - xs->compressStartTime)) / ALF_CPU,
		xs->compression);


//	fprintf(f, "%9llu  ",
//		((1.0e6)*(xs->writeEndTime - xs->writeStartTime))/ALF_CPU);

	fprintf(f, "%6.2f  ",
		((1.0e6)*(xs->writeEndTime - xs->writeStartTime))/ALF_CPU);

/* 	fprintf(f, "%3d   %9llu  ", */
/* 		xs->numXactionsSynched, */
/* 		xs->fsyncEndTime - xs->fsyncStartTime); */


	fprintf(f, "%3d   %6.2f  ",
		xs->numXactionsSynched,
		((1.0e6)*(xs->fsyncEndTime - xs->fsyncStartTime))/ALF_CPU);


	fprintf(f, "%6.2f  ",
		((1.0e6)*(xs->totalSyncEndTime - xs->totalSyncStartTime))/ALF_CPU);

	fprintf(f, "\n");
    }

}
