/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */



/**
 * xactionLib.c
 *
 */
#include "xactionInfo.h"





#include <errno.h>
#include <sched.h>
#include <signal.h>
#include <string.h>
#include <sys/file.h>
//#include <sys/mman.h>


/* #include "libxac_client_types.h" */


//timeStruct syncTS1, syncTS2;
//double syncTime;
//int numSyncs;

//#define IS_DURABLE FALSE
//#define XACTION_PRINT


#include "xactionLib.h"



/*********************************************************/
xactionContext* currentXC;
extern int isDurableTempFlag;
extern xaction_local_context xlc;
extern mappedFileData actualMFD;
/*********************************************************/


/***
 * Checks for a conflict and then aborts the
 *  right person.
 * This function releases the global lock.
 */
void checkForConflict(xaction_local_context* xlocal,
		      TID id,
		      int pageNumber) { 
 
  int isPending;
  accessStatus currentStatus;
  

  acquireGlobalLock(currentXC);
  // Figure out if the transaction is accessing this page before.
  currentStatus = pageStatusForXaction(currentXC, id, pageNumber);
  isPending = (getXactionStatus(currentXC, id) == PENDING);

  switch (currentStatus) {
  case TRANSFER:
  case NONE:


    if ((isPending) && (!xlocal->isReadOnlyXaction)) {
      isPending = !findReadConflicts(id, pageNumber, currentAbortPolicy(currentXC));
    }
    // Either way, the transaction can read the page.
    handlePageRead(xlocal, id, pageNumber, isPending, xlocal->isReadOnlyXaction);  
    // The above function call unlocks the global lock.
    break;

  case READING:
    if (xlocal->isReadOnlyXaction) {
      fprintf(stderr, "For readonly-xaction, status for trans %d, page %d is invalid. Should not be 2nd seg fault..\n", id, pageNumber);
      assert(FALSE);
    }
    if (isPending) {
      isPending = !findWriteConflicts(id, pageNumber, currentAbortPolicy(currentXC), TRUE);
    }

    //    checkTimer(&currentXC->pageT1);
    handlePageWrite(xlocal, id, pageNumber, isPending, TRUE);
    //handlePageWrite unlocks the global lock.
    break;
  case WRITING:
    fprintf(stderr, "Status for trans %d, page %d is invalid. Should be no seg faults on pages we are writing.\n", id, pageNumber); 
  default:
    fprintf(stderr, "Status for trans %d, page %d is invalid. Should be no seg faults on ther?.\n", id, pageNumber);
    releaseGlobalLock(currentXC);
    //    Cilk_unlock(*(currentXC->xactionGlobal));
    exit(1);
  }  
}

// This function is quote similar to checkForConflict
void setPageAccess(xaction_local_context* xlocal,
		   TID id,
		   int pageNum,
		   int doOnlyRead) {
  int isPending;
  int releasedLock = FALSE;
  accessStatus currentStatus;

  acquireGlobalLock(currentXC);
  if (doOnlyRead) {
    currentStatus = pageStatusForXaction(currentXC, id, pageNum);

    if ((currentStatus == NONE) || (currentStatus == TRANSFER)) {
      isPending = (getXactionStatus(currentXC, id) == PENDING);

      // Process the page read.
      if (isPending) {
	isPending = !findReadConflicts(id, pageNum, currentAbortPolicy(currentXC));
      }
      // Either way, the transaction can read the page.
      handlePageRead(xlocal, id, pageNum, isPending, xlocal->isReadOnlyXaction);
      releasedLock = TRUE;
    }
  }
  else {
    // Do a write without first doing read instead.
    currentStatus = pageStatusForXaction(currentXC, id, pageNum);
    if (currentStatus != WRITING) {
      isPending = (getXactionStatus(currentXC, id) == PENDING);
      if (isPending) {
	isPending = !findWriteConflicts(id, pageNum, currentAbortPolicy(currentXC), (currentStatus == READING));
      }
      // transaction can write to page.
      handlePageWrite(xlocal, id, pageNum, isPending, (currentStatus == READING));
      releasedLock = TRUE;
    }
   
    if (!releasedLock) {
      releaseGlobalLock(currentXC);
    }
  }
}


// Returns the transaction ID, or -1 if we failed.
TID get_transaction_id(xaction_local_context* xlocal,
		       int is_query) {
  TID answer;
  acquireGlobalLock(currentXC);

  // Create the data structure for the transaction.
  answer = createTransactionInfo(currentXC);

  // If we ran out of transaction id's, try to do a garbage collection.
  if (answer == -1) {
    DBPRINT(stderr, "ACTUALLY doing this gb. collection!!!!!!!!!!1\n");
    //      printf("Actually doing this gbcollection...\n");
    garbageCollectTransactions(xlocal, TRUE);
    answer = createTransactionInfo(currentXC);
  }
  
  if (answer == -1) {
    printf("Process %d stalled here trying to get an id... \n", getpid());
  }
  else {

    // Insert the transaction into the dependency tree, hanging off
    //  the last committed transaction.

    if (is_query) {
      addReadOnly(currentXC->t,
		  answer,
		  lastCommittedXaction(currentXC->t));      
    }
    else {
      addPending(currentXC->t, answer, lastCommittedXaction(currentXC->t));
    }

    DBPRINT(stderr, "#################### Beginning transaction %d! ######\n", xlocal->currentXId);
    DBPRINT(stderr, "Tree is now \n");
    TREEPRINT(currentXC->t);
  }
  releaseGlobalLock(currentXC);
  return answer;
}



static void doSynchronizationOnDisk(xaction_local_context* xlocal) {  
    if (xlocal->isDurable) {


	addEventToLocalBuffer(xlocal->lcbf,
			      xlocal->currentXId,
			      SYNC_SCHED_BEGIN);
#ifdef GATHER_STATS
	checkCycleCount(&(xlocal->xs.totalSyncStartTime));
#endif
	flushCommitDataToDisk(currentXC, xlocal);
#ifdef GATHER_STATS
	checkCycleCount(&(xlocal->xs.totalSyncEndTime));
#endif

	addEventToLocalBuffer(xlocal->lcbf,
			      xlocal->currentXId,
			      SYNC_DONE);

    }
}


int xend_server_side_step1(xaction_local_context* xlocal) {
  int didCommit;
  acquireGlobalLock(currentXC);

  // Stage 1 of commit:  check whether we are still PENDING.
  //   If so, set the flag of this transaction to COMMITTED.
  //   After stage 1, this transaction can no longer be aborted.

  if (getXactionStatus(currentXC, xlocal->currentXId) == PENDING) {

    xactionCommitHelper(currentXC,
			xlocal,
			xlocal->currentXId);
    didCommit = TRUE;
  }
  else {

    xactionAbortHelper(currentXC,
		       xlocal,
		       xlocal->currentXId);

    didCommit = FALSE;
  }

  assert(verifyGlobalIsLocked(currentXC));
  releaseGlobalLock(currentXC);
  return didCommit;
}

// Call this function to prepare a log entry for commit, and
//  to sync. the log entry to file.
void xend_server_side_step2(xaction_local_context* xlocal) {

  generateLogEntryForCommit(currentXC,
			    xlocal,
			    xlocal->currentXId,
			    xlocal->isDurable);
  doSynchronizationOnDisk(xlocal);

#ifdef USE_LSN
  updateLSNLastCommitted(currentXC);
#endif
}

void xend_server_side_step3(xaction_local_context* xlocal,
			    int didCommit) {

  // Stage 3: Remove all the pages that this transaction has written from
  //  the page->transaction array, and then queue the unmaps of the pages.
  acquireGlobalLock(currentXC);
  garbageCollectTransactions(xlocal, FALSE);
  if (didCommit) {
    handleXactionCommitStage3(xlocal,
			      xlocal->currentXId);
  }
  else {
    // For an aborted transaction, delete the transaction info.
    deleteTransactionInfo(currentXC, xlocal->currentXId);
  }
  assert(numPagesInReadSourceTable(xlocal->mfd) == 0);
  releaseGlobalLock(currentXC);
}

void xend_server_side_step4(xaction_local_context* xlocal) {
  // Stage 4: actuallly unmap everything for this process
  processUnmapQueue(currentXC, xlocal, xlocal->isDurable);
}

void xendQuery_server_side_step1(xaction_local_context* xlocal) {
  acquireGlobalLock(currentXC);
  assert(getXactionStatus(currentXC, xlocal->currentXId) == PENDING);
  xactionCommitReadOnlyHelper(xlocal);
  deleteTransactionInfo(currentXC, xlocal->currentXId);
  garbageCollectTransactions(xlocal, FALSE);
  releaseGlobalLock(currentXC);
}



/*********************************************/
// Functions for creating/attaching xaction system.


void xMmap_server_side(xaction_local_context* xlocal,
		       const char* userFileName,
		       int numPages) {

  //  currentXC = attachControlRegion(userFileName);
  currentXC = attachControlRegion();
  attachMmapToFile(currentXC,
		   xlocal,
		   userFileName,
		   numPages);
}


void xMunmap_server_side(xaction_local_context* xlocal,
			 const char* fileName) {
#ifdef DO_LOCK_TIMINGS
    printf("On process %d: global lock acquire time: \n", getpid());    
    printf("Total of %d locks:  Avg. %0.6f cycles per lock, or %0.6f us per lock\n",
	   currentXC->numLocks, 
	   1.0 * currentXC->lockTime / currentXC->numLocks,
	   1e6*currentXC->lockTime / (currentXC->numLocks* 1.4 * 1e9));
#endif	   	   
  //  reportStatsOnProcess();
  //  printf("About to detach on process %d\n", getpid());
  //  garbageCollectTransactions(TRUE);
  //  printf("Finished gbCollecting transactions.\n");
  if (errno != 0) {
    perror("WHy???");
    assert(errno == 0);    
  }

  // Garbage collect, i.e., copy things back
  //  to the original file.
  acquireGlobalLock(currentXC);
  //  printf("Performing final gb collect....\n");
  garbageCollectTransactions(xlocal, TRUE);
  releaseGlobalLock(currentXC);

  //  printf("Final tree.\n");
  //  outputDepTree(currentXC->t);  
  detachMmapFromFile(currentXC,
		     xlocal,
		     fileName);
}




int xInit(const char* fileName, int isDurable) {
  int error = setupControlFile(fileName, isDurable);
  isDurableTempFlag = isDurable;
  assert(error == 0);
  return error;
}


void xShutdown(void) {

  //  printf("End of program report\n");
  //  printGLF(currentXC->glf);
  //  printf("Starting control region detach.\n");

  //  printf("doing with final gb collect.\n");
  //  finalGarbageCollectTransactions();
  //  printf("Done with final gb collect.\n");
  //  printFinalRefCounts(currentXC->glf);

  finalCleanupAttachForLogFiles(currentXC,
				&xlc,
				NULL);
  
  finalGarbageCollectTransactions(&xlc);
  printFinalRefCounts(currentXC->glf);

  finalCleanupDetachForLogFiles(currentXC,
				&xlc,
				NULL);
  
  detachControlRegion(currentXC);

//  printf("Finished control region detach.\n");
  assert(errno == 0);
  //  closeControlFile();  
}



// Functions for the old interface.  This just works out
//   with an anonymous log file of initial length MAX_PAGES

void* setupXactionSystem(int controlFileId __attribute__((__unused__))) {
  xInit(NULL, IS_DURABLE);
  return xMmap(NULL, MAX_PAGES);
}

int cleanupXactionSystem(void) {
  xMunmap(NULL);
  assert(errno == 0);
  xShutdown();
  assert(errno == 0);
  //  printf("The size of the control file is.. %d or about %d pages\n", sizeof(actualGlobalStruct), sizeof(actualGlobalStruct)/4096);
  return SUCCESS;
}


// Checkpoints aren't implemented yet...
void xCheckpointBegin(void) {
  //  writeTaggedPageToLog(currentXC, &currentXC->xmdPtr, CHECKPT_START);
//  syncUserFile(currentXC->glf, xlc.mfd);
  // Need to do something here.. but not sure what yet.
  //  syncCurrentLogFiles(currentXC);
}

void xCheckpointEnd(void) {
  //  writeTaggedPageToLog(currentXC, &currentXC->xmdPtr, CHECKPT_FINISH);
  //  syncCurrentLogFiles(currentXC); //, logFileId, logFileId);
}



void setLogTestMode(int newLogTestMode) {
    currentXC->logTestModeOn = newLogTestMode;
}

