/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xConflict.h
 *
 *  Implements conflict-resolution functions (i.e.,
 *   decide which transaction to abort)
 */

#ifndef __XCONFLICT_H
#define __XCONFLICT_H

#include "globalTypes.h"



/**
 * Called when transaction "id" is reading the specified
 *  page for the first time.
 * This will fail the appropriate transactions before
 *  going forward.
 *
 * Returns TRUE if the transaction "id" failed.
 */
int findReadConflicts(int id, int pageNumber, AbortPolicy pol);

/**
 * Called when transaction "id" is writing the specified
 *  page for the first time.
 * This will fail the appropriate transactions before
 *  going forward.
 *
 * isIsreader is a Boolean stating whether id is reading this 
 *   page currently
 * Returns TRUE if the transaction "id" FAILED
 */
int findWriteConflicts(int id, int pageNumber, AbortPolicy pol, int idIsReader);



#endif
