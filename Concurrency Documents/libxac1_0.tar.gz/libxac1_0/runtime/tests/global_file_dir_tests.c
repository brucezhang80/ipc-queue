/*************************************************************************
 *
 *  Libxac runtime system -- test code
 *   
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2006       Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * global_file_dir_tests.c
 *
 *  Test code for the global file directory. 
 */



#include "../global_file_dir.h"
#include "../globalControl.h"


#define NUM_TEST_FILES 100
extern xactionContext* currentXC;


global_file_info test_files[100];



static void generate_random_files(void) {
  int i;
  for (i = 0; i < NUM_TEST_FILES; i++) {
    int name_length;
    size_t length;
    int k;

    name_length = 5 + 10.0*(rand() / (RAND_MAX + 1.0));
    //    name_length = 5;
    length = 50 + 100.0*(rand() / (RAND_MAX + 1.0));

    test_files[i].id = i;
    test_files[i].length = length;

    for (k = 0; k < name_length; k++) {
      test_files[i].name[k] = 'a' + 26.0*(rand() / (RAND_MAX + 1.0));      
    }
    test_files[i].name[name_length] = '\0';

    printf("Key %d:    ", i);
    key_print(&test_files[i]);
    printf("\n");
  }
}


static void test_insert_files(void) {
  int i;

  for (i = 0; i < NUM_TEST_FILES; i++) {
    printf("INSERT %d: \n", i);

    insert_key_into_gfd(currentXC->gfiledir,
			&test_files[i]);

    printf("After insert, what is the directory looking like? \n");
    print_global_file_directory(currentXC->gfiledir);

    //    check_gfd(currentXC->gfiledir);

    {
      int j;
      int found;
      global_file_info test_info;
      for (j = 0; j < i; j++) {

	strcpy(test_info.name, test_files[j].name);

	found = find_key_in_gfd(currentXC->gfiledir,
				&test_info);

	printf("Searched for file name %s.  Found? %d\n",
	       test_info.name, found);
	assert(found == 1);
	assert(test_info.id == test_files[j].id);
	assert(test_info.length == test_files[j].length);
      }
    }
  }
}

static void test_delete_files(void) {
  int i;
  int alpha = 10;

  for (alpha = 0; alpha < NUM_TEST_FILES; alpha++) {

    printf("ALPHA is %d!!!!\n", alpha);
    for (i = 0; i < alpha; i++) {
      printf("DELETE %d: \n", i);

      insert_key_into_gfd(currentXC->gfiledir,
			  &test_files[i]);

      //      printf("After insert, what is the directory looking like? \n");
      //      print_global_file_directory(currentXC->gfiledir);

      //    check_gfd(currentXC->gfiledir);

      {
	int j;
	int found;
	global_file_info test_info;
	for (j = 0; j < i; j++) {

	  strcpy(test_info.name, test_files[j].name);

	  found = find_key_in_gfd(currentXC->gfiledir,
				  &test_info);

	  //	  printf("Searched for file name %s.  Found? %d\n",
	  //		 test_info.name, found);
	  assert(found == 1);
	  assert(test_info.id == test_files[j].id);
	  assert(test_info.length == test_files[j].length);
	}
      }
    }

    for (i = 0; i < alpha; i++) {
      int deleted;
      global_file_info delete_info;

      strcpy(delete_info.name, test_files[i].name);
      //      print_global_file_directory(currentXC->gfiledir);
      //      printf("Deleting file name %s: \n", delete_info.name);
      deleted = delete_key(currentXC->gfiledir, &delete_info);
      //      printf("Deleted? for file name %s.  Deleted? %d\n",
      //	     delete_info.name, deleted);
      //      printf("After the delete...\n");
      //      print_global_file_directory(currentXC->gfiledir);
      assert(deleted == 0);
      assert(strcmp(delete_info.name, test_files[i].name) == 0);
      assert(delete_info.id == test_files[i].id);
      assert(delete_info.length == test_files[i].length);
    }
  }
}
				     

int main(void) {

  setupControlFile("test.db", FALSE);  
  printf("Attempting to attach control region\n");
  currentXC = attachControlRegion();


  printf("Testing initialization of the gfd\n");  
  init_global_file_dir(currentXC->gfiledir);

  print_global_file_directory(currentXC->gfiledir);


  generate_random_files();
  if (0) {
    test_insert_files();
  }

  test_delete_files();

  // All the crap in between is the actual test cases...

  
  detachControlRegion(currentXC);

  printf("All global_file_dir_tests OK\n");
  return 0;       
}
