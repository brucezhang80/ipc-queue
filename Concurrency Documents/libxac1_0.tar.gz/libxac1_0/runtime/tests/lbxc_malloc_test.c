/*************************************************************************
 *
 *  Libxac runtime tests -- test code
 *
 *************************************************************************/
/*
 * Copyright (c) 2006    Massachusetts Institute of Technology
 * Copyright (c) 2006    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * lbxc_malloc_test.c
 *
 *    Test code for lbxc_malloc
 *    
 */

#include <assert.h>
#include "../lbxc_malloc.h"


int hyperfloor_ceil_test(void);
int libxac_arena_test(void);
int simple_malloc_test(void);
void malloc_test(void);
int malloc_arena_grow_test(void);
int simple_arena_grow_test(void);
int malloc_arena_grow_test2(void);
size_t page_size = 4096;

/****************************************************/
// Test code for floors and ceilings.
//  Don't run this test by default...

int hyperfloor_ceil_test(void) {

  unsigned int k;
  size_t temp = 1;
  //  unsigned int test_max = 34;
  unsigned int test_max = (sizeof(size_t)*8LL);

  printf("Hyperfloors/ceilings: k = ");
  for (k = 0; k < test_max; k++) {
    size_t i;
    size_t min_test, max_test;
  
    printf("%d..  ", k);
    i = BUCKET_SIZE(k);
    assert(i == temp);

 //    printf("What is size of sizet? %zd\n", sizeof(size_t));
/*     printf("HyperCeil(%zd) = %zd\n", i, hyperceil(i)); */
/*     printf("lg_Ceil(%zd) = %u\n", i, lg_ceil(i)); */
/*     printf("HyperFloor(%zd) = %zd\n", i, hyperfloor(i)); */
/*     printf("lg_floor(%zd) = %u\n", i, lg_floor(i)); */
/*     printf("\n"); */

    assert(hyperceil(i) == temp);
    assert(hyperfloor(i) == temp);
    assert(lg_ceil(i) == k);
    assert(lg_floor(i) == k);

    min_test = BUCKET_SIZE(k) + 1;
    max_test = BUCKET_SIZE(k+1);

    //    printf("What is k? %u\n", k);
    //    printf("What is min_test? %zd\n", min_test);
    //    printf("What is max_test? %zd\n", max_test);
    if (max_test - min_test > 100) {      
      min_test = max_test - 50;

      for (i = min_test; i < min_test + 50; i++) {
	assert(hyperceil(i) == 2*temp);
	assert(hyperfloor(i) == temp);
	assert(lg_ceil(i) == k+1);
	assert(lg_floor(i) == k);      
      }

      for (i = max_test - 50; i < max_test; i++) {
	assert(hyperceil(i) == 2*temp);
	assert(hyperfloor(i) == temp);
	assert(lg_ceil(i) == k+1);
	assert(lg_floor(i) == k);      
      }
    }
    else {
      for (i = ((BUCKET_SIZE(k))+1);  i < BUCKET_SIZE(k+1);  i++) {
	//    for (i = ((BUCKET_SIZE(k))+1); i < (BUCKET_SIZE(k+1)-1); i++) {
	/*       printf("HyperCeil(%zd) = %zd\n", i, hyperceil(i)); */
	/*       printf("lg_Ceil(%zd) = %u\n", i, lg_ceil(i)); */
	/*       printf("HyperFloor(%zd) = %zd\n", i, hyperfloor(i)); */
	/*       printf("lg_floor(%zd) = %u\n", i, lg_floor(i)); */
	/*       printf("\n"); */

	assert(hyperceil(i) == 2*temp);
	assert(hyperfloor(i) == temp);
	assert(lg_ceil(i) == k+1);
	assert(lg_floor(i) == k);      
      }
    }

    temp *= 2;
    fflush(stdout);
  }

  printf(" OK!\n");
  
  return 0;
}



int libxac_arena_test(void) {

  int error;
  void* base_addr;
  base_addr = malloc(page_size*100);
  assert(base_addr != NULL);



  assert(sizeof(arena_header) < CONTROL_BLOCK_SIZE);
  error = lbxc_arena_init(CONTROL_BLOCK_SIZE, base_addr);
  assert(error == -1);


  printf("initializing arean of size %zd\n", 10*page_size);
  error = lbxc_arena_init(10*page_size, base_addr);
  assert(error == 0);


  free(base_addr);
  return 0;  
}




//  Another test function
int simple_malloc_test(void) {

  int i;
  void* start_ptr;
  int error;

  size_t total_size = page_size * 500;

  printf("Simple malloc test running...\n");
  start_ptr = malloc(total_size);
  error = lbxc_arena_init(total_size, start_ptr);
  assert(error == 0);

  printf("Base address pointer is %p\n", start_ptr);
  for (i = 0; i < 10; i++) {
    size_t my_offset;
    void* my_ptr;
    
    my_offset = lbxc_malloc(20*i, start_ptr);
    my_ptr = OFFSET_TO_PTR(my_offset, start_ptr);
    printf("malloc'ed memory of size %d at offset %zd, pointer %p\n",
	   20*i,
	   my_offset,
	   my_ptr);
    assert(my_ptr != 0);

   lbxc_free(my_offset, start_ptr);
   printf("Freed memory of size %d\n\n", 20*i);
  }

  printf("Simple malloc test OK\n");
  free(start_ptr);
  return 0;    
}



static int malloc_test_helper(void* base_addr, size_t region_size) {
  
  int MIN_MALLOC_SIZE = 64;
  size_t ptr_array[region_size/MIN_MALLOC_SIZE];
  size_t ptr_size[region_size/MIN_MALLOC_SIZE];
  size_t ptr_block_sum[region_size/MIN_MALLOC_SIZE];

  unsigned int i = 0;
  size_t total_size_used = 0;
  unsigned int num_ptrs = 0;
  int error;

  while (1) {
    unsigned int j;
    ptr_size[i] = MIN_MALLOC_SIZE + (int) (3.8*page_size*rand()/(RAND_MAX+1.0));
    ptr_array[i] = lbxc_malloc(ptr_size[i], base_addr);

    if (ptr_array[i] != 0) {
      char* temp_ptr = OFFSET_TO_PTR(ptr_array[i], base_addr);

      //	printf("Malloc %zd bytes at offset %zd\n", ptr_size[i], ptr_array[i]);
      total_size_used += ptr_size[i];

      // Fill it with random characters and store the sum...
      ptr_block_sum[i] = 0;
      for (j = 0; j < ptr_size[i]; j++) {
	temp_ptr[j] = (char)rand();
	ptr_block_sum[i] += (size_t)temp_ptr[j];	  
      }
      //      printf("\n");
      i++;
    }
    else {
      break;
    }     
  }
  num_ptrs = i;

  printf("MEMORY USAGE: we used %zd out of %zd, or %0.6f percent\n",
	 total_size_used, region_size,
	 total_size_used*1.0 / region_size);

  for (i = 0; i < num_ptrs; i++) {
    unsigned int j;
    char* temp_ptr = OFFSET_TO_PTR(ptr_array[i], base_addr);
    size_t check_sum = 0;
      
    for (j = 0; j < ptr_size[i]; j++) {
      check_sum += (size_t)temp_ptr[j];
    }

    if (ptr_block_sum[i] != check_sum) {
      printf("ERROR! sum for block %u doesn't match...\n", i);
      assert(ptr_block_sum[i] == check_sum);
    }
      

    //      printf("Pointer sum at %zd is %zd\n", ptr_array[i], check_sum);
    //      printf("Freeing pointer at %zd\n", ptr_array[i]);
    error = lbxc_free(ptr_array[i], base_addr);
    assert(error == 0);
  }

  return 0;
}

//  A test function
void malloc_test(void) {

  void* base_addr;
  int error;
  size_t region_size = page_size * 100;

  unsigned int test_count;
  unsigned int num_tests = 100;


  printf("malloc_test running...\n");
  base_addr = malloc(region_size);
  error = lbxc_arena_init(region_size, base_addr);
  assert(error == 0);
  printf("Base address pointer is %p\n", base_addr);
    
  for (test_count = 0; test_count < num_tests; test_count++) {
    printf("MALLOC_TEST %d:  \n", test_count);
    malloc_test_helper(base_addr, region_size);
  }

  printf("Successfully completed malloc test\n");
  free(base_addr);
}

int malloc_arena_grow_test(void) {

  size_t max_test_size = 1000 * page_size;
  size_t init_test_size = 3*page_size;
  void* base_addr;
  int resize_count = 0;
  int error;

  size_t current_size = init_test_size;

  printf("malloc_arena_grow running...\n");
  base_addr = malloc(max_test_size);
  error = lbxc_arena_init(init_test_size, base_addr);
  assert(error == 0);
  printf("Base address pointer is %p\n", base_addr);

  while (current_size < max_test_size) {
    if (current_size > max_test_size/2)  {
      current_size = max_test_size;
    }
    else {
      current_size *= 3;
    }    
    printf("Resizing arena at size %zd. Count = %d\n", current_size, resize_count);

    lbxc_arena_grow(current_size, base_addr);
    malloc_test_helper(base_addr, current_size);
  }
  free(base_addr);
  
  return 0;  
}

int malloc_arena_grow_test2(void) {
#define MAX_TESTS 100
  size_t max_test_size = 1000 * page_size;
  size_t init_test_size = 3*page_size;  
  void* base_addr;

  int resize_count = 0;
  size_t current_size = init_test_size;


  size_t ptr_array[MAX_TESTS];
  size_t ptr_size[MAX_TESTS];
  size_t ptr_block_sum[MAX_TESTS];
  size_t MIN_MALLOC_SIZE = 64;

  unsigned int i = 0;
  size_t total_size_used = 0;
  unsigned int num_ptrs = 0;
  int error;

  printf("malloc_arena_grow_test2 running\n");

  base_addr = malloc(max_test_size);
  assert(base_addr != NULL);

  error = lbxc_arena_init(init_test_size, base_addr);
  assert(error == 0);
  
  
  for (i = 0; i < MAX_TESTS; i++) {

    ptr_size[i] = MIN_MALLOC_SIZE + (int) (1.2*page_size*rand()/(RAND_MAX+1.0));
    ptr_array[i] = lbxc_malloc(ptr_size[i], base_addr);

    //    printf("Trying at malloc %u of size %zd\n", i, ptr_size[i]);
    
    while (ptr_array[i] == 0) {
      int success;
      printf("Problem at malloc %u of size %zd\n", i, ptr_size[i]);

      if (current_size <= max_test_size/2) {
	current_size *= 2;
	success = lbxc_arena_grow(current_size, base_addr);
	ptr_array[i] = lbxc_malloc(ptr_size[i], base_addr);
      }
      else {
	current_size = max_test_size;
	lbxc_arena_grow(current_size, base_addr);
	ptr_array[i] = lbxc_malloc(ptr_size[i], base_addr);
	success = 1;
      }
      resize_count++;
    }

    if (ptr_array[i] != 0) {      
      unsigned int j;
      char* temp_ptr = OFFSET_TO_PTR(ptr_array[i], base_addr);

      //	printf("Malloc %zd bytes at offset %zd\n", ptr_size[i], ptr_array[i]);
      total_size_used += ptr_size[i];

      // Fill it with random characters and store the sum...
      ptr_block_sum[i] = 0;
      for (j = 0; j < ptr_size[i]; j++) {
	temp_ptr[j] = (char)rand();
	ptr_block_sum[i] += (size_t)temp_ptr[j];	  
      }
      //      printf("\n");
    }
    else {
      num_ptrs = i;
      break;
    }         
  }

  printf("MEMORY USAGE: we used %zd out of %zd, or %0.6f percent\n",
	 total_size_used, current_size,
	 total_size_used*1.0 / current_size);

  for (i = 0; i < num_ptrs; i++) {
    unsigned int j;
    char* temp_ptr = OFFSET_TO_PTR(ptr_array[i], base_addr);
    size_t check_sum = 0;
      
    for (j = 0; j < ptr_size[i]; j++) {
      check_sum += (size_t)temp_ptr[j];
    }

    if (ptr_block_sum[i] != check_sum) {
      printf("ERROR! sum for block %u doesn't match...\n", i);
      assert(ptr_block_sum[i] == check_sum);
    }
      

    //      printf("Pointer sum at %zd is %zd\n", ptr_array[i], check_sum);
    //      printf("Freeing pointer at %zd\n", ptr_array[i]);
    error = lbxc_free(ptr_array[i], base_addr);
    assert(error == 0);
  }

  free(base_addr);
  return 0;  
}


int simple_arena_grow_test(void) {
  void* base_addr;
  size_t p[2];
  int error;
  base_addr = malloc(100*page_size);
  assert(base_addr != NULL);

  // Depending on how big the header is for implementation, we may
  //   need to change the initial size.
  lbxc_arena_init(3*page_size, base_addr);


  printf("Trying to malloc block of size 2289\n");
  p[0] = lbxc_malloc(2048, base_addr);
  printf("First malloc: my_ptr is %zd\n", p[0]);
  assert(p[0] != 0);

  // Second malloc should fail
  p[1] = lbxc_malloc(4093, base_addr);
  printf("Second malloc: ptr is %zd\n", p[1]);
  assert(p[1] == 0);
  
  error = lbxc_arena_grow(6*page_size, base_addr);
  assert(error == 0);

  // Second try at the second malloc should succeed.
  p[1] = lbxc_malloc(4093, base_addr);
  printf("2nd try for Second ptr is %zd\n", p[1]);
  assert(p[1] != 0);

  lbxc_free(p[0], base_addr);
  lbxc_free(p[1], base_addr);

  free(base_addr);

  printf("simple_arena_grow_test is OK\n");
  return 0;
  
}

int main(void) {
  libxac_arena_test();
  simple_malloc_test();
  malloc_test();
  malloc_arena_grow_test();
  simple_arena_grow_test();
  malloc_arena_grow_test2();
  printf("All lbxc_malloc tests OK.\n");
  return 0;
}
