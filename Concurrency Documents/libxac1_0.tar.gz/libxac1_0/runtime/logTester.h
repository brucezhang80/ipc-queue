/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * logTester.h
 *
 *  Some test functions for testing the log functionality.
 *  Don't actually use these functions for anything but testing. (i.e., logTestMode is on)
 */



#ifndef __LOG_TESTER_H
#define __LOG_TESTER_H


#include "basics.h"

#define MAX_TEST_SIZE (5*PAGESIZE)


#define DEFAULT_TEST_BUFFER_SIZE (2*MAX_TEST_SIZE + 10)
#define FSYNC_START_TOKEN -23
#define FSYNC_END_TOKEN -34


int generateLogEntry(void* buffer, int bufferLength, int myId);

int checkForValidLogFile(const char* fileName);


void generateValidLogFileTest(int n);
void generateInvalidLogFileTest(int n);

#endif
