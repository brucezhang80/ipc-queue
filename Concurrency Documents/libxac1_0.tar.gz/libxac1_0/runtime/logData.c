#include <assert.h>
#include <stdlib.h>
#include "logData.h"


#define XBEGIN_TAG 0x1234
#define XCOMMIT_START_TAG 0x3456
#define XCOMMIT_FINISH_TAG 0x5678
#define XABORT_TAG 0x7890
#define CHECKPT_START_TAG 0x90AB
#define CHECKPT_FINISH_TAG 0xABCD
#define DATA_TAG 0xCDEF
#define EXTRA_TAG 0xEF01


dpPtr nullPagePtr(void) {
  dpPtr answer;
  answer.fileId = NULL_FILE_ID;
  answer.dp = UNMAPPED_PAGE;
  return answer;
}

int isNullPagePtr(dpPtr testPtr) {
  return ((testPtr.fileId == NULL_FILE_ID) &&
	  (testPtr.dp = UNMAPPED_PAGE));
}

int logPageContentsSize(void) {
  return sizeof(logPageContents);
}

logPageTag createLogTag(logPageType tp) {
  switch (tp) {
  case XBEGIN:
    return XBEGIN_TAG;
  case XCOMMIT_START:
    return XCOMMIT_START_TAG;
  case XCOMMIT_FINISH:
    return XCOMMIT_FINISH_TAG;
  case XABORT:
    return XABORT_TAG;    
  case CHECKPT_START:
    return CHECKPT_START_TAG;
  case CHECKPT_FINISH:
    return CHECKPT_FINISH_TAG;
  case DATA:
    return DATA_TAG;
  case EXTRA:
    return EXTRA_TAG;
  case INVALID:
  default:
    return 0;
  }
}

logPageType lpTypeFromTag(logPageTag tag) {
  switch(tag) {
  case XBEGIN_TAG:
    return XBEGIN;
  case XCOMMIT_START_TAG:
    return XCOMMIT_START;
  case XCOMMIT_FINISH_TAG:
    return XCOMMIT_FINISH;
  case XABORT_TAG:
    return XABORT;
  case CHECKPT_START_TAG:
    return CHECKPT_START;
  case CHECKPT_FINISH_TAG:
    return CHECKPT_FINISH;
  case DATA_TAG:
    return DATA;
  case EXTRA_TAG:
    return EXTRA;
  default:
    return INVALID;
  }
}

void printLogType(logPageType tempType) {
  //  logPageType tempType = lpTypeFromTag(tag);
  switch (tempType) {
  case XBEGIN:
    printf("XBEGIN");
    break;
  case XCOMMIT_START:
    printf("XCOMMIT_START");
    break;
  case XCOMMIT_FINISH:
    printf("XCOMMIT_FINISH");
    break;
  case XABORT:
    printf("XABORT");
    break;    
  case CHECKPT_START:
    printf("CHECKPT_START");
    break;
  case CHECKPT_FINISH:
    printf("CHECKPT_FINISH");
    break;
  case DATA:
    printf("DATA");
    break;
  case EXTRA:
    printf("EXTRA");
    break;    
  case INVALID:
  default:
    printf("INVALID");
  }
}


void initLogPageContents(logPageContents* lpc, logPageType pageType, int xactionId, int timeStamp) {
  assert(lpc != NULL);
  lpc->tag = createLogTag(pageType);
  
  lpc->header.checkTag = createLogTag(pageType);
  lpc->header.xactionId = xactionId;
  lpc->header.timeStamp = timeStamp;

  //  lpc->header.prevPage = nullPagePtr();
  lpc->header.nextPage = nullPagePtr();

  lpc->header.dataLength = 0;
}


void addPageToLPC(logPageContents* lpc, int xactionPage, dpPtr newPage) {
  
  assert(!lpcIsFull(lpc));
  
  

  lpc->pages[lpc->header.dataLength].xPage = xactionPage;
  lpc->pages[lpc->header.dataLength].page = newPage;
  lpc->header.dataLength++;
}

// Returns TRUE if we have filled up the log page
int lpcIsFull(logPageContents* lpc) {
  assert(lpc != NULL);
  return (lpc->header.dataLength >= PAGE_PTRS_PER_LOG_PAGE);

}
// Functions to point the log pages to each other.
void setNextLP(logPageContents* lpc, dpPtr nextPage) {
  lpc->header.nextPage = nextPage;
}

/* void setPrevLP(logPageContents* lpc, dpPtr prevPage) { */
/*   lpc->header.prevPage = prevPage; */
/* } */


logPageType getLogPageType(logPageContents* lpc) {
  if (lpc->tag != lpc->header.checkTag) {
    return INVALID;
  }
  return lpTypeFromTag(lpc->tag);
}

int getXactionIdFromLP(logPageContents* lpc) {
  return lpc->header.xactionId;
}
dpPtr getLPNextPage(logPageContents* lpc) {
  return lpc->header.nextPage;
}

/* dpPtr getLPPrevPage(logPageContents* lpc) { */
/*   return lpc->header.prevPage; */
/* } */

void printLPC(logPageContents* lpc) {
  int i;
  printf("lpc tag: 0x%llx =   ", lpc->tag);
  printLogType(lpTypeFromTag(lpc->tag));
  printf("\n");
  printf("xactionId = %d, timeStamp = %d\n", lpc->header.xactionId, lpc->header.timeStamp);
  printf("nextPage = (%d, %d),  prevPAge = (%d, %d)\n",
	 lpc->header.nextPage.fileId,
	 lpc->header.nextPage.dp,
	 -1, -1);
	 //	 lpc->header.prevPage.fileId,
	 //	 lpc->header.prevPage.dp);

  printf("Data length is %d\n", lpc->header.dataLength);

  for (i = 0; i < lpc->header.dataLength; i++) {
    printf("[xp %d --> (%d, %d)]  ", lpc->pages[i].xPage, lpc->pages[i].page.fileId, lpc->pages[i].page.dp);
  }

  printf("\n\n");
}

void resetXactionMDPtr(xactionMetaDataPtr* xmdPtr) {
  assert(xmdPtr != NULL);
  xmdPtr->xbeginAddr = NULL;
  xmdPtr->xendAddr1 = NULL;
  xmdPtr->xendAddr2 = NULL;
  xmdPtr->checkPtAddr1 = NULL;
  xmdPtr->checkPtAddr2 = NULL;
  xmdPtr->extraAddr = NULL;
  xmdPtr->numMetaDataPages = 0;

  xmdPtr->xbeginPage = nullPagePtr();
  xmdPtr->extraPage = nullPagePtr();
  xmdPtr->xendPage1 = nullPagePtr();
  xmdPtr->xendPage2 = nullPagePtr();
  xmdPtr->checkPtPage1 = nullPagePtr();
  xmdPtr->checkPtPage2 = nullPagePtr();
  
}

void updateXactionMDPtr(xactionMetaDataPtr* xmdPtr, logPageType lpType, dpPtr diskPage, void* addr, int numPages) {
  assert(xmdPtr != NULL);
  switch (lpType) {
  case XBEGIN:
    assert(numPages == 1);
    assert(xmdPtr->numMetaDataPages == 0);
    xmdPtr->xbeginAddr = addr;
    //      printf("Updated xbegin  to addr %p\n", addr);
    xmdPtr->xbeginPage = diskPage;
    break;
  case EXTRA:
    assert(numPages >= 1);
    xmdPtr->numMetaDataPages = numPages;
    xmdPtr->extraAddr = addr;
    xmdPtr->extraPage = diskPage;
    break;
  case XCOMMIT_START:
    assert(numPages == 1);
    xmdPtr->xendAddr1 = addr;
    //    printf("Updated commited start to addr %p\n", addr);
    xmdPtr->xendPage1 = diskPage;
    break;
  case XCOMMIT_FINISH:
    assert(numPages == 1);
    xmdPtr->xendAddr2 = addr;
    //    printf("Updated commited end to addr %p\n", addr);
    xmdPtr->xendPage2 = diskPage;
    break;
  case XABORT:
    assert(numPages == 1);
    xmdPtr->xendAddr1 = addr;
    xmdPtr->xendPage1 = diskPage;
    break;
  case CHECKPT_START:
    assert(numPages == 1);
    xmdPtr->checkPtAddr1 = addr;
    xmdPtr->checkPtPage1 = diskPage;
    break;
  case CHECKPT_FINISH:
    assert(numPages == 1);
    xmdPtr->checkPtAddr2 = addr;
    xmdPtr->checkPtPage2 = diskPage;
    break;
  case INVALID:
  default:
    printf("Bad lpType into reservePages\n");
    assert(FALSE);
  }
}

void* getCorrectAddr(xactionMetaDataPtr* xmdPtr, logPageType lpType) {
  switch(lpType) {
  case XBEGIN:
    return xmdPtr->xbeginAddr;
  case XABORT:
    return xmdPtr->xendAddr1;
  case XCOMMIT_START:
    return xmdPtr->xendAddr1;
  case XCOMMIT_FINISH:
    return xmdPtr->xendAddr2;
  case CHECKPT_START:
    return xmdPtr->checkPtAddr1;      
  case CHECKPT_FINISH:
    return xmdPtr->checkPtAddr2;
  case EXTRA:
    return xmdPtr->extraAddr;
  case DATA:
  case INVALID:
  default:
    return NULL;
  }
}

dpPtr getCorrectDiskPage(xactionMetaDataPtr* xmdPtr, logPageType lpType) {
 switch(lpType) {
  case XBEGIN:
    return xmdPtr->xbeginPage;
  case XABORT:
    return xmdPtr->xendPage1;
  case XCOMMIT_START:
    return xmdPtr->xendPage1;
  case XCOMMIT_FINISH:
    return xmdPtr->xendPage2;
  case CHECKPT_START:
    return xmdPtr->checkPtPage1;      
  case CHECKPT_FINISH:
    return xmdPtr->checkPtPage2;
  case EXTRA:
    return xmdPtr->extraPage;
  case DATA:
  case INVALID:
  default:
    return nullPagePtr();
  }
}

int firstLogFile(xactionMetaDataPtr* xmdPtr) {
  assert(xmdPtr->xbeginPage.fileId != NULL_FILE_ID);
  //  assert(xmdPtr->xbeginAddr != NULL);
  return xmdPtr->xbeginPage.fileId;
}

int lastLogFile(xactionMetaDataPtr* xmdPtr) {
  if (xmdPtr->xendPage2.fileId == NULL_FILE_ID) {
    assert(xmdPtr->xendPage1.fileId != NULL_FILE_ID);
    return xmdPtr->xendPage1.fileId;
  }
  else {
    return xmdPtr->xendPage2.fileId;
  }
}

/* int main(void) { */
/*   logPageContents lpStruct; */
/*   logPageContents*  lpc = &lpStruct; */
/*   dpPtr tempPage; */
/*   int i; */
/*   printf("The size of logPageContents structure is %d\n", logPageSize()); */
/*   printf("The number of log ptrs is %d\n", PAGE_PTRS_PER_LOG_PAGE); */

/*   initLogPageContents(lpc, XBEGIN, 1, 23); */

/*   tempPage.fileId = 13; */
/*   for (i = 0; i < 10; i++) { */
/*     tempPage.dp = i; */
/*     addPageToLPC(lpc, tempPage); */
/*   } */

/*   printLPC(lpc); */
  
/*   return 0; */
/* } */



void sprintLogType(logPageType tempType, char* buffer) {
  //  logPageType tempType = lpTypeFromTag(tag);
  switch (tempType) {
  case XBEGIN:
    sprintf(buffer, "XBEGIN");
    break;
  case XCOMMIT_START:
    sprintf(buffer, "XCOMMIT_START");
    break;
  case XCOMMIT_FINISH:
    sprintf(buffer, "XCOMMIT_FINISH");
    break;
  case XABORT:
    sprintf(buffer, "XABORT");
    break;    
  case CHECKPT_START:
    sprintf(buffer, "CHECKPT_START");
    break;
  case CHECKPT_FINISH:
    sprintf(buffer, "CHECKPT_FINISH");
    break;
  case DATA:
    sprintf(buffer, "DATA");
    break;
  case EXTRA:
    sprintf(buffer, "EXTRA");
    break;    
  case INVALID:
  default:
    sprintf(buffer, "INVALID");
  }
}
