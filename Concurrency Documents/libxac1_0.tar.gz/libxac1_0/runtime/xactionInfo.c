/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// xactionInfo.c

#include "xactionInfo.h"


static inline int getNextTimeStamp(xactionContext* xc) {
  return ++xc->theXinfoFLStruct->timeStampCounter;
}


static void xcClearTransactionItem(xactionContext* xc, int id) {
  xc->xactionArrayInUse[id] = FALSE;
  xc->transactionArray[id].id = id;
  xc->transactionArray[id].status = PENDING;
  xc->transactionArray[id].timeStamp = -1;

  xc->transactionArray[id].numPages = 0;
  xc->transactionArray[id].readSetIndex = NULL_INDEX;
  xc->transactionArray[id].writeSetIndex = NULL_INDEX;
}

/**
 * Sets up the table that maps ids to transactions.
 *  If useControlFile is TRUE, then we are allocating memory
 *   from the memory-mapped control file.  Otherwise, we just
 *   use malloc.
 */
void initXactionInfoTable(xactionContext* xc) {
  int count = 0;

  // The first transaction is special - it corresponds to main memory
  //  It never goes on the free list.

  xcClearTransactionItem(xc, 0);
  
  for (count = 0; count <= MAX_XACTIONS ; count++) {
    int i;
    
    xcClearTransactionItem(xc, count);
    if (count == 0) {
      xc->xactionArrayInUse[0] = TRUE;
      xc->transactionArray[0].status = COMMITTED_ON_DISK; //_ON_DISK;
    }
    else {
      xc->theXinfoFLStruct->freeList[count-1] = count;
      //      printf("Adding trans. id to free list: %d\n", xc->theXinfoFLStruct->freeList[count-1]);      
    }
    for (i = 0; i < MAX_PAGES; i++) {
      //      printf("Trying i = %d\n", i);
      xc->transactionArray[count].pageStatusCount[i] = NONE;
      xc->transactionArray[count].pagePtrs[i] = NULL_INDEX;
      xc->transactionArray[count].pageSet[i] = NULL_PAGE;
      xc->transactionArray[count].nextPage[i] = NULL_INDEX;
      xc->transactionArray[count].prevPage[i] = NULL_INDEX;
    }
  }
  
  xc->theXinfoFLStruct->freeListTop = 0;
}



/**
 * Gets the transaction information corresponding
 *  to a particular id, or NULL if no
 *   transaction matches.
 */
xactionInfo* getXactionFromId(xactionContext* xc, int id) {
  if ((id < 0) || (id > MAX_XACTIONS)) {
    return NULL;
  }

  if (xc->xactionArrayInUse[id] == TRUE) {
    return &xc->transactionArray[id];
  }
  else {
    return NULL;
  }
}

/**
 * Returns the status of the current transaction 
 *  (PENDING, FAILED, COMMITTED, or ABORTED)
 */
inline xactionStatus getXactionStatus(xactionContext* xc, int id) {
  if (!xc->xactionArrayInUse[id]) {
    fprintf(stderr, "Trying to get status of a transction %d that isn't in use. \n", id);
    printTransactionInfo(xc, id);
    assert(FALSE);
  }
  return xc->transactionArray[id].status;
}


/**
 * Sets the appropriate status field.
 */
void setXactionStatus(xactionContext* xc, int id, xactionStatus newStatus) {
  assert(xc->xactionArrayInUse[id]);
  xc->transactionArray[id].status = newStatus;
}



/**
 * Creates a new transaction that has status PENDING
 *  and has NULL read and write sets.
 * Returns the id of the transaction created (or -1
 *  if there was an error)
 */
int createTransactionInfo(xactionContext* xc) {

  int newId;
  
  // If no more items on the free list, fail.
  if (xc->theXinfoFLStruct->freeListTop == (MAX_XACTIONS)) {
    //    printf("ERROR!!!! No more transaction id's to give out...\n");
    //    assert(FALSE);
    return -1;
  }

  newId = xc->theXinfoFLStruct->freeList[xc->theXinfoFLStruct->freeListTop];
  xc->theXinfoFLStruct->freeListTop++;

  xcClearTransactionItem(xc, newId);

  assert(xc->xactionArrayInUse[newId] == FALSE);
  xc->xactionArrayInUse[newId] = TRUE;
  xc->transactionArray[newId].timeStamp = getNextTimeStamp(xc);
  return  newId;
}

/**
 * Deletes the information for the transaction
 *   corresponding to id.
 * Returns 0 if successfully deleted,
 *  or -1 if error (transaction wasn't found)
 */
int deleteTransactionInfo(xactionContext* xc, int id) {
  if (xc->xactionArrayInUse[id] == FALSE) {
    fprintf(stderr,
	    "Error! Trying to delete a transaction %dnot in use.\n",
	    id);
    assert(FALSE);	   
    return -1;
  }
  else {
    xc->xactionArrayInUse[id] = FALSE;
    xc->theXinfoFLStruct->freeListTop--;
    xc->theXinfoFLStruct->freeList[xc->theXinfoFLStruct->freeListTop] = id;
    return 0;
  }
}


int numberOfFreeXactionIds(xactionContext* xc) {
  return MAX_XACTIONS - xc->theXinfoFLStruct->freeListTop;
}

/**
 * Returns READING if transaction has pageNumber in readSet
 * Returns WRITING if pageNumbers is in writeSet
 * Otherwise, returns NONE.
 */
inline accessStatus pageStatusForXaction(xactionContext* xc, int id, int pageNumber) {
  assert(xc->xactionArrayInUse[id] == TRUE);
  return xc->transactionArray[id].pageStatusCount[pageNumber];
}


/**
 * Changes the access status for the specified page of the transaction
 *   to "stat".
 */
//inline void setPageStatusForXaction(int id, int pageNumber, accessStatus stat) {
//  xc->transactionArray[id].pageStatusCount[pageNumber] = stat;
//}



//  Add a page to the read or write set
//   of a transaction.
void addToReadSet(xactionContext* xc, int id,  int pageNumber) {
  int newIndex = xc->transactionArray[id].numPages;
  assert(xc->xactionArrayInUse[id] == TRUE);
  //  assert(addPageToList(&xc->transactionArray[id].readSet, (unsigned int)pageNumber) == SUCCESS);
  
  xc->transactionArray[id].pageStatusCount[pageNumber] = READING;

  // Insert the element
  xc->transactionArray[id].pageSet[newIndex] = pageNumber;

  // Update the ptr to the element
  xc->transactionArray[id].pagePtrs[pageNumber] = newIndex;


  // Insert at the head of the read list.
  xc->transactionArray[id].nextPage[pageNumber] = xc->transactionArray[id].readSetIndex;
  xc->transactionArray[id].prevPage[pageNumber] = NULL_INDEX;
  
  if (xc->transactionArray[id].readSetIndex != NULL_INDEX) {
    int originalPage = xc->transactionArray[id].pageSet[xc->transactionArray[id].readSetIndex];
    xc->transactionArray[id].prevPage[originalPage] = newIndex;
  }
  
  xc->transactionArray[id].readSetIndex = newIndex;
  xc->transactionArray[id].numPages++;
}

// Analogous to addToReadSet
void addToWriteSet(xactionContext* xc, int id, int pageNumber) {
 int newIndex = xc->transactionArray[id].numPages;
 assert(xc->xactionArrayInUse[id] == TRUE);

 xc->transactionArray[id].pageStatusCount[pageNumber] = WRITING;
 // Insert the element
 xc->transactionArray[id].pageSet[newIndex] = pageNumber;
 // Update the ptr to the element
 xc->transactionArray[id].pagePtrs[pageNumber] = newIndex;


 // Insert at the head of the write list.
 xc->transactionArray[id].nextPage[pageNumber] = xc->transactionArray[id].writeSetIndex;
 xc->transactionArray[id].prevPage[pageNumber] = NULL_INDEX;

 if (xc->transactionArray[id].writeSetIndex != NULL_INDEX) {
   int originalPage = xc->transactionArray[id].pageSet[xc->transactionArray[id].writeSetIndex];
   xc->transactionArray[id].prevPage[originalPage] = newIndex;
 }
 xc->transactionArray[id].writeSetIndex = newIndex;
 xc->transactionArray[id].numPages++;
}

/*
static int countReadSetLength(int id) {
  int count = 0;

  int currentPtr = transactionArray[id].readSetIndex;
  while (currentPtr != NULL_INDEX) {
    count++;
    currentPtr = transactionArray[id].nextPage[transactionArray[id].pageSet[currentPtr]];
  }

  return count;
}

static int countWriteSetLength(int id) {
  int count = 0;
  int currentPtr = transactionArray[id].writeSetIndex;
  while (currentPtr != NULL_INDEX) {
    count++;
    currentPtr = transactionArray[id].nextPage[transactionArray[id].pageSet[currentPtr]];
  }
  return count;
}

static void checkSetLength(int id, const char message[]) {
  int count;

  count = countReadSetLength(id) + countWriteSetLength(id);
  //  fprintf(stderr, "Values are: add up. %d + %d is not %d\n",
  //	  countReadSetLength(id),
  //	  countWriteSetLength(id),
  //	  transactionArray[id].numPages);
  //  printTransactionInfo(id);
    
  if (count != transactionArray[id].numPages) {
    fprintf(stderr, "Values dont' add up. %d + %d is not %d\n",
	    countReadSetLength(id),
	    countWriteSetLength(id),
	    transactionArray[id].numPages);
    printTransactionInfo(id);
    printf("We made it to this one: %s\n", message);
    assert(FALSE);
  }
}
*/

// Moves a page from the readset to the writeset.
void switchFromReadToWriteSet(xactionContext* xc, int id, int pageNumber) {

  // The pointer to the page in question
  int currentIndex = xc->transactionArray[id].pagePtrs[pageNumber];

  // The pointer to the previous node.
  int prevPtr = xc->transactionArray[id].prevPage[pageNumber];
  int nextPtr = xc->transactionArray[id].nextPage[pageNumber];

  //  checkSetLength(id, "switchBefore");
  assert(currentIndex != NULL_INDEX);
  assert((xc->xactionArrayInUse[id] == TRUE));
  //  assert(removePageFromList(&transactionArray[id].readSet, (unsigned int)pageNumber) == TRUE);
  //  assert(addPageToList(&transactionArray[id].writeSet, (unsigned int)pageNumber) == SUCCESS);
  
  xc->transactionArray[id].pageStatusCount[pageNumber] = WRITING;

  // Remove the element from the read set.  
  if (prevPtr != NULL_INDEX) {
    xc->transactionArray[id].nextPage[xc->transactionArray[id].pageSet[prevPtr]] = nextPtr;
  }
  else {
    xc->transactionArray[id].readSetIndex = nextPtr;
  }
  

  if (nextPtr != NULL_INDEX) {
    xc->transactionArray[id].prevPage[xc->transactionArray[id].pageSet[nextPtr]] = prevPtr;
  }
  
  // Now add to the write set.
  xc->transactionArray[id].nextPage[pageNumber] = xc->transactionArray[id].writeSetIndex;
  if (xc->transactionArray[id].writeSetIndex != NULL_INDEX) {
    int nextPage = xc->transactionArray[id].pageSet[xc->transactionArray[id].writeSetIndex];
    xc->transactionArray[id].prevPage[nextPage] = currentIndex;
  }

  xc->transactionArray[id].writeSetIndex = currentIndex;
  //  checkSetLength(id, "switchAfter");
}

// returns TRUE if the transaction has a copy of that page, before
//   its copy gets replaced.
inline int givePageToOtherXaction(xactionContext* xc, int id, int pageNumber, int newOwner) {
  //  assert(addPageToList(&xc->transactionArray[newOwner].writeSet, (unsigned int)pageNumber) == SUCCESS);

  int actuallyOwnedPage = TRUE;
  
  // If the other transaction doesn't own it, add it.
  if ((xc->transactionArray[newOwner].pageStatusCount[pageNumber] == NONE)) {
    int newIndex = xc->transactionArray[newOwner].numPages;
    int originalPage;


    //    xc->transactionArray[newOwner].pagePtrs[pageNumber] = newIndex;
    //    xc->transactionArray[newOwner].pagePtrs[pageNumber] = NULL_INDEX;
    xc->transactionArray[newOwner].pageSet[newIndex] = pageNumber;
    xc->transactionArray[newOwner].nextPage[pageNumber] = xc->transactionArray[newOwner].writeSetIndex;
    xc->transactionArray[newOwner].prevPage[pageNumber] = NULL_INDEX;

    if (xc->transactionArray[newOwner].writeSetIndex != NULL_INDEX) {
      originalPage = xc->transactionArray[newOwner].pageSet[xc->transactionArray[newOwner].writeSetIndex];
      xc->transactionArray[newOwner].prevPage[originalPage] = newIndex;
    } 

    xc->transactionArray[newOwner].writeSetIndex = newIndex;
    xc->transactionArray[newOwner].numPages++;
    actuallyOwnedPage = FALSE;
  }
  else {
    if ((xc->transactionArray[newOwner].pageStatusCount[pageNumber] == READING)) {
      printf("Are we doing this?\n");
      actuallyOwnedPage = FALSE;
      switchFromReadToWriteSet(xc, newOwner, pageNumber);
    }
  }

  xc->transactionArray[newOwner].pageStatusCount[pageNumber] = TRANSFER;
  xc->transactionArray[id].pageStatusCount[pageNumber] = NONE;
  return actuallyOwnedPage;

}


inline void clearPageStatusForXaction(xactionContext* xc, int id, int pageNumber) {
  xc->transactionArray[id].pageStatusCount[pageNumber] = NONE;
  xc->transactionArray[id].pagePtrs[pageNumber] = NULL_INDEX;
}



void printXactionStatus(xactionStatus status) {
  switch(status) {
  case FAILED:
    fprintf(stderr, "FAILED");
    break;
  case PENDING:
    fprintf(stderr, "PENDING");
    break;
  case ABORTED:
    fprintf(stderr, "ABORTED");
    break;
  case COMMITTED:
    fprintf(stderr, "COMMITTED");
    break;
  case COMMITTED_ON_DISK:
    fprintf(stderr, "COMMITTED_ON_DISK");
    break;
  default:
    fprintf(stderr, "ERROR!!");
    
  }
}


static void printReadWriteSets(xactionContext* xc, int id) {
  int count;
  for (count = 0; count < xc->transactionArray[id].numPages; count++) {
    int currentPage = xc->transactionArray[id].pageSet[count];

    fprintf(stderr, "(%d p:%d n:%d  ptr:%d), ",
	    currentPage,
	    xc->transactionArray[id].prevPage[currentPage],
    	    xc->transactionArray[id].nextPage[currentPage],
      	    xc->transactionArray[id].pagePtrs[currentPage]);	    
  }
  fprintf(stderr, "\nRStart = %d,  WStart = %d\n",
	  xc->transactionArray[id].readSetIndex,
	  xc->transactionArray[id].writeSetIndex);
}

void printTransactionInfo(xactionContext* xc, int id) {
  fprintf(stderr, "Id %d, Transaction %d: \n", id, xc->transactionArray[id].id);
  fprintf(stderr, "  timeStamp: %d, status =", xc->transactionArray[id].timeStamp);
  printXactionStatus(xc->transactionArray[id].status);

  fprintf(stderr, "\n");
  printReadWriteSets(xc, id);
  //  fprintf(stderr, "\n  RSet - ");
  //  printPageList(&xc->transactionArray[id].readSet);
  //  fprintf(stderr, "  WSet - ");
  //  printPageList(&xc->transactionArray[id].writeSet);  
}

/*************************************************************************/

void initPageInfoTable(xactionContext* xc) {
  int count;
  for (count = 0; count < MAX_PAGES; count++) {
    clearNodeList(&(xc->pageToXactionReads[count]));
    clearNodeList(&(xc->pageToXactionWrites[count]));
  }
}


void printPageAccessors(xactionContext* xc) {
  int count;
  fprintf(stderr, "\n(page, id): \n");
  for (count = 0; count < MAX_PAGES; count++) {
    fprintf(stderr, "Page %d accesses:  \n", count);
    fprintf(stderr, "     R - ");
    printNodeList(&xc->pageToXactionReads[count]);
    fprintf(stderr, "     W - ");
    printNodeList(&xc->pageToXactionWrites[count]);
  }
}

// We also keep track of the reverse direction.
//  For a given page, we can ask who is reading
//   or writing that page.
int addReaderForPage(xactionContext* xc, int id, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return addNodeToList(&xc->pageToXactionReads[pageNumber], (unsigned int)id);
}

int removeReaderForPage(xactionContext* xc, int id, int pageNumber) {
  int value;
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  value = removeNodeFromList(&xc->pageToXactionReads[pageNumber], (unsigned int) id);
  if (value == FALSE) {

    fprintf(stderr,
	    "Error!! trying to remove a reader , %d, for page %d but it doesn't exist.\n",
	    id,
	    pageNumber);
    printTransactionInfo(xc, id);
    assert(FALSE);
  }
  return value;
  //  return removeNodeFromList(&xc->pageToXactionReads[pageNumber], id);
}

int addWriterForPage(xactionContext* xc, int id, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return addNodeToList(&xc->pageToXactionWrites[pageNumber], (unsigned int)id);
}

int removeWriterForPage(xactionContext* xc, int id, int pageNumber) {
  int value;
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  value = removeNodeFromList(&xc->pageToXactionWrites[pageNumber], (unsigned int)id);

  if (value == FALSE) {
    fprintf(stderr,
	    "Error!! trying to remove a writer , %d, for page %d but it doesn't exist.\n",
	    id,
	    pageNumber);
    sleep(1000);
    assert(FALSE);
  }

  return value;
}

xactionNodeList* getReaders(xactionContext* xc, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return &xc->pageToXactionReads[pageNumber];
}

int getNumReaders(xactionContext* xc, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return xc->pageToXactionReads[pageNumber].length;
}


xactionNodeList* getWriters(xactionContext* xc, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return (xc->pageToXactionWrites + pageNumber);
  //  return &xc->pageToXactionWrites[pageNumber];
}
int getNumWriters(xactionContext* xc, int pageNumber) {
  assert((pageNumber >= 0) && (pageNumber < MAX_PAGES));
  return xc->pageToXactionWrites[pageNumber].length;
}



/**
 * For the specified transaction, this function
 *  goes through the transaction's readSet and
 *  removes those pages from the page->reader table.
 *
 * This means that the pages the transaction reads
 *  will no longer generate conflicts.
 */
void removeReadSetFromPageToReaderMap(xactionContext* xc, int id) {
  int touchedPage;
  int currentPtr;
  //  xactionInfo* currentTransInfo = getXactionFromId(xc, id);

  // Scan through readset.
/*   currentPtr = currentTransInfo->readSetIndex; */
/*   while (currentPtr != NULL_INDEX) { */
/*     touchedPage = currentTransInfo->pageSet[currentPtr]; */
/*     currentPtr = currentTransInfo->nextPage[touchedPage]; */
/*     removeReaderForPage(xc, id, touchedPage); */
/*   } */

  
  currentPtr = firstReadSetIndex(xc, id);
  while (!endOfReadSet(xc, id, currentPtr)) {
    touchedPage = currentReadSetPage(xc, id, currentPtr);
    removeReaderForPage(xc, id, touchedPage);
    currentPtr = nextReadSetIndex(xc, id, currentPtr);
  }
}



/**
 * For the specified transaction, this function
 *  goes through the transaction's writeSet and
 *  removes those pages from the page->writer table.
 *
 * This means that the pages the transaction writes
 *  will no longer generate conflicts.
 */
void removeWriteSetFromPageToWriterMap(xactionContext* xc, int id) {
/*   int touchedPage; */
/*   int currentPtr; */
/*   xactionInfo* currentTransInfo = getXactionFromId(xc, id); */

/*   // Scan through writeset. */
/*   currentPtr = currentTransInfo->writeSetIndex; */
/*   while (currentPtr != NULL_INDEX) { */
/*     touchedPage = currentTransInfo->pageSet[currentPtr]; */
/*     removeWriterForPage(xc, id, touchedPage);  */
/*     currentPtr = currentTransInfo->nextPage[touchedPage]; */
/*   } */

  int touchedPage, currentPtr;


  currentPtr = firstWriteSetIndex(xc, id);
  while (!endOfWriteSet(xc, id, currentPtr)) {
    touchedPage = currentWriteSetPage(xc, id, currentPtr);
    removeWriterForPage(xc, id, touchedPage);
    currentPtr = nextWriteSetIndex(xc, id, currentPtr);    
  }
}


inline int firstReadSetIndex(xactionContext* xc, int id) {
  return xc->transactionArray[id].readSetIndex;
}

inline int currentReadSetPage(xactionContext* xc, int id, int currentPtr) {
  return xc->transactionArray[id].pageSet[currentPtr];
}
inline int nextReadSetIndex(xactionContext* xc, int id, int currentPtr) {
  return xc->transactionArray[id].nextPage[currentReadSetPage(xc, id, currentPtr)];
}

inline int endOfReadSet(xactionContext* xc __attribute__((__unused__)),
			int id __attribute__((__unused__)),
			int currentPtr) {
  return  (currentPtr == NULL_INDEX);
}

inline int firstWriteSetIndex(xactionContext* xc, int id) {
  return xc->transactionArray[id].writeSetIndex;
}

inline int currentWriteSetPage(xactionContext* xc, int id, int currentPtr) {
  return xc->transactionArray[id].pageSet[currentPtr];
}
inline int nextWriteSetIndex(xactionContext* xc, int id, int currentPtr) {
  return xc->transactionArray[id].nextPage[currentWriteSetPage(xc, id, currentPtr)];
}

inline int endOfWriteSet(xactionContext* xc __attribute__((__unused__)),
			int id __attribute__((__unused__)),
			int currentPtr) {
  return  (currentPtr == NULL_INDEX);
}


// This is a really stupid implementation...
inline int writeSetLength(xactionContext* xc, int id) {
  int count = 0;
  int currentPtr = xc->transactionArray[id].writeSetIndex;
  while (currentPtr != NULL_INDEX) {
    count++;
    currentPtr = xc->transactionArray[id].nextPage[xc->transactionArray[id].pageSet[currentPtr]];
  }
  return count;
}





inline int getXactionTimeStamp(xactionContext* xc, int id) {
  return xc->transactionArray[id].timeStamp;
}
