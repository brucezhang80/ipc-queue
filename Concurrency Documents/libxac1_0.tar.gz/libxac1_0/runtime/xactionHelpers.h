/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * xactionHelpers.h
 *
 *  Contains helper functions for our implementing our
 *   transactional system.
 *
 */

#ifndef __XACTION_HELPERS_H
#define __XACTION_HELPERS_H


#include "xactionInfo.h"
#include "pageMap.h"
#include "libxac_client_types.h"

//#include "xactionMmap.h"


/**
 * Returns the id of the transaction who wrote the
 *  value of transaction page "pageNumber" that
 *  "currentXId" should see (or 0 if main memory
 *  has the last value.)
 *  This is the last ancestor in the tree that
 *   wrote to the page.
 */
int findLastWriter(int currentXId, int pageNumber);



void handlePageRead(xaction_local_context* xlc,
		    TID id,
		    int pageNumber,
		    int xactionIsStillPending,
		    int isReadOnly);

void handlePageWrite(xaction_local_context* xlc,
		     TID id,
		     int pageNumber,
		     int xactionIsStillPending,
		     int hasBeenRead);




void garbageCollectTransactions(xaction_local_context* xlc, int force);
void finalGarbageCollectTransactions(xaction_local_context* xlc);


void handleXactionCommit(xaction_local_context* xlc,
			 TID id,
			 int isDurable);

void handleXactionCommitStage2(xaction_local_context* xlc,
			       TID id);

void handleXactionCommitStage3(xaction_local_context* xlc,
			       TID id);


void handleXactionAbort(xaction_local_context* xlc,
			TID id, int isDurable);

void handleReadOnlyCommit(xaction_local_context* xlc,
			  TID id);

void generateLogEntryForCommit(xactionContext* xc,
			       xaction_local_context* xlc,
			       TID currentXId,
			       int isDurable);

void xactionCommitHelper(xactionContext* xc,
			 xaction_local_context* xlc,
			 TID id);

void xactionAbortHelper(xactionContext* xc,
			xaction_local_context* xlc,
			TID id);

void xactionCommitReadOnlyHelper(xaction_local_context* xlc);


#endif

