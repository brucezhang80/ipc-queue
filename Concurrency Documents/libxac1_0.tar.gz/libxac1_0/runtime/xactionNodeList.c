/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */



/**
 * xactionNodeList.c
 *
 *  Maintains a list of transaction ids.  The implementation is inefficient at the
 *   moment.
 */


#include <assert.h>
#include <stdio.h>

#define FALSE 0
#define TRUE 1

#include "intList.h"
#include "xactionNodeList.h"
//#include "xactionMmap.h"
#include "xactionInfo.h"

#ifdef USE_BIT_NODELIST


/*****************************************************************/
/* Bit-vector implementation of a nodeList.
 *
 * 8/23/04: Still broken.  Don't use it yet.
 *****************************************************************/

// Debruijn indexing magic.  See paper on SuperTech website by Leiserson, Prokop, Randall
#define debruijn32 0x077CB531UL
static int index32[32] = {0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8, 31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9, };


/*
  int index32[32];

  // The setup function that actually generated index32[]
void setup(void) {
  int i;

  for (i = 0; i < 32; i++) {
    index32[(debruijn32 << i) >> 27] = i;
  }

  printf("index32 = {");
  for (i = 0; i < 32; i++) {
    printf("%d, ", index32[i]);
  }
  printf("};\n");
}
*/

static inline int rightmost_index(unsigned int b) {
  b &= -b;
  b *= debruijn32;
  b >>= 27;
  return index32[b];
}


static inline void clear_rightmost_index(unsigned int* b) {
  *b -= ((*b) & -(*b));
}

static inline int getRightmostIndexAndClear(unsigned int* b) {
  unsigned int h;
  h  = (*b) & -(*b);
  *b -= h;
  //  printf("h here is %x\n", h);
  h *= debruijn32;
  h >>= 27;
  return index32[h];
}


#define COMPUTE_MASK(num) (1U << ((num)%(INT_SIZE)))

/**
 * Clears an existing xactionNodeListstructure
 *  (effectively removing all the elements)
 */
void clearNodeList(xactionNodeList* list) {
  int count;
  // fprintf(stderr, "Attempgint to celar page list of size %d.\n", NUM_BIT_VECTORS);
  list->length = 0;
  for (count = 0; count < NUM_NL_BIT_VECTORS; count++) {
    list->bitArray[count] = 0;
  }
}


/**
 * Adds the specified page to the list, if
 *   it is not already there.
 * Returns -1 if there is an error
 *  (list is full),  0 otherwise.
 */
int addNodeToList(xactionNodeList* list, unsigned int nodeId) {
  unsigned int count = (nodeId)/(INT_SIZE);
  unsigned int mask = COMPUTE_MASK(nodeId);


  //  printf("Trying to add page %d to list. count is %d, mask is %d\n",
  //	 nodeId, count, mask);
  if (nodeId > MAX_XACTIONS) { //NUM_NL_BIT_VECTORS*(INT_SIZE)) {
    printf("Error! trying to add %u that is out of range\n", nodeId);
    return -1;
  }
  //  printf("Adding %d,  case, count is %d.  The mask is %x\n", nodeId, count, mask);
  if ((list->bitArray[count] & mask) == 0) {
    list->length++;
  }
  list->bitArray[count] |= mask;  
  return 0;
}


/** Returns TRUE if pageNum was removed from the list. **/
int removeNodeFromList(xactionNodeList* list, unsigned int nodeId) {
  unsigned int count = (nodeId)/(INT_SIZE);
  unsigned int mask = COMPUTE_MASK(nodeId);

  if (nodeId > MAX_XACTIONS) {
    fprintf(stderr, "Error! trying to remove a page %d from list, bigger than %d\n", nodeId, MAX_PAGES);
    //    sleep(1000);
    assert(FALSE);
  }
  // Look inside bit array.
  if ((list->bitArray[count] & mask) != 0) {
    // If we find it, decrement length, clear mask.
    //    printf("We are clearing the mask for page %d, mask is %x\n", nodeId, mask);
    list->length--;
    //    printf("list->bitArray[coutn] startrs as %x\n", list->bitArray[count]);
    list->bitArray[count] ^= mask;
    //    printf("list->bitArray[coutn] is now %x\n", list->bitArray[count]);
    return TRUE;
  }

  return FALSE;
}


/** Returns TRUE if specified page is in the list **/
int containsNode(xactionNodeList* list, unsigned int nodeId) {
  unsigned int count = (nodeId)/(INT_SIZE);
  unsigned int mask = COMPUTE_MASK(nodeId);
  
  return ((list->bitArray[count] & mask)  != 0);
}


/** Returns TRUE if the list is empty. **/
int nodeListIsEmpty(xactionNodeList* list) {
  return (list->length == 0);
}

/** Returns the length of list **/
int getNodeListLength(xactionNodeList* list) {
  return list->length;
}


// Prints out the contents of the list to stderr
void printNodeList(xactionNodeList* list) {
  if (list == NULL) {
    fprintf(stderr, "BitList %p is NULL.\n", list);
  }
  else {
    nodeListIterator itPtr;

    resetNodeListIterator(list, &itPtr);

    fprintf(stderr, "NodeList %p[%d]:  ", list, list->length);
    while (!endOfNodeList(list, &itPtr)) {
      int currentNode = getCurrentNode(list, &itPtr);
      fprintf(stderr, "%d ", currentNode);
      advanceNodeListIterator(list, &itPtr);
    }
    fprintf(stderr, "\n");
  }
}


// Prints out the contents of the list to stderr
void printNodeListPlain(xactionNodeList* list) {
  if (list == NULL) {
    fprintf(stderr, "BitList %p is NULL.\n", list);
  }
  else {
    int count;
    fprintf(stderr, "BitList %p[%d]:  ", list, list->length);
    for (count =0; count < NUM_NL_BIT_VECTORS;  count++) {
      fprintf(stderr, "%x ", list->bitArray[count]);
    }
    fprintf(stderr, "\n");
  }
}


// A mechanism for iterating through the list.
inline void resetNodeListIterator(xactionNodeList* list, nodeListIterator* it) {
  it->currentLength = 0;
  it->countIndex = 0;
  it->currentMask = list->bitArray[0];

  while ((it->currentMask == 0)
	 && (it->currentLength < list->length)
	 && (it->countIndex < NUM_NL_BIT_VECTORS)) {
    it->countIndex++;
    it->currentMask = list->bitArray[it->countIndex];
  }
}

// returns value at the iterator AND advances the iterator to the
//   next value
inline int getCurrentNode(xactionNodeList* list __attribute__((__unused__)), nodeListIterator* it) {
  // This calculates the index of the current 1 we are
  //  looking at in the bit vector.  This also clears
  //  the 1 from that spot in currentMask.
  int bitindex = rightmost_index(it->currentMask);
  int answer = bitindex + (it->countIndex)*(INT_SIZE);

 /*  printNodeListPlain(list); */
/*   printf("our current mask was %d\n", (it->currentMask)); */
/*   printf("our current mask was %d, countindex %d\n", (it->currentMask), it->countIndex); */
/*   printf("our iterator is retruning as answer %d\n", answer); */
/*   printNodeListPlain(list); */

/*   printf("Size is %d\n", NUM_NL_BIT_VECTORS); */
  return answer;
}


inline void advanceNodeListIterator(xactionNodeList* list, nodeListIterator* it) {
  clear_rightmost_index(&it->currentMask);
  it->currentLength++;
  // If the currentMask is now 0.
  if (it->currentMask == 0) {
    // Find the next bit vector that isn't zero.
    
/*     printf("Getting here. now what? \n"); */
/*     printf("%d < %d?  \n", it->currentLength, list->length); */
/*     printf("count index is now %d\n", it->countIndex); */
/*     printf("bitArray[countIndex] == %x\n", list->bitArray[it->countIndex]); */

    do {
      it->countIndex++;
    }
    while ((it->currentLength < list->length)
	   && (list->bitArray[it->countIndex] == 0)
	   && (it->countIndex < NUM_NL_BIT_VECTORS));

    // Set the currentMask to be that value.
    it->currentMask = list->bitArray[it->countIndex];
  }
}


// gets the current page and removes from the list.
inline int popCurrentNode(xactionNodeList* list, nodeListIterator* it) {
  int bitindex = rightmost_index(it->currentMask) ;
  int answer = bitindex + (it->countIndex)*(INT_SIZE);
  int bef, aft;

  //  printf("calling popCurrent page. stop! \n");
  //  printNodeListPlain(list);
  
  //  assert(FALSE);
  bef = list->bitArray[it->countIndex];
  printf("Before: at index %d -- %d\n", it->countIndex, bef);
  clear_rightmost_index(&list->bitArray[it->countIndex]);
  aft = list->bitArray[it->countIndex];
 printf("after: at index %d -- %d\n", it->countIndex, aft);

  if ((bef != 0) && (bef == aft)) {
    fprintf(stderr, "bAd!\n");
    sleep(1000);
  }
  
  //  list->bitArray[it->countIndex] = it->currentMask;
  //  printf("list length before is %d\n", list->length);
  list->length--;
  
  // This is sort of a hack... for getCurrentNode,
  //  in the advanceNodeListIterator method, we increment it->currentLength.
  // In popCurrentNode, we want to decrement list->length.
  //  But this is to keep the same advanceNodeListIterator() method.
  it->currentLength--;

/*   printf("list length after is %d\n", list->length); */

/*   printf("Our iterator stats.: \n"); */
/*   printf("countINdex: %d\n", it->countIndex); */
/*   printf("current length: %d\n", it->currentLength); */
/*   printf("current mask: %x\n", it->currentMask); */
   
/*   // If the currentMask is now 0.  */
/*   if (it->currentMask == 0) { */
/*     // Find the next bit vector that isn't zero. */
    
/*     do { */
/*       it->countIndex++; */
/*     } */
/*     while ((it->currentLength < list->length) */
/* 	   && (list->bitArray[it->countIndex] == 0) */
/* 	   && (it->countIndex < NUM_NL_BIT_VECTORS)); */

/*     // Set the currentMask to be that value. */
/*     it->currentMask = list->bitArray[it->countIndex]; */
/*   } */

  //  printf("After.\n");
  //  printNodeListPlain(list);
  return answer;
}


inline int endOfNodeList(xactionNodeList* list __attribute__((__unused__)), nodeListIterator* it) {
  //  printf("We are calling endOfNodeList here. \n");
  return ((it->currentLength >= list->length)
	  || ((it->countIndex == NUM_NL_BIT_VECTORS) &&(it->currentMask == 0)));
}


#else

/**********************************************************
 *  Array implementation of a node list.
 *********************************************************/

/** Clears the node list **/
void clearNodeList(xactionNodeList* list) {
  list->length = 0;
}


/**
 * Adds a page to the list, if it is not already there.
 * Returns -1 if there is an error, 0 otherwise.
 */
int addNodeToList(xactionNodeList* list, unsigned int nodeId) {
  if (list->length < MAX_XACTIONS) {    
    return addIntToList(list->nodeArray, &list->length, (int)nodeId);
  }
  else {
    fprintf(stderr, "xactionNodeList at %p is full.\n", list);
    return -1;
  }
}

/** Returns TRUE if the page is in the list. **/
int containsNode(xactionNodeList* list, unsigned int nodeId) {
  return containsInt(list->nodeArray, &list->length, (int)nodeId);
}


/** Returns TRUE if we removed a copy of nodeId from the list **/
int removeNodeFromList(xactionNodeList* list, unsigned int nodeId) {
  if (nodeId > 0) {
    if (list->length > 0) {
      return removeIntFromList(list->nodeArray, &list->length, (int)nodeId);
    }
    else {
      fprintf(stderr, "xactionNodeList at %p is empty\n", list);
      fprintf(stderr, "We are trying to remove a node %d \n", nodeId);
      //      printDepTree();
      //      printXactionMmap();
      //      printReferenceCount();
      //      printTransactionInfo((int)nodeId);
      //      assert(FALSE);
      return FALSE;
    }
  }

  fprintf(stderr, "Error!!! we are removing the node 0. bad...\n");
  sleep(1000);
  assert(FALSE);
  return FALSE;
}





// Prints out the contents of the list to stderr
void printNodeList(xactionNodeList* list) {
  if (list == NULL) {
    fprintf(stderr, "NodeList %p is NULL.\n", list);
  }
  else {
    int count;
    fprintf(stderr, "NodeList %p[%d]:  ", list, list->length);
    for (count = 0; count < list->length; count++) {
      fprintf(stderr, "%d ", list->nodeArray[count]);
    }
    fprintf(stderr, "\n");
  }
}


// A mechanism for iterating through the children
inline void resetNodeListIterator(xactionNodeList* list, nodeListIterator* it) {
  //  list->iterator = list->length-1;
  *it = list->length - 1;
  
}

// returns value at the current iterator.
inline int getCurrentNode(xactionNodeList* list, nodeListIterator* it) {
  //  return list->nodeArray[list->iterator];
  return list->nodeArray[*it];
}

// gets the current child id and removes from the list.
inline int popCurrentNode(xactionNodeList* list, nodeListIterator* it) {

  /*
  int currentChild = list->nodeArray[list->iterator];
  int movCount, nodeIndex;
  nodeIndex = list->iterator+1;
  for (movCount = nodeIndex; movCount < list->length; movCount++) {
    // Shift everything else over by 1.
    list->nodeArray[movCount-1] = list->nodeArray[movCount];
  }
  list->length--;

  */

  int currentChild = list->nodeArray[*it];
  int movCount, nodeIndex;
  nodeIndex = *it+1;
  for (movCount = nodeIndex; movCount < list->length; movCount++) {
    // Shift everything else over by 1.
    list->nodeArray[movCount-1] = list->nodeArray[movCount];
  }
  list->length--;
  
  return currentChild;
}


inline void advanceNodeListIterator(xactionNodeList* list __attribute__((__unused__)), nodeListIterator* it) {
  (*it)--;
  //  list->iterator--;
}

inline int endOfNodeList(xactionNodeList* list __attribute__((__unused__)), nodeListIterator* it) {
  return (*it < 0);
  //  return (list->iterator < 0);
}

#endif

#undef FALSE
#undef TRUE
