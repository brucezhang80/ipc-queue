/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * globalControl.c
 *
 */


#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "basics.h"
#include "commitBuffer.h"
#include "globalControl.h"
#include "lbxc_malloc.h"
#include "lockTest.h"
#include "pageMap.h"
#include "xDep.h"
#include "xStats.h"


#define FILE_NAME_LENGTH 100
#define INIT_CONTROL_FILE_LENGTH ((size_t)1024  *(size_t)(PAGESIZE))

static const char base_lockFileName[] = "LibxacLockFile";
static const char base_controlFileName[] = "LibxacControlFile";
static const char base_control_prefix[] = LIBXAC_DEFAULT_PATH;

// These are global variables that get set when someone sets up 
//  the control file.
char control_file_name[FILE_NAME_LENGTH];
char lock_file_name[FILE_NAME_LENGTH];
char control_prefix[FILE_NAME_LENGTH];


static void fill_name(const char* base, const char* path, char* buffer) {
  if (path == NULL) {
    snprintf(buffer, FILE_NAME_LENGTH, "%s", base);
  }
  else {
    snprintf(buffer, FILE_NAME_LENGTH, "%s/%s", path, base);
  }

  //  printf("Filled in name: %s\n", buffer);
}

/**
 * This function creates an empty control file of  "numPages" long,
 *  up to (or MAX_FILE_PAGES).  
 * If the file already exists, then we lengthen the existing file.
 * Returns 0 if succeeded, -1 otherwise.
 */
static int extendControlFile(const char* cfFileName, int numPages) {
  int count;
  size_t fileSize;
  int additionalSize;
  int xactionControlFileLength;
  char emptyArray[PAGESIZE];
  int tempControlFd;
  
  tempControlFd = open(cfFileName, O_RDWR | O_CREAT, 0666);
  if (tempControlFd == -1) {
    fprintf(stderr, "Error opening %s.\n", cfFileName);
    xactionControlFileLength = 0;
    return -1;
  }

  fileSize = lseek(tempControlFd, (off_t)0, SEEK_END);  
  xactionControlFileLength = fileSize/PAGESIZE;


  if (numPages > MAX_FILE_PAGES) {
#if GLB_CONTROL_DB_PRINT == 1
    fprintf(stderr, "Control file: Can not use more than %d pages.\n", MAX_FILE_PAGES);
#endif
    return -1;
  }
  
  additionalSize = numPages - xactionControlFileLength;

#if GLB_CONTROL_DB_PRINT == 1
  fprintf(stderr, "NumPages is %d, file Length is %d\n", numPages, xactionControlFileLength);
  fprintf(stderr, "additional size is %d\n", additionalSize);
#endif
  
  if (additionalSize > 0) {
    
#if GLB_CONTROL_DB_PRINT == 1
    printf("The file is not large enough. lengthening Control file.\n");
    printf("We have %d pages, we want %d pages.\n", xactionControlFileLength, numPages);
#endif
    
    for (count = 0; count < additionalSize; count++) {
      
#if GLB_CONTROL_DB_PRINT == 1
      fprintf(stderr, "Writing page at %d, stopping at %d\n", count, additionalSize);
#endif
      write(tempControlFd, (void*) &emptyArray, (size_t)PAGESIZE);
    }
  }
  else {
#if GLB_CONTROL_DB_PRINT == 1    
    fprintf(stderr, "The control file is big enough already.\n");
#endif
  }

  // Set length to be max
  if (xactionControlFileLength < numPages) {
    xactionControlFileLength = numPages;
  }
#if GLB_CONTROL_DB_PRINT == 1
  fprintf(stderr, "The final control file size after create is %d\n", xactionControlFileLength);
#endif
  
  close(tempControlFd);
  return 0;
}


// Must be true that the control file is already open.
static OFFSET_PTR cfile_malloc_helper(size_t size,
				      void** cfile_addr,
				      int control_file_fd) {

  int error;
  OFFSET_PTR answer = 0;
  assert(cfile_addr != NULL);
  assert(*cfile_addr != NULL);

  while (answer == 0) {    
    answer = lbxc_malloc(size, *cfile_addr);
    if (answer == 0) {
      //      printf("start of resize...the address we care about is %p\n", *cfile_addr);
      // Resize the arena and file and try again.
      size_t current_size = lbxc_arena_length(*cfile_addr);
      size_t new_size;

      // Unmap the old arena.
      error = munmap(*cfile_addr,
		     page_length_ceil(current_size));

      
      new_size = page_length_ceil(current_size * 2.5);
      //      printf("Resizing arena. old size is %zd, new size is %zd\n",
      //	     current_size, new_size);

      // Make sure the file is long enough.
      extendControlFile(control_file_name, 
			new_size/PAGESIZE);

      //      printf("Remapping the file to length %zd\n", new_size);
      // Remap the file.
      *cfile_addr = mmap(*cfile_addr,
			 new_size,
			 PROT_READ | PROT_WRITE,
			 MAP_SHARED,
			 control_file_fd,
			 (off_t)0);
      assert((*cfile_addr) != MAP_FAILED);

      // Resize the arena.
      lbxc_arena_grow(new_size, *cfile_addr);

      //     printf("Here, the address we care about is %p\n", *cfile_addr);
      //      printf("Done. Increased arena size to %zd\n",
      //	     lbxc_arena_length(*cfile_addr));
    }
  }
  return answer;  
}


// A malloc that returns a pointer to the control region.
OFFSET_PTR cfile_malloc(size_t size,
			xactionContext* xc) {

  OFFSET_PTR temp;
  assert(xc != NULL);
  temp = cfile_malloc_helper(size,
			     &(xc->controlRegion),
			     xc->controlFd);
  return temp;
}


int cfile_free(OFFSET_PTR p, xactionContext* xc) {
  assert(xc != NULL);
  return lbxc_free(p, xc->controlRegion);
}




static void setContextAddresses(xactionContext* xc,
				cfile_ptrs* dataPtrs, 
				void* base_addr) { 
  assert(xc->controlRegion == base_addr);
  xc->xactionGlobal = OFFSET_TO_PTR(dataPtrs->xcGlobalLock, base_addr);
#ifdef USE_LSN  
  xc->lsnNumLock = OFFSET_TO_PTR(dataPtrs->lsn_num_lock, base_addr);
  xc->lsnPtr = OFFSET_TO_PTR(dataPtrs->lsn_counter, base_addr);
  xc->lsnLastCommitted = OFFSET_TO_PTR(dataPtrs->lsn_last_committed, base_addr);
#endif


  xc->transactionArray = OFFSET_TO_PTR(dataPtrs->actualTransactionArray, base_addr);
  xc->xactionArrayInUse = OFFSET_TO_PTR(dataPtrs->actualXactionArrayInUse, base_addr);
  xc->pageToXactionReads = OFFSET_TO_PTR(dataPtrs->actualPageToXactionReads,
					 base_addr);

  xc->pageToXactionWrites = OFFSET_TO_PTR(dataPtrs->actualPageToXactionWrites,
					  base_addr);

  xc->theXinfoFLStruct = OFFSET_TO_PTR(dataPtrs->actualXInfoFLStruct,
				       base_addr);

  //  printf("Halfway done with attach\n");

  xc->t = OFFSET_TO_PTR(dataPtrs->actualT, base_addr);
  xc->theMmap = OFFSET_TO_PTR(dataPtrs->actualMmap, base_addr);
  xc->glf = OFFSET_TO_PTR(dataPtrs->actualGLF, base_addr);

  xc->glf->logManagerLock = OFFSET_TO_PTR(dataPtrs->actualLogManagerLock,
					  base_addr);

  xc->gcbf = OFFSET_TO_PTR(dataPtrs->actualGCBF,
			   base_addr);


  // Testing the global file directory.
  xc->gfiledir = OFFSET_TO_PTR(dataPtrs->actualGFileDir,
			       base_addr);
  //  printf("Done with setContext!\n");    
}


xactionContext* attachControlRegion(void) {

  size_t current_cfile_size;
  int error;
  xactionContext* tempContext = (xactionContext*)malloc(sizeof(xactionContext));
  assert(tempContext != NULL);
 
  tempContext->controlFd = open(control_file_name, O_RDWR, 0666);


  // Now mmap the file, and figure out what the right size is.
  //  (We might have to mmap twice)
  tempContext->controlRegion = mmap(0,
				    (size_t)INIT_CONTROL_FILE_LENGTH,
				    PROT_READ | PROT_WRITE,
				    MAP_SHARED,
				    tempContext->controlFd, 
				    (off_t)0);

  assert(tempContext->controlRegion != MAP_FAILED);
  
  current_cfile_size = lbxc_arena_length(tempContext->controlRegion);
  if (current_cfile_size > (INIT_CONTROL_FILE_LENGTH)) {
    //    printf("On attach, we need to open a bigger control file.\n");
    error = munmap(tempContext->controlRegion, (INIT_CONTROL_FILE_LENGTH));
    assert(error == 0);

    tempContext->controlRegion =
      mmap(tempContext->controlRegion,
	   current_cfile_size,
	   PROT_READ | PROT_WRITE,
	   MAP_SHARED,
	   tempContext->controlFd,
	   (off_t)0);
    assert(tempContext->controlRegion != MAP_FAILED);
  }

  // Once the control file is mmaped in and the base address pointer
  //   is fixed, actually set all the addresses in the context.


  setContextAddresses(tempContext,
		      (cfile_ptrs*)lbxc_arena_control_data_ptr(tempContext->controlRegion),
		      tempContext->controlRegion);  

  return tempContext;
}


/**
 * This function is called after we have finished accessing the control
 *  file.  Munmaps the control region and closes the control file.
 */
void detachControlRegion(xactionContext* xc) {

  int error;
//  printf("Before msync...\n");
//  msync(controlFileRegion, (size_t)CF_FILE_LENGTH*PAGESIZE, MS_SYNC);
//  printf("After msync...\n");
//  munmap(controlFileRegion, (size_t)CF_FILE_LENGTH*PAGESIZE);


  assert(xc->controlRegion != NULL);
  error = munmap(xc->controlRegion,
		 lbxc_arena_length(xc->controlRegion));
  assert(error == 0);
  //  free(xc->mfd);
  //  destroyCommitBuffer(xc->cbf);

  close(xc->controlFd);
  free(xc);
  
}




/** Sets up global lock. Should
 *  only be done once for all processes
 */
static void initGlobalXactionLock(xactionContext* xc) {
  Cilk_lock_init(*(xc->xactionGlobal));
  assert((*(xc->xactionGlobal))[0] == 0);

//  Cilk_lock_init(*(xc->gbcollectLock));
//  assert((*(xc->gbcollectLock))[0] == 0);
}

#ifdef USE_LSN
#define LSN_START 10231

static void initLSNLock(xactionContext* xc) {
    Cilk_lock_init(*(xc->lsnNumLock));
    assert((*(xc->lsnNumLock))[0] == 0);
    *(xc->lsnPtr) = LSN_START;
    *(xc->lsnLastCommitted) = LSN_START - 1;
}
#endif





int setupControlFile(const char* path, int is_durable) {
  int error;
  int lockFd;
  int controlFileFd;

  void* cfile_addr;
  struct stat  sbuf;
  cfile_ptrs* dataPtrs;

  if (path != NULL) {
    //    printf("Callking mkdir on %s\n", path);
    mkdir(path, 0777);
    strncpy(control_prefix, path, FILE_NAME_LENGTH);
    errno = 0;

    error = stat(path, &sbuf);
    assert(error == 0);
    assert(errno == 0);
  }
  else {
    // Copy and store the path that the user passed in.
    strncpy(control_prefix, base_control_prefix, FILE_NAME_LENGTH);
  }

  fill_name(base_controlFileName, path, control_file_name);
  fill_name(base_lockFileName, path, lock_file_name);

  printf("Now the control prefix is %s\n", control_prefix);

  printf("path is %s\nControlFile is %s\nLockfile is %s\n",
	 control_prefix,
	 control_file_name,
	 lock_file_name);

  

  // Grab a (file) lock), so we never call setup concurrently

  lockFd = open(lock_file_name, O_RDWR | O_CREAT, 0666);
  //  printf("About to acquire file lock on fd %d \n", lockFd);
  assert(lockFd != -1);
  assert(errno == 0);
  flock(lockFd, LOCK_SH);

  
  // Create the control file.
  error = extendControlFile(control_file_name,
			    INIT_CONTROL_FILE_LENGTH/PAGESIZE);
  if (error != 0) {
    fprintf(stderr, "Error creating control file!\n");
    assert(FALSE);
  }

  // Open the control file and then memory-map it.
  controlFileFd = open(control_file_name, O_RDWR, 0666);
  assert(controlFileFd != -1);


  
  cfile_addr = mmap(0,
		    (size_t)INIT_CONTROL_FILE_LENGTH,
		    PROT_READ | PROT_WRITE,
		    MAP_SHARED,
		    controlFileFd,
		    (off_t)0);

  assert(cfile_addr != MAP_FAILED);


  // Initialize malloc in the control file.
  error = lbxc_arena_init(INIT_CONTROL_FILE_LENGTH,
			  (void*)cfile_addr);

  assert(error == 0);

  //  printf("What is sizeof data ptrs? %zd.  lbxc space for control data? %zd\n",
  //	 sizeof(*dataPtrs),
  //	 lbxc_arena_control_data_size(cfile_addr));

  
  // Set the pointer offsets to the control data structures.
  assert(sizeof(cfile_ptrs) < lbxc_arena_control_data_size(cfile_addr));  
  dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);

  
  // Actually allocate space for the control data structures now.



  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(Cilk_lockvar),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->xcGlobalLock = temp;
    //    printf("switched pointer... global_address is %p\n", cfile_addr);
  }

#ifdef USE_LSN
  {
    OFFSET_PTR temp = cfile_malloc_helper(sizeof(Cilk_lockvar),
					  &cfile_addr,
					  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->lsn_num_lock = temp;
  }
  
  {
    OFFSET_PTR temp = cfile_malloc_helper(sizeof(unsigned long long),
					      &cfile_addr,
					      controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->lsn_counter = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(unsigned long long),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->lsn_last_committed = temp;
  }
#endif
  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(xactionInfo)*(MAX_XACTIONS+1),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualTransactionArray = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(int)*(MAX_XACTIONS+1),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualXactionArrayInUse = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(xinfoFreeListStruct),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualXInfoFLStruct = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(xactionNodeList) * (size_t)MAX_PAGES,
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualPageToXactionReads = temp;
  }
  
  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(xactionNodeList) * (size_t)MAX_PAGES,
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualPageToXactionWrites = temp;
  }  
  {
    OFFSET_PTR temp =  cfile_malloc_helper(sizeof(xDepTree),
					   &cfile_addr,
					   controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualT =temp;
  }

  {
    OFFSET_PTR temp = cfile_malloc_helper(sizeof(xactionMmap),
					  &cfile_addr,
					  controlFileFd);

    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualMmap = temp;
  }

  {
    OFFSET_PTR temp = cfile_malloc_helper(sizeof(globalLogFileInfo),
					  &cfile_addr,
					  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualGLF = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(Cilk_lockvar),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualLogManagerLock = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(globalCommitBuffer),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualGCBF = temp;
  }

  {
    OFFSET_PTR temp =
      cfile_malloc_helper(sizeof(global_file_directory),
			  &cfile_addr,
			  controlFileFd);
    dataPtrs = (cfile_ptrs*)lbxc_arena_control_data_ptr(cfile_addr);
    dataPtrs->actualGFileDir = temp;    
  }

  //  printf("cfile_malloc'ed the space for everything!\n");
  error = munmap((void*)cfile_addr, page_length_ceil(lbxc_arena_length(cfile_addr)));
  assert(error == 0);
  error = close(controlFileFd);
  assert(error == 0);

  //  printf("Now actually do the initialization...\n");

  {
    xactionContext* xc;
    xc = attachControlRegion();
    assert(xc != NULL);

    
    initGlobalXactionLock(xc);
#ifdef USE_LSN
    initLSNLock(xc);
#else
    xc->myLSN = 0;
#endif

    initDepTree(xc->t);
    initializeMmapAndGLF(xc, is_durable, control_prefix);
    initXactionInfoTable(xc);
    initPageInfoTable(xc);

    initGlobalBuffer(xc->gcbf, control_prefix, 1);
    //    printf("Finished init. of global buffer.\n");
    //    assert((*(xc->xactionGlobal))[0] == 0);
    //    printf("Getting here past assert\n");
    
    detachControlRegion(xc);
  }

  //  printf("Finished initialization of control file!!!\n");
     

  flock(lockFd, LOCK_UN);
  //  fprintf(stderr, "Release file lock\n\n\n");
  close(lockFd);
  return error;  
}




void acquireGlobalLock(xactionContext* xc) {

    
#ifdef DO_LOCK_TIMINGS
    xc->numLocks++;
    checkCycleCount(&xc->lockT1);
#endif
  Cilk_lock(*(xc->xactionGlobal));

#ifdef DO_LOCK_TIMINGS
  checkCycleCount(&xc->lockT2);
  xc->lockTime += clockTimeDiff(xc->lockT1, xc->lockT2);
#endif
}


int verifyGlobalIsLocked(xactionContext* xc) {
  return ((*(xc->xactionGlobal))[0] == 1);
}
void releaseGlobalLock(xactionContext* xc) {
  Cilk_unlock(*(xc->xactionGlobal));
}


#ifdef USE_LSN

static void acquireLSNLock(xactionContext* xc) { 
   Cilk_lock(*(xc->lsnNumLock)); 
} 

static void releaseLSNLock(xactionContext* xc) {
  Cilk_unlock(*(xc->lsnNumLock));
}


void getNextLSN(xactionContext* xc) {
    unsigned long long next = 0;
//    acquireLSNLock(xc);
    next = *(xc->lsnPtr);
    *(xc->lsnPtr) = *(xc->lsnPtr) + 1;
//    releaseLSNLock(xc);

/*     printf("transaction %d on process %d got lsn %llu\n", */
/* 	   xc->currentXId, getpid(), */
/* 	   next); */
    xc->myLSN = next;
}


int tryToUpdateLSNLastCommitted(xactionContext* xc) {
    int done = FALSE;
    unsigned long long globalLSN;
    

    acquireLSNLock(xc);
    globalLSN = *(xc->lsnLastCommitted);

    if (xc->myLSN ==  (globalLSN + 1)) {
	*(xc->lsnLastCommitted) = *(xc->lsnLastCommitted)+ 1;
	done = TRUE;
    }
    releaseLSNLock(xc);


    {
//	int mypid = getpid();
	if (done) {
/* 	    printf("transaction %d on process %d updated last committed lsn to %llu\n", */
/* 		   xc->currentXId, mypid, */
/* 		   xc->myLSN); */
	}
	else {
/* 	    printf("Transaction %d on process %d has LSN %llu, but last committed is %llu\n", */
/* 		   xc->currentXId, mypid, */
/* 		   xc->myLSN, globalLSN); */
	}
    }

    return done;
}

void updateLSNLastCommitted(xactionContext* xc) {
    int failCounter = 0;
    int done = FALSE;

    while (!done) {
	// Try to update the LSN
	done = tryToUpdateLSNLastCommitted(xc);
	if (!done) {
	    failCounter++;
	    if (failCounter > 10) {
		sched_yield();
	    }
	}
    }
}
#endif
