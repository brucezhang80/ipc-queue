/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */



/**
 * xactionNodeList.h
 *
 *  Maintains a list of transaction ids 
 */

#ifndef __XACTION_NODE_LIST
#define __XACTION_NODE_LIST


/***********************************/
/** Bit_nodelist is BROKEN right now.
 *    Don't use. 8/23/04
 ***********************************/
//#define USE_BIT_NODELIST


#include "basics.h"


#ifdef USE_BIT_NODELIST

#ifdef __x86_64
#define INT_SIZE 32
#else
#define INT_SIZE 32
#endif

#define NUM_NL_BIT_VECTORS (MAX_XACTIONS/INT_SIZE + 1)

// A linked list of page numbers.
typedef struct xactionNodeList {
  int length;                // Length
  unsigned int bitArray[NUM_NL_BIT_VECTORS];  // Fixed size array for storing pages
} xactionNodeList;

typedef struct {
  int countIndex;
  unsigned int currentMask;
  int currentLength;
} nodeListIterator;

#else

// A list of ids (for use as children of a node)
typedef struct xactionNodeList {
  int length;
  int nodeArray[MAX_XACTIONS];
} xactionNodeList;

typedef long nodeListIterator;

#endif


/** Clears the node list **/
void clearNodeList(xactionNodeList* list);

/**
 * Adds a page to the list, if it is not already there.
 * Returns -1 if there is an error, 0 otherwise.
 */
int addNodeToList(xactionNodeList* list, unsigned int nodeId);

/** Returns TRUE if the page is in the list. **/
int containsNode(xactionNodeList* list, unsigned int nodeId);

/** Returns TRUE if we removed a copy of nodeId from the list **/
int removeNodeFromList(xactionNodeList* list, unsigned int nodeId);

// Prints out the contents of the list to stderr
void printNodeList(xactionNodeList* list);



// A mechanism for iterating through the children
inline void resetNodeListIterator(xactionNodeList* list, nodeListIterator* it);

// returns value at the current iterator.
inline int getCurrentNode(xactionNodeList* list, nodeListIterator* it);

// gets the current child id and removes from the list.
inline int popCurrentNode(xactionNodeList* list, nodeListIterator* it);

inline void advanceNodeListIterator(xactionNodeList* list, nodeListIterator* it);

inline int endOfNodeList(xactionNodeList* list, nodeListIterator* it);



/** Returns TRUE if the list is empty. **/
int nodeListIsEmpty(xactionNodeList* list);

/** Returns the length of list **/
int getNodeListLength(xactionNodeList* list);

void printNodeListPlain(xactionNodeList* list);

#endif
