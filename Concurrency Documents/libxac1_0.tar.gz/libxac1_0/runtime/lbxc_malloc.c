/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2006    Massachusetts Institute of Technology
 * Copyright (c) 2006    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * lbxc_malloc.c
 *
 *    This file contains a simple buddy-system implementation of malloc. 
 *    
 */

#include <assert.h>
#include "lbxc_malloc.h"


static inline block_tag* GET_BLOCK_TAG(OFFSET_PTR current_offset,
				       unsigned int bucket_index __attribute__((__unused__)), 
				       void* base_addr) {
  
  assert(current_offset >= CONTROL_BLOCK_SIZE);
  return (block_tag*) ((OFFSET_PTR)base_addr +
		       current_offset);
}

static inline void SET_BLOCK_TAG_NEXT(OFFSET_PTR the_offset,
				      unsigned int bucket_index,
				      void* base_addr,
				      OFFSET_PTR new_next) {

  block_tag* ctag = GET_BLOCK_TAG(the_offset, bucket_index, base_addr);
  ctag->next = new_next;
}

static inline void SET_BLOCK_TAG_PREV(OFFSET_PTR the_offset,
				      unsigned int bucket_index,
				      void* base_addr,
				      OFFSET_PTR new_prev) {
  block_tag* ctag = GET_BLOCK_TAG(the_offset, bucket_index, base_addr);
  ctag->prev = new_prev;
}

static inline void SET_BLOCK_TAG_STATE(OFFSET_PTR the_offset,
				       unsigned int bucket_index,
				       void* base_addr,
				       char value) {
  block_tag* ctag = GET_BLOCK_TAG(the_offset, bucket_index, base_addr);

  ctag->tag = value;
  ctag->k = bucket_index;
}


static inline int is_free_tag(block_tag* t) {
  return (t->tag == FREE);
}

static inline void set_free_tag(block_tag* t, char value) {
  t->tag = value;
}



// Initializes an arena of memory of the specified size, 
//  starting at the specified address.
//  Returns 0 if successful, -1 otherwise.

int lbxc_arena_init(size_t arena_size, void* base_addr) {

  unsigned int i;
  arena_header* ah;
  bucket_list* blist;


  if (arena_size <= CONTROL_BLOCK_SIZE) {
    printf("Error! Arena size %zd is too small\n", arena_size);
    return -1;
  }

  
  assert(base_addr != NULL);
  ah = (arena_header*)base_addr;
/*   printf("How big is the arena header actually? %zd\n", sizeof(arena_header)); */
/*   printf("How big is a block tag? %zd\n", sizeof(block_tag)); */


  {
    block_tag temp;
    //    printf("block_tag offset for tag: %zd\n",
    //	   (size_t)(&(temp.tag)) - (size_t)&temp);
    // Make sure the TAG field is at the beginning of the block.
    assert((size_t)&(temp.tag) == (size_t)&temp);
  }

  assert(sizeof(block_tag) <  BUCKET_SIZE(BUCKET_BEGIN));
  assert(sizeof(arena_header) < CONTROL_BLOCK_SIZE);

  

  // This value is the size of the entire arena.
  ah->free_buckets.current_arena_size = arena_size;
  blist = &ah->free_buckets;

  // This value is the size of our initial block.
  blist->largest_block_index = lg_floor(arena_size-CONTROL_BLOCK_SIZE);
  //  printf("Creating arena of size %zd\n", arena_size);
  //  printf("Largest block index is %u\n", blist->largest_block_index);
  
  // Zero all the buckets initially.
  for (i = 0; i < BUCKET_END; i++) {
    blist->free_blocks[i] = NO_BLOCK;    
  }

  // The initial block starts
  blist->free_blocks[blist->largest_block_index] = CONTROL_BLOCK_SIZE;


  SET_BLOCK_TAG_STATE(CONTROL_BLOCK_SIZE,
		      blist->largest_block_index,
		      base_addr,
		      FREE);
  return 0;
}

size_t lbxc_arena_length(void* base_addr) {
  bucket_list* blist;
  
  assert(base_addr != NULL);
  blist = &(((arena_header*)base_addr)->free_buckets);
    
  return CONTROL_BLOCK_SIZE + BUCKET_SIZE(blist->largest_block_index);
}

// Takes in a new (larger) size for the arena.
//  Returns 0 if successfully resized, and non-zero if error
int lbxc_arena_grow(size_t new_size, void* base_addr) {
  arena_header* ah;
  bucket_list* blist;
  size_t current_arena_size;
  unsigned int target_arena_index;
  size_t target_arena_size;
  size_t new_block_size;

  //  size_t

  unsigned int temp_index;

  assert(base_addr != NULL);
  ah = (arena_header*)base_addr;
  blist = &ah->free_buckets;


  current_arena_size = CONTROL_BLOCK_SIZE + BUCKET_SIZE(blist->largest_block_index);

  if (new_size <= current_arena_size) {
    printf("ERROR! new size isn't any bigger than the current arena size.\n");
    return -1;
  }

  target_arena_index = lg_floor(new_size - CONTROL_BLOCK_SIZE);
  target_arena_size = BUCKET_SIZE(target_arena_index);
  if (target_arena_size <= current_arena_size) {
    printf("ERROR! new size isn't large enough to grow the current arena.\n");
    return -1;
  }

  temp_index = blist->largest_block_index;
  new_block_size = BUCKET_SIZE(temp_index);
  assert(new_block_size == (current_arena_size - CONTROL_BLOCK_SIZE));


  while (temp_index < target_arena_index) {

    OFFSET_PTR new_block_offset = CONTROL_BLOCK_SIZE + new_block_size;

    // Add the free block of size BUCKET_SIZE(temp_index)
    SET_BLOCK_TAG_STATE(new_block_offset,
			temp_index,
			base_addr,
			FREE);

    if (temp_index == blist->largest_block_index) {
      if (blist->free_blocks[temp_index] != NO_BLOCK) {
	// There is a block on the current list.  Change that
	//  block's PREV pointer
	SET_BLOCK_TAG_PREV(blist->free_blocks[temp_index],
			   temp_index,
			   base_addr,
			   new_block_offset);	
      }
    }
    else {
      // For bigger blocks, we should be adding the first
      //  block of that size.
      assert(blist->free_blocks[temp_index] == NO_BLOCK);
    }

    // Set the next pointer.
    SET_BLOCK_TAG_NEXT(new_block_offset,
		       temp_index,
		       base_addr,
		       blist->free_blocks[temp_index]);

    SET_BLOCK_TAG_PREV(new_block_offset,
		       temp_index,
		       base_addr,
		       NO_BLOCK);

    blist->free_blocks[temp_index] = new_block_offset;

    //
    //    printf("In arena resize, added block of size 2^ %u =  %zd, at offset %zd\n",
    //	   temp_index,
    //	   new_block_size,
    //	   new_block_offset);
	   

    temp_index++;
    new_block_size *=2;
  }

  // Finally, update the value of the largest block.
  blist->largest_block_index = target_arena_index;
  //  printf("Final block index changed to %u\n", blist->largest_block_index);
  return 0;
}



// Returns an offset into the file.
//  (or 0) if no memory is available.
OFFSET_PTR lbxc_malloc(size_t size, void* base_addr) {

  arena_header* ah;
  bucket_list* blist;
  unsigned int start_bucket;
  unsigned int bucket_index;
  size_t current_size;
  OFFSET_PTR current_offset;
  block_tag* current_tag;


  // Allocate space we asked for plus block_tag.
  start_bucket = lg_ceil(size + sizeof(block_tag));

/*    printf("Malloc for size %zd:  we are asking for index %u, size %zd\n", */
/*   	 size,  */
/*   	 start_bucket, */
/*   	 BUCKET_SIZE(start_bucket)); */



  ah = (arena_header*)base_addr;
  blist = &ah->free_buckets;

  // We don't allocate any blocks smaller than SMALLEST_BLOCK
  if (start_bucket < BUCKET_BEGIN) {
    start_bucket = BUCKET_BEGIN;
  }

  if (start_bucket > blist->largest_block_index) {
    // We are out of memory
    goto out_of_memory;
  }

  bucket_index = start_bucket;

  //  printf("Malloc start looking at bucket %u\n", start_bucket);

  // Find the next largest free block that is big enough
  while ((blist->free_blocks[bucket_index] == NO_BLOCK)
	 && (bucket_index <= blist->largest_block_index)) {
    bucket_index++;
  }


  //  printf("Malloc stopping at  index %u\n", bucket_index);
  if (bucket_index > blist->largest_block_index) {
    goto out_of_memory;
  }



  //  printf("The bucket index for the next largest: %u\n", bucket_index);

  // This block is free.
  current_offset = blist->free_blocks[bucket_index];
  current_tag = GET_BLOCK_TAG(current_offset, bucket_index, base_addr);
  assert(is_free_tag(current_tag));
  

  // Remove that top block from the free list.
  blist->free_blocks[bucket_index] = current_tag->next;
  if (current_tag->next != NO_BLOCK) {
    SET_BLOCK_TAG_PREV(current_tag->next,
		       bucket_index,
		       base_addr,
		       NO_BLOCK);
  }
		     
  current_size = BUCKET_SIZE(bucket_index);
  //  printf("Starting at bucket index %u\n", bucket_index);
  //  printf("Size of bucket %zd\n", current_size);

  while (bucket_index > start_bucket) 
  {   
    // Go down to the next smaller size...
    bucket_index--;
    current_size /= 2;    

    //    printf("Splitting a block to size %zd\n", current_size);
    // Put the right half back on the appropriate free list.


    SET_BLOCK_TAG_STATE(current_offset + current_size,
			bucket_index,
			base_addr,
			FREE);

    SET_BLOCK_TAG_NEXT(current_offset + current_size,
		       bucket_index,
		       base_addr,
		       blist->free_blocks[bucket_index]);

    SET_BLOCK_TAG_PREV(current_offset + current_size,
		       bucket_index,
		       base_addr,
		       NO_BLOCK);

    if (blist->free_blocks[bucket_index] != NO_BLOCK) {
      SET_BLOCK_TAG_PREV(blist->free_blocks[bucket_index],
			 bucket_index,
			 base_addr,
			 current_offset + current_size);
    }

    blist->free_blocks[bucket_index] = current_offset + current_size;
			
    // We are going to loop on the left half.  (note if we wanted to
    // loop on the other half, we would need to change the value of
    // current_offset for the next loop    
  }

  assert(bucket_index == start_bucket);
  //  printf("Stopping at a block size %zd\n", current_size);
  assert(current_size == BUCKET_SIZE(start_bucket));

  // Mark the final block as IN_USE
  SET_BLOCK_TAG_STATE(current_offset,
		      start_bucket,
		      base_addr,
		      IN_USE);

  //  printf("Returning block at offset %zd\n", current_offset);

  return current_offset + sizeof(block_tag);

 out_of_memory:
  //    printf("ERROR! Malloc arena starting at address %p is out of memory\n",
  //	   base_addr);

    // No memory here...
    return 0;  
}


// Returns 0 on success and -1 on error.
int lbxc_free(OFFSET_PTR user_offset, void* base_addr) {

  OFFSET_PTR current_start_offset;
  size_t current_size;
  unsigned int current_k;
  block_tag* current_tag;
  block_tag* buddy_tag;
  arena_header* ah = ((arena_header*)base_addr);
  bucket_list* blist = &(ah->free_buckets);

  
  // The pointer that malloc/free uses is actually before the
  //  user's pointer.
  OFFSET_PTR block_offset = user_offset - sizeof(block_tag);
  //  unsigned int expected_k;
  //  size_t actual_size;
  //  size_t temp_size;

  block_tag* ctag;

  // Compute pointer to block lists

  if (block_offset < CONTROL_BLOCK_SIZE) {
    printf("ERROR! Trying to free a block offset that is too low..\n");
    return -1;
  }

  ctag = (block_tag*)OFFSET_TO_PTR(block_offset, base_addr);

  if (is_free_tag(ctag)) {
    printf("ERROR! Trying to free a block that is already freed or trying to free an invalid tag\n");
    assert(!is_free_tag(ctag));    
  }

  //  printf("We want to free a block at (real) offset %zd, with index %u\n",
  //	 block_offset,
  //	 ctag->k); 
  assert((block_offset-CONTROL_BLOCK_SIZE) % BUCKET_SIZE(ctag->k) == 0);


  // Now keep searching until we find the largest block we can to free and merge:

  current_start_offset = block_offset;
  current_size = BUCKET_SIZE(ctag->k);
  current_k = ctag->k; 
  //  printf("Starting free: start_offset is %zd, current_k is %u\n", current_start_offset, current_k);

  if (current_k == blist->largest_block_index) {
    // If we are freeing the largest block...
    goto put_final_block_on_free_list;
  }
  
  while (1) {
    int new_offset;
    if (((current_start_offset-CONTROL_BLOCK_SIZE) % (2*current_size)) == 0) {
      // Buddy is to the right...   
      buddy_tag = (block_tag*)OFFSET_TO_PTR(current_start_offset + current_size, base_addr);

      // current_start_offset remains the same
      new_offset = current_start_offset;
    }
    else {
      // Buddy is to the left
      //      printf("What is current_start_offset - CONTROL_BLOCK_SIZE? %zd\n",
      //	     current_start_offset - CONTROL_BLOCK_SIZE);
      //      printf("What is current_Size? %zd\n", current_size);
      //      printf("What is the left offset? %zd\n", current_start_offset - current_size);
      buddy_tag = (block_tag*)OFFSET_TO_PTR(current_start_offset - current_size, base_addr);
      new_offset = current_start_offset - current_size;
      //      printf("Going left! \n");
    }

    if (is_free_tag(buddy_tag)) {
      // Delete buddy from free list.

      if (buddy_tag->k != current_k) {	
	//	printf("no match! buddy_tag->k is %u, current_k = %u\n",
	//	       buddy_tag->k, current_k);
	break;
      }      
      assert(buddy_tag->k == current_k);

      if (buddy_tag->prev != NO_BLOCK) {
	SET_BLOCK_TAG_NEXT(buddy_tag->prev,
			   buddy_tag->k,
			   base_addr,
			   buddy_tag->next);
      }
      else {
	// We are removing the first element from the list..
	blist->free_blocks[buddy_tag->k] = buddy_tag->next;
      }

      if (buddy_tag->next != NO_BLOCK) {
	SET_BLOCK_TAG_PREV(buddy_tag->next,
			   buddy_tag->k,
			   base_addr,
			   buddy_tag->prev);
      }

      current_start_offset = new_offset;
      current_k++;
      current_size *= 2;

      //      printf("Merging... new start_offset is %zd, current_k is %u\n", current_start_offset, current_k);
    }
    else {
      break;
    }
  }

 put_final_block_on_free_list:
  // This is the tag of the final block we are freeing.
  current_tag = OFFSET_TO_PTR(current_start_offset, base_addr);
  //  printf("We are putting back a block of size %zd on the list\n", current_size);
  assert(current_size == BUCKET_SIZE(current_k));


  // Set the block state to free
  SET_BLOCK_TAG_STATE(current_start_offset,
		      current_k,
		      base_addr,
		      FREE);

  // Add that block back into the free list..
		      	
  SET_BLOCK_TAG_NEXT(current_start_offset,
		     current_k,		     
		     base_addr,		     
		     blist->free_blocks[current_k]);

  SET_BLOCK_TAG_PREV(current_start_offset,
		     current_k,
		     base_addr,
		     NO_BLOCK);

  if (blist->free_blocks[current_k] != NO_BLOCK) {
    SET_BLOCK_TAG_PREV(blist->free_blocks[current_k],
		       current_k,
		       base_addr,
		       current_start_offset);
  }
  
  blist->free_blocks[current_k] = current_start_offset;
			        
  return 0;
}


// This number is how much space we have to store our own
//  satic control data.
size_t lbxc_arena_control_data_size(void* base_addr __attribute__((__unused__))) {
  return CONTROL_BLOCK_SIZE - (sizeof(arena_header));
}




void* lbxc_arena_control_data_ptr(void* base_addr) {
  assert(lbxc_arena_control_data_size(base_addr) > 0);
  return (void*) ((size_t)base_addr + sizeof(arena_header));    
}
