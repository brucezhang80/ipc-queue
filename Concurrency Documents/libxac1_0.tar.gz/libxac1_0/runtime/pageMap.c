/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * pageMap.c
 *
 */

#include <assert.h>
#include <errno.h>
#include <sched.h>
#include <string.h>
#include <unistd.h>
 

#include "globalControl.h"
#include "file_manager.h"
#include "logData.h"
#include "logTester.h"
#include "lockTest.h"
#include "pageMap.h"
#include "xactionInfo.h"




/**
 * The relevant portions of the xactionContext* xc we use:
 *
 *   xc->theMmap[currentTrans][pageNumber]:
 *     This gives us the page on disk that currentTrans is mapping pageNumber
 *     to (or UNMAPPED_PAGE)
 */


/**************************************************************************************
 * Functions for the public interface.  See comments in pageMap.h for the
 *  specifications.
 **************************************************************************************/

void initializeMmapAndGLF(xactionContext* xc,
			  int isDurable,
			  const char* control_prefix) {
  int pageCount;
  int xCount;

  // Initially, only main memory maps any pages.
  for (pageCount = 0; pageCount < MAX_PAGES; pageCount++) {
    xc->theMmap->pageMap[0][pageCount] = createUserFilePtr(pageCount);
  }

  for (xCount = 1; xCount < MAX_XACTIONS+1; xCount++) {
    for (pageCount = 0; pageCount < MAX_PAGES; pageCount++) {
      xc->theMmap->pageMap[xCount][pageCount] = nullPagePtr();
    }
  }

  //  assert(xc->isDurable == durableXactions());
    //  printf("About to init global log file.\n");
  initGlobalLogFileInfo(xc->glf, isDurable, control_prefix);

}


/**
 * This function is called by each process, so that we can attach ourselves
 *  to file with the specified name.
 */
void attachMmapToFile(xactionContext* xc,
		      xaction_local_context* xlc,
		      const char* userFileName, int numPages) {

  global_file_info newFileInfo;

  server_open_user_file(xc->glf,
			userFileName,
			numPages,
			&newFileInfo);
  local_open_user_file(xlc->mfd,
		       &newFileInfo);

  openLogFiles(xc->glf, xlc->mfd);
  xlc->lcbf = createLocalCommitBuffer(xc->gcbf);
}

// The corresponding detach function.
void detachMmapFromFile(xactionContext* xc,
			xaction_local_context* xlc,
			const char* userFileName) {
  global_file_info newFileInfo;
  server_close_user_file(xc->glf,
			 userFileName,
			 &newFileInfo);

  local_close_user_file(xlc->mfd,
			&newFileInfo);

  closeLogFiles(xc->glf, xlc->mfd);

  destroyLocalCommitBuffer(xlc->lcbf);
}



/**
 * This function is called before doing final cleanup to the control region.
 */
void finalCleanupAttachForLogFiles(xactionContext* xc,
				   xaction_local_context* xlc,
				   const char* userFileName) {

  global_file_info newFileInfo;
  server_open_user_file(xc->glf,
			userFileName,
			xc->glf->userFileInfo[USER_FILE_ID].length,
			&newFileInfo);

  local_open_user_file(xlc->mfd,
		       &newFileInfo);


  openLogFiles(xc->glf, xlc->mfd);
}


/**
 * This function is called before doing final cleanup to the control region.
 */
void finalCleanupDetachForLogFiles(xactionContext* xc,
				   xaction_local_context* xlc,
				   const char* userFileName) {
  global_file_info newFileInfo;

  if (xc->logTestModeOn) {
    printf("Testing the log file %s\n",
	   xc->glf->currentCommitFileInfo.name);
    assert(checkForValidLogFile(xc->glf->currentCommitFileInfo.name));
  }
  server_close_user_file(xc->glf, userFileName, &newFileInfo);
  local_close_user_file(xlc->mfd, &newFileInfo);

  closeLogFiles(xc->glf, xlc->mfd);
}





void readFrom(xactionContext* xc,
	      xaction_local_context* xlc, 
	      int sourceTrans,
	      int pageNumber,
	      int releaseLock) {
  dpPtr sourceDiskPage, nullPage;
  int currentTrans = xlc->currentXId;

  nullPage= nullPagePtr();

  // Look up disk page for source transaction.
  sourceDiskPage = xc->theMmap->pageMap[sourceTrans][pageNumber];

  assert(sourceDiskPage.fileId != nullPage.fileId);
  assert(sourceDiskPage.dp != nullPage.dp);

  // Release the global lock

   // Update reference count
  acquireLogManagerLock(xc->glf);

  REF_CT_PRINT(stderr, "About to inc ref count for page (%d, %d) in readFrom\n",
	       sourceDiskPage.fileId, sourceDiskPage.dp);

  incRefCount(xc->glf, sourceDiskPage);
  releaseLogManagerLock(xc->glf);

  xc->theMmap->pageMap[currentTrans][pageNumber] = sourceDiskPage;

  //  printf("I just read from file %d, page %d\n", sourceDiskPage.fileId, sourceDiskPage.dp);
  
  if (releaseLock) {
    releaseGlobalLock(xc);
  }


  // Call mmap
  mmapDiskPage(xlc->mfd, pageNumber, sourceDiskPage, PROT_READ); 
}



void createPageRangeCopy(xactionContext* xc,
			 xaction_local_context* xlc, 
			 void* memoryRange,
			 int pageStart,
			 int numPages,
			 int releaseLock) {
  int i;
  int currentTrans = xlc->currentXId;
  dpPtr newDiskPage;
  dpPtr tempDiskPage;
  dpPtr sourceDiskPage;


  assert(verifyGlobalIsLocked(xc));


  // Write out the new pages to the log file.

  // Actually do the copying...
  newDiskPage = writeNewPagesToLogFile(xc->glf, xlc->mfd, memoryRange,
				       numPages,
				       xc->theMmap->pageMap[currentTrans][pageStart]);

  //  printf("I just made a new page in %d, page %d\n", newDiskPage.fileId, newDiskPage.dp);
  //  writeNewPagesToLogFile(xc, memoryRange, endOfFile, numPages);

  tempDiskPage = newDiskPage;

  // Unmap the old pages
  //  if (releaseLock) {
  //    releaseGlobalLock(xc);
    //    Cilk_unlock(*(xc->xactionGlobal));
  //  }
/*   for (i = 0; i < numPages; i++) { */
/*     munmapDiskPage(xlc->mfd, pageStart+i); */
/*   } */
//  if (releaseLock) {
//    acquireGlobalLock(xc);
    //    Cilk_lock(*(xc->xactionGlobal));
  //  }
    
  // Fix all the reference counts
  acquireLogManagerLock(xc->glf);
  //  Cilk_lock(*(xc->glf->logManagerLock));
  for (i = 0; i < numPages; i++) {
    tempDiskPage.dp = newDiskPage.dp + i;

    sourceDiskPage = xc->theMmap->pageMap[currentTrans][pageStart+i];

    
    REF_CT_PRINT(stderr, "About to decRefCount for page (%d, %d) in createPageRangeCopy\n",
	   sourceDiskPage.fileId, sourceDiskPage.dp);
    addPageToReadSourceTable(xlc->mfd, pageStart+i, sourceDiskPage);
    // Don't actually decrement the reference count here...
    //  do it when we are sure we won't need to access that page any more, i.e.,
    //  when we clear the source page instead.
    //    decRefCount(xc->glf, xlc->mfd, sourceDiskPage);
    //    decRefCount(xc->glf, xlc->mfd,  xc->theMmap->pageMap[currentTrans][pageStart+i]);

    
    xc->theMmap->pageMap[currentTrans][pageStart+i] = tempDiskPage;
    // Increment count on the page.

    REF_CT_PRINT(stderr, "About to incRefCount for page (%d, %d) in createPageRangeCopy\n",
	   tempDiskPage.fileId, tempDiskPage.dp);
    incRefCount(xc->glf,  tempDiskPage);
  }

  releaseLogManagerLock(xc->glf);
  //  Cilk_unlock(*(xc->glf->logManagerLock));

  if (releaseLock) {
    releaseGlobalLock(xc);
    //    Cilk_unlock(*(xc->xactionGlobal));
  }

  // Mmap the new pages from the end of the log file.
  for (i = 0; i < numPages; i++) {
    tempDiskPage.dp = newDiskPage.dp + i;
    mmapDiskPage(xlc->mfd,
		 pageStart+i,
		 xc->theMmap->pageMap[currentTrans][pageStart+i],
		 //		 tempDiskPage, 
		 PROT_READ | PROT_WRITE);
  }
}

void replaceOriginalPageRange(xactionContext* xc,
			      xaction_local_context* xlc,
			      int someTrans, int pageStart, int numPages) {

  int i;
  dpPtr tempPage = nullPagePtr();
  dpPtr nullPage = nullPagePtr();
  dpPtr diskSourceStart = xc->theMmap->pageMap[someTrans][pageStart];
  
  // Copy those pages from the log file to the original.
  copyRangeToUserFile(xc->glf, xlc->mfd, pageStart, diskSourceStart, numPages);

  acquireLogManagerLock(xc->glf);
  //  Cilk_lock(*(xc->glf->logManagerLock));
  // Clear the mmap data structure for the current transaction for those pages
  for (i = 0; i < numPages; i++) {
    tempPage = xc->theMmap->pageMap[someTrans][pageStart+i];
    assert(tempPage.fileId != NULL_FILE_ID);

    REF_CT_PRINT(stderr, "ABout to dec ref count on page (%d, %d) in replaceOrigPageRange\n",
	   tempPage.fileId, tempPage.dp);
    decRefCount(xc->glf, tempPage);

    xc->theMmap->pageMap[someTrans][pageStart+i] = nullPage;
  //    xc->theMmap->pageMap[someTrans][pageStart+i] = UNMAPPED_PAGE;
  }
  //  incCopyCount(xc->glf, tempPage.fileId, numPages);
  releaseLogManagerLock(xc->glf);
  //  Cilk_unlock(*(xc->glf->logManagerLock));

}

#include "xDep.h"

void transferTo(xactionContext* xc,
		int currentTrans, int sourceTrans, int pageNumber,
		int parentOwnedXaction) {

  dpPtr sourcePage = xc->theMmap->pageMap[sourceTrans][pageNumber];
  dpPtr originalPage = xc->theMmap->pageMap[currentTrans][pageNumber];
  
  if (parentOwnedXaction) {
    if (originalPage.fileId == NULL_FILE_ID) {
      printf("ERROR!!!.  CurrentTrans %d trying to transfer page %d from source %d \n",
	     currentTrans, pageNumber, sourceTrans);
      outputDepTree(xc->t);
      sleep(1000);
    }
    assert(originalPage.fileId != NULL_FILE_ID);
    //    printf("What is the original page's file ID? %d. The disk page is %d\n", originalPage.fileId, originalPage.dp);

    acquireLogManagerLock(xc->glf);
    
    //    incCopyCount(xc->glf, originalPage.fileId, 1);
    REF_CT_PRINT(stderr, "ABout to dec ref count in TransferTo on (%d, %d)\n",
	   originalPage.fileId, originalPage.dp); 
    decRefCount(xc->glf,  originalPage); 
		
    releaseLogManagerLock(xc->glf);
  }
  else {
    if (originalPage.fileId != NULL_FILE_ID) {
      printf("currentTrans == %d, sourceTrans == %d, pageNumber == %d\n",
	     currentTrans, sourceTrans, pageNumber);
      //      printTransactionInfo(xc, currentTrans);
      //      printTransactionInfo(xc, sourceTrans);

      printf("The original page file id is %d, disk page number is %d\n",
	     originalPage.fileId,
	     originalPage.dp);
    }
    assert(originalPage.fileId == NULL_FILE_ID);
  }
  xc->theMmap->pageMap[currentTrans][pageNumber] = sourcePage;
  xc->theMmap->pageMap[sourceTrans][pageNumber] = nullPagePtr();
}



// Removes a page from the read source table.
//  Should be called when we are committing, and on 
//  a page that we are writing to.
void clearSourcePage(xactionContext* xc,
		     xaction_local_context* xlc,
		     int pageNumber) {
  dpPtr readPage;
  readPage = getPageFromReadSourceTable(xlc->mfd, pageNumber);
  if (isNullPagePtr(readPage)) {
    printf("Error! the page we are looking for is %d\n",
	   pageNumber);
    printHashTable(xlc->mfd->readSourceTable);
  }
  assert(!isNullPagePtr(readPage));
  readPage = removePageFromReadSourceTable(xlc->mfd, pageNumber);
  decRefCount(xc->glf, readPage);
}


/**
 * These functions changes the system memory map so
 *   the protection on the current transaction's page
 *   is PROT_NONE.
 *
 * Precondition:
 *  -  mmap(currentTrans, pageNumber) == d (some disk page)
 *
 * Postcondition:
 *  -  system has changed process mmap for disk page d to PROT_NONE
 *  -  If isCommit is FALSE, then refCount(d)--, and
 *       mmap(currentTrans, pageNumber) = UNMAPPED_PAGE
 *
 * queuePageUnmap stores a page to be unmapped into the queue
 * processUnmapQueue actually goes through and calls unmap on all the
 *  pages in the queue.
 */
void queuePageUnmap(xactionContext* xc,
		    xaction_local_context* xlc, 
		    int pageNumber, int isCommit, int isWrite) {

  int currentTrans = xlc->currentXId;
  dpPtr diskPage = xc->theMmap->pageMap[currentTrans][pageNumber];
  int n = xlc->pagesToUnmap.length;
  assert(n < MAX_PAGES);
  
  xlc->pagesToUnmap.page[n] = pageNumber;
  xlc->pagesToUnmap.dpage[n] = diskPage;
  xlc->pagesToUnmap.pageIsWrite[n] = isWrite;
  xlc->pagesToUnmap.length++;


  if (isWrite) {

    
    if (!isCommit) {
      // Mark this page as being "copied back" already.
      acquireLogManagerLock(xc->glf);

      // Ok to dec. the ref count for an aborted page now, because
     //   no one else will ever access this page.

      clearSourcePage(xc, xlc, pageNumber);
      //      testPage = getPageFromReadSourceTable(xlc->mfd, pageNumber);
      //      assert(!isNullPagePtr(testPage));
      //      testPage = removePageFromReadSourceTable(xlc->mfd, pageNumber);
      //    decRefCount(xc->glf, xlc->mfd,  testPage);
      
      REF_CT_PRINT(stderr, "About to decRefCoutn for page (%d, %d) in unmapXactionPage\n",
		   diskPage.fileId,
		   diskPage.dp);
      decRefCount(xc->glf, diskPage);
      

      releaseLogManagerLock(xc->glf);

      
      // Change the mapping to a null page only if it was an abort.
      xc->theMmap->pageMap[currentTrans][pageNumber] = nullPagePtr();
    }
  }
  else {
    // it is not a write.
    // Change the mapping to a null page.
    xc->theMmap->pageMap[currentTrans][pageNumber] = nullPagePtr();
  }
}




void processUnmapQueue(xactionContext* xc,
		       xaction_local_context* xlc,
		       int isDurable) {
  int i = 0;

  assert(numPagesInReadSourceTable(xlc->mfd) == 0);
  for (i = 0; i < xlc->pagesToUnmap.length; i++) {

    //    printf("About to actually unmap queued (%d, %d) at id %d, on %d\n",
    //	   xc->pagesToUnmap.page[i],
    //	   xc->pagesToUnmap.dpage[i],
    //	   i,
    //	   xlc->currentXId);

    // DONT do munmap below, because you want to ensure that
    //  we dont' accidentally mmap this address and use it elsewhere
    //    munmapDiskPage(xlc->mfd, xc->pagesToUnmap.page[i]);

    if ((xlc->pagesToUnmap.pageIsWrite[i]) && (isDurable)) {
	mmapDiskPage(xlc->mfd,
		     xlc->pagesToUnmap.page[i],
		     xlc->pagesToUnmap.dpage[i],
		     PROT_NONE);
    }
    else {
      mmapDiskPage(xlc->mfd,
		   xlc->pagesToUnmap.page[i],
		   xlc->pagesToUnmap.dpage[i],
		   PROT_NONE);
    }
  }


  acquireLogManagerLock(xc->glf);
  for (i = 0; i < xlc->pagesToUnmap.length; i++) {

    
    if (!xlc->pagesToUnmap.pageIsWrite[i]) {
      REF_CT_PRINT(stderr, "About to decRefCoutn for page (%d, %d) in unmapXactionPage\n",
	     xlc->pagesToUnmap.dpage[i].fileId,
	     xlc->pagesToUnmap.dpage[i].dp);
      // only decrement the reference count for pages that you
      //  are reading from.  If you wrote to it,
      //  the person who copies it back should dec. the ref. count.
      decRefCount(xc->glf, xlc->pagesToUnmap.dpage[i]);
    }
  }
  releaseLogManagerLock(xc->glf);
  
  // reset the unmap queue.
  xlc->pagesToUnmap.length = 0;
}



// Transfer the data from the global commit buffer to the commit
// record.  Does NOT sync the data, however.
static void writeGlobalBufferToCommitFile(xactionContext* xc,
					  xaction_local_context* xlc) {


  writeDataToCommitFile(xc->glf,
			xlc->currentXId,
			xlc->lcbf,
			xlc->mfd,
			xlc->lcbf->commitBufferRegion,
			xc->gcbf->length);
  clearGlobalBuffer(xlc->lcbf, xc->gcbf);
  changeStatusOnWaitersToStarted(xc->gcbf, xlc->lcbf);
}

// The method that actually does the writing of the 
//  log data to disk.
// It takes the data from the process's local commit buffer.
//    This method won't return until this process's
//    data has been synched to disk. 
int flushCommitDataToDisk(xactionContext* xc,
			  xaction_local_context* xlc) {

    int myFsyncStartToken = FSYNC_START_TOKEN;
    int myFsyncEndToken = FSYNC_END_TOKEN;
    

#ifdef GATHER_STATS
    xlc->xs.numXactionsSynched = 0;
    xlc->xs.fsyncStartTime = 0;
    xlc->xs.fsyncEndTime = 0;
#endif

  if (xlc->lcbf->currentLength > 0) { 
    if (tryToAcquirePrimaryBufferLock(xc->gcbf)) {

      // If we managed to get the primary buffer lock...
      //    acquirePrimaryBufferLock(xc->gcbf);

      // Write my local stuff directly to the commit file.
      writeDataToCommitFile(xc->glf,
			    xlc->currentXId,
			    xlc->lcbf,
			    xlc->mfd,
			    getLocalBufferPointer(xlc->lcbf),
			    getLocalBufferLength(xlc->lcbf));
      clearLocalBuffer(xlc->lcbf);

     



      // Write anything else people have written to the file. 
      acquireSecondaryBufferLock(xc->gcbf);
      writeGlobalBufferToCommitFile(xc, xlc);
      releaseSecondaryBufferLock(xc->gcbf);


      if (xc->logTestModeOn) {
	  writeDataToCommitFile(xc->glf,
				xlc->currentXId,
				xlc->lcbf, 
				xlc->mfd,
				&myFsyncStartToken,
				sizeof(int));

      }


      addEventToLocalBuffer(xlc->lcbf,
			    xlc->currentXId,
			    LOC_BEFORE_SYNC);

      // Synchronize it
      syncCurrentCommitRecord(xc->glf, xlc->mfd);

      if (xc->logTestModeOn) {
	  writeDataToCommitFile(xc->glf,
				xlc->currentXId,
				xlc->lcbf, 
				xlc->mfd,
				&myFsyncEndToken,
				sizeof(int));
      }


      addEventToLocalBuffer(xlc->lcbf,
			    xlc->currentXId,
			    LOC_AFTER_SYNC);




      // Clear anyone who is set as running.  They are synched now. 
      acquireSecondaryBufferLock(xc->gcbf);

#ifdef GATHER_STATS
      // In this case, you never mark yourself as running...
      xlc->xs.numXactionsSynched = 1 + clearAllRunningIds(xc->gcbf, xlc->lcbf);   
#else
      clearAllRunningIds(xc->gcbf, xlc->lcbf);
#endif

      releaseSecondaryBufferLock(xc->gcbf);

      releasePrimaryBufferLock(xc->gcbf);
    }
    else {
      // We didn't get it.  Try the secondary lock.

      int done = FALSE;
      int retryCount = 0;

      //      printf("Process %d didn't get primary lock.  Try for secondary.\n",
      //	     myPid);


      // Write my local data to the global commit file.
      acquireSecondaryBufferLock(xc->gcbf);
      //      printf("Process %d got secondary lock. Writing data to global file \n",
      //	     myPid);
      emptyLocalIntoGlobalBuffer(xlc->lcbf,
				 xc->gcbf);

      addIdToWaitersList(xc->gcbf, xlc->currentXId);
      releaseSecondaryBufferLock(xc->gcbf);


      while (!done) {
//	int waitTest, runTest;
	acquireSecondaryBufferLock(xc->gcbf);
	//	printf("Now %d will check to see if it is done. \n", myPid);
//	waitTest = stillWaiting(xc->gcbf, xlc->currentXId);
//	runTest = stillRunning(xc->gcbf, xlc->currentXId);
	done = !stillWaitingOrRunning(xc->gcbf, xlc->currentXId);
	
/* 	printf("For process %d, id %d, Waiting = %d, Running = %d, Done? %d\n", */
/* 	       myPid, */
/* 	       xlc->currentXId, */
/* 	       waitTest, */
/* 	       runTest, */
/* 	       done); */
	releaseSecondaryBufferLock(xc->gcbf);

	if (!done) {
	  // Try to get the primary lock again.

	  if (tryToAcquirePrimaryBufferLock(xc->gcbf)) {

	    // If we managed to get the primary buffer lock...
	    //	    printf("Process %d maanged to get primary lock a second time\n", myPid);

	    acquireSecondaryBufferLock(xc->gcbf);
	    done = !stillWaitingOrRunning(xc->gcbf, xlc->currentXId);
	    if (!done) {
		//	    printf("Now %d I can write all this stuff to file. including myself.\n", myPid);
		writeGlobalBufferToCommitFile(xc, xlc);	 
	    }
	    releaseSecondaryBufferLock(xc->gcbf);

	    //	    printf("Process %d syncing to file \n", myPid);

	    if (!done) {
		if (xc->logTestModeOn) {
		    writeDataToCommitFile(xc->glf,
					  xlc->currentXId,
					  xlc->lcbf,
					  xlc->mfd,
					  &myFsyncStartToken,
					  sizeof(int));
		}

		addEventToLocalBuffer(xlc->lcbf,
				      xlc->currentXId,
				      LOC_BEFORE_SYNC);

		// Synchronize it
		syncCurrentCommitRecord(xc->glf, xlc->mfd);

		if (xc->logTestModeOn) {
		    writeDataToCommitFile(xc->glf,
					  xlc->currentXId,
					  xlc->lcbf,
					  xlc->mfd,
					  &myFsyncEndToken,
					  sizeof(int));
		}

		addEventToLocalBuffer(xlc->lcbf,
				      xlc->currentXId,
				      LOC_AFTER_SYNC);




		// Clear anyone who is waiting for themselves to finish.
		acquireSecondaryBufferLock(xc->gcbf);
		//	    printf("Process %d is clearing all the waiters...\n", myPid);
		//	    printf("Before: waiters were \n");
		//	    printAllWaiters(xc->gcbf);

#ifdef GATHER_STATS
		xlc->xs.numXactionsSynched = clearAllRunningIds(xc->gcbf, xlc->lcbf);
#else
		clearAllRunningIds(xc->gcbf, xlc->lcbf);	    
#endif

		releaseSecondaryBufferLock(xc->gcbf);
	    }
	    releasePrimaryBufferLock(xc->gcbf);
	 
	    done = TRUE;
	  }
	}


	// If we get here and not done, do backoff.
	//	printf("Process %d doign backoff. \n", myPid);



//	usleep(1000);
	// Instead of backing off, just yield.
	sched_yield();	
	retryCount++;
      }

      if (retryCount > 150) {
//      int myPid = getpid();
//	printf("Process %d backed off %d times... \n", myPid, retryCount);
      }
    }      
  }

  return 0;
}



void storePageDiff(xaction_local_context* xlc,
		   localCommitBuffer* lcbf, int page) {
  dpPtr sourcePage = getPageFromReadSourceTable(xlc->mfd, page);

  char tagBuffer[25];
  char tempBuffer[3*PAGESIZE];
  char appendBuffer[10];
  size_t tempBuffer_nbytes;

  int i;
  for (i = 0; i < 25; i++) {
    tagBuffer[i] = (char)'a'+i;
  }
  for (i = 0; i < 10; i++) {
    appendBuffer[i] = (char)'a'+i;
  }

  for (i = 0; i < 100; i++) {
    tempBuffer[i] = (char)0;
  }


  assert(xlc->lcbf == lcbf);
  assert(lcbf != NULL);

  //  printf("Calling storePageDiff on page %d\n", page);
  computePageDiff(xlc->currentXId,
		  xlc->lcbf,
		  xlc->mfd,
		  sourcePage,
		  page,
		  (void*) tempBuffer,
		  PAGESIZE*3,
		  &tempBuffer_nbytes);

  snprintf(tagBuffer, 25, "Page %d:", page);
  snprintf(appendBuffer, 10, "\n");
  addDataToLocalBuffer(lcbf, tagBuffer, strlen(tagBuffer));
  addDataToLocalBuffer(lcbf, tempBuffer, tempBuffer_nbytes);
  addDataToLocalBuffer(lcbf, appendBuffer, strlen(appendBuffer));
}



int storeTagToBuffer(xactionContext* xc,
		     localCommitBuffer* lcbf,
		     logPageType lpType,
		     int timeStamp,
		     unsigned long long myLSN) {

    unsigned long long answerBuffer[4];

    answerBuffer[0] = lpType;
    answerBuffer[1] = myLSN;
    answerBuffer[2] = timeStamp;
    answerBuffer[3] = lpType + myLSN + timeStamp;

    if (!xc->logTestModeOn) {
	addDataToLocalBuffer(lcbf, answerBuffer, 4*sizeof(unsigned long long));
    }
    
    return 0;
}
	    
