/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xStats.h
 *
 *  structures for keeping track of runtime statistics.
 */


#ifndef __XSTATS_H
#define __XSTATS_H


#include "basics.h"
#include "cycle_counter.h"

typedef struct xactionStats {

    int myId;
    int pagesRead;
    int pagesWritten;
    size_t bytesLogged;

    rtimeStruct writeStartTime;
    rtimeStruct writeEndTime;
    rtimeStruct fsyncStartTime;
    rtimeStruct fsyncEndTime;

    rtimeStruct compressStartTime;
    rtimeStruct compressEndTime;

    rtimeStruct totalCompressTime;


    rtimeStruct totalSyncStartTime;
    rtimeStruct totalSyncEndTime;

    int numXactionsSynched;

    int commitStatus;
    int compression;

} xactionStats;


void clearXactionStats(xactionStats* xstat);



void printXStatsKey(FILE* f);
void printXStats(FILE* f, int mypid, xactionStats* xs);

#endif
