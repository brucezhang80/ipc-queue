/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * basics.h
 *
 *    This file contains global constants for the Libxac runtime system
 *     and other flags controlling the runtime behavior.
 */

#ifndef __XACTION_BASICS_H
#define __XACTION_BASICS_H

// This is needed so we can call mremap
#define _GNU_SOURCE

#define FALSE 0
#define TRUE 1
#define SUCCESS 0
#define FAILURE -1

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

// The maximum number of transactions that we can
//  have in the system at any one time.
// Note that this includes committed transactions
//  that have not been merged into their parent yet.
#define MAX_XACTIONS 32

// The maximum size (in pages) of the transactional
//  memory region that we can map.

#define MAX_PAGES 100000


// The maximum size of our log file.
#define MAX_FILE_PAGES MAX_PAGES*5

enum { PAGESIZE = 4096};

// Integer size for a pointer for a 32 or 64 bit machine.
#define PTR_INT size_t

//#ifdef __x86_64
//#   define PTR_INT long 
//#else
//#   define PTR_INT int
//#endif




#define NULL_TRANS_ID -1
#define NULL_INDEX -1
#define NULL_PAGE -1

// If this flag is set to TRUE, then when committing
//  a transaction, we generate a sample log entry 
//  as in logTester.h

#define DEFAULT_LOG_TEST_ON FALSE

//#define DO_TIMINGS
//#define DO_LOCK_TIMINGS
//#define DO_MMAP_TIMINGS
//#define COUNT_STATS


typedef enum {EMPTY_EVENT,
	      XBEGIN_START,
	      XBEGIN_FINISH,
	      XEND_START,
	      XCOMMIT_FIN,
	      XABORT_FIN,
	      LOC_BEFORE_MMAP_READ,
	      LOC_AFTER_MMAP_READ, 
	      LOC_BEFORE_MMAP_WRITE,
	      LOC_AFTER_MMAP_WRITE,
	      LOC_BEFORE_MMAP_NONE,
	      LOC_AFTER_MMAP_NONE,
	      LOC_BEFORE_MMAP_IN_DIFF,
	      LOC_AFTER_MMAP_IN_DIFF,
	      LOC_BEFORE_WRITE,
	      LOC_AFTER_WRITE,
	      LOC_BEFORE_SYNC,
	      LOC_AFTER_SYNC,
	      SYNC_SCHED_BEGIN,
	      SYNC_DONE, 
	      LAST_NULL_EVENT } eventType;

#define GATHER_STATS
//#define USE_COMPRESSED_LOGS


//#define USE_LSN
//#define  DO_EARLY_RELEASE_ON_WRITES

#define DEFAULT_ANONYMOUS_FILE_NAME "xactionFile.xdt"
#define LIBXAC_DEFAULT_PATH "LibxacTemp"

typedef int TID;   // Transaction ID


#ifdef XACTION_PRINT
#define DBPRINT fprintf
#define TREEPRINT outputDepTree
#else
#define DBPRINT emptyPrint
#define TREEPRINT emptyTreePrint
#endif




#endif
