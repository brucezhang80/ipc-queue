/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * cycle_counter.c
 *  
 *  Functions to call rdtsc.  So far, only x86 platforms supported.
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <sys/time.h>
#include "cycle_counter.h"


int notSetup = 1;

#ifdef PERF_COUNTER_TIMERS

struct vperfctr *vpc;
struct perfctr_info info;
struct vperfctr_control control;

void setupTimers(void) {
  if (notSetup) {
    if (!(vpc = vperfctr_open())) {
      perror("vperfctr_open");
      exit(1);
    }
    if (vperfctr_info(vpc, &info)<0) {
      perror("vperfctr_info");
      exit(1);
    }

    // setup
    memset(&control.cpu_control, 0, sizeof control.cpu_control);
    control.cpu_control.tsc_on = 1;
    vperfctr_control(vpc, &control);
    notSetup = 0;

    printf("The CPU speed is %d", info.cpu_khz);
 }
}


inline void checkTimer(timeStruct* tv) {
  *tv = vperfctr_read_tsc(vpc);
}


double timeDiff(long long before, long long after) {
  return ((after - before)/1000.0)/info.cpu_khz;
}



double rtimeDiff(rtimeStruct before, rtimeStruct after) {
  return ((after - before)/1000.0L)/info.cpu_khz;
}

#else

void setupTimers(void) {
}


inline void checkTimer(timeStruct* tv) {
  gettimeofday(tv, 0);
/*   unsigned long long rt0; */
/*   __asm__ __volatile__("rdtsc" : "=A" (rt0)); */
/*   *tv = rt0; */
}



/**
 * Takes in two timeval structs and returns
 *  the time difference between them, in micro-seconds.
 */
double timeDiff(timeStruct tv0, timeStruct tv1){
  return (tv1.tv_sec-tv0.tv_sec)+(tv1.tv_usec-tv0.tv_usec)*1e-6;
  //  return ((tv1 - tv0)/1000.0)/2400000;
}


// This is hardcoded in though...
double rtimeDiff(rtimeStruct before, rtimeStruct after) {
//  return ((after - before)/1000.0)/PRUNELLA;
    return ((after - before)/1000.0)/ALF;
}

#endif



inline void checkRealTimer(rtimeStruct* tv) {
  unsigned long long rt0;
  __asm__ __volatile__("rdtsc" : "=A" (rt0));
  *tv = rt0;
}


/**
 * Outputs the time taken and average time taken for a task to stdout.
 *   desc: the string description of the task
 *   time: how long the task took (in us)
 *   num:  how many times the task was repeated
 */
void reportTime(const char* desc, double runningTime, int num) {
  printf("%s: Done %d times, total time %0.6f s (avg. %0.4f us/ op)\n",
	 desc,
	 num,
	 runningTime,
	 1e6*runningTime/num);
}




inline void checkCycleCount(rtimeStruct* tv) {
//  unsigned long long rt0;
//  __asm__ __volatile__("rdtsc" : "=A" (rt0));
//  *tv = rt0;

    unsigned int low,high;
    __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));
//      return (((long)low)<<32)+high;
    *tv = (((unsigned long long)high)<<32)+low;
}

unsigned long long clockTimeDiff(rtimeStruct tv0, rtimeStruct tv1) {
    return (tv1 - tv0);
}

void reportCycles(const char* desc, long long cycleCount, int num) {
  printf("%s: Done %d times, total time %0.4f cycles (avg. %0.4f cycles/ op)\n",
	 desc,
	 num,
	 cycleCount*1.0,
	 1.0*cycleCount/num);
}
