/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * file_manager.c
 *
 */


#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <zlib.h>

#include "basics.h"
#include "cycle_counter.h"
#include "globalTypes.h"
#include "libxac_client_types.h"
#include "logData.h"
#include "file_manager.h"


#define USER_FILE_INDEX 0


void emptyLogPrint(FILE* file __attribute__((__unused__)), ...);
void emptyLogPrint(FILE* file __attribute__((__unused__)), ...) {

}

char emptyArray[PAGESIZE];


#ifdef DISPLAY_LOG_MESSAGES
#define PLOG_PRINT fprintf
#else
#define PLOG_PRINT emptyLogPrint
#endif


extern xaction_local_context xlc;


// Helper method declarations

static int extendFileToSpecifiedLength(int fd, int numPages);
static void createNewCommitFile(globalLogFileInfo* glf, const char* path);
static void createNewPageLogFile(globalLogFileInfo* glf, const char* path);
static void closePageLogFileForProcess(mappedFileData* mfd);


static inline void generatePageLogFileName(char* nameBuffer, const char* path, int fileId) {
  if (path == NULL) {
    snprintf(nameBuffer, (size_t)FILE_NAME_LENGTH, "%s%dP.plg", "LbxcPageLog", fileId);	   
  }
  else {
    snprintf(nameBuffer, (size_t)FILE_NAME_LENGTH, "%s/%s%dP.plg", path, "LbxcPageLog", fileId);	   
  }
}

static inline void generateCommitFileName(char* nameBuffer, const char* path, int fileId) {
  if (path == NULL) {
    snprintf(nameBuffer, (size_t)FILE_NAME_LENGTH, "%s%05d.log", "LbxcCommitFile", fileId);
  }
  else {
    snprintf(nameBuffer, (size_t)FILE_NAME_LENGTH, "%s/%s%05d.log", path, "LbxcCommitFile", fileId);
  }
}




// Functions for grabbing and releasing the lock on
//   the global log file info structure.

void acquireLogManagerLock(globalLogFileInfo* glf) {
#ifdef DO_TIMINGS
  //  checkTimer(&st1);
#endif
  Cilk_lock(*(glf->logManagerLock));

#ifdef DO_TIMINGS
  //  checkTimer(&st2);
  //  glf->numLocks++;
  //  glf->lockTime += timeDiff(st1, st2);
#endif
}

void releaseLogManagerLock(globalLogFileInfo* glf) {
  Cilk_unlock(*(glf->logManagerLock));
}



void initGlobalLogFileInfo(globalLogFileInfo* glf,
			   int isDurable,
			   const char* control_prefix) {
  int i;

  for (i = 0; i < PAGESIZE; i++) {
    emptyArray[i] = (char)0;
  }
  // Set up the ref. count and free list structures.
  for (i = 0; i < MAX_PAGELOG_SIZE; i++) {
    glf->refCount[i] = 0;
    glf->freeList[i] = i;  // The free list starts with all the
			   // indices in the array
  }
  glf->freeListTop = 0;    // But the list starts as being empty.
  glf->freeListEnd = 0;


  glf->durableXactions = isDurable;


  if (control_prefix == NULL) {
    glf->control_path[0] = '\0';  // Set path to the empty string...
    //    snprintf(glf->control_path, FILE_NAME_LENGTH, "");
  }
  else {
    snprintf(glf->control_path, FILE_NAME_LENGTH, "%s", control_prefix);
  }

  // Create the first commit file.
  // It won't actually open/create the file until the first process
  //   decides to access it.
  glf->currentCommitFileInfo.fileId = NULL_FILE_ID;
  createNewCommitFile(glf, glf->control_path);


  // Create first page log file.
  glf->pageLogFileInfo.fileId = NULL_FILE_ID;
  glf->pageLogFileInfo.length = 0;
  glf->pageLogFileInfo.status = INACTIVE;
  createNewPageLogFile(glf, glf->control_path);

//  printf("Finished inittingin createPageLog.\n");
  
  for (i = 0; i < MAX_NUM_USER_FILES; i++) {
    glf->userFileInUse[i] = FALSE;
    glf->userFileInfo[i].status = INACTIVE;
  }

//  printf("Finished initing glf.\n");
  
  PLOG_PRINT(stderr, "Created log...\n");
//  printf("Trying to init the lock....\n");  
  Cilk_lock_init(*(glf->logManagerLock));
  
  PLOG_PRINT(stderr, "After global init:\n");


#ifdef DO_TIMINGS
  glf->numLocks = 0;
  glf->lockTime = 0;
#endif

}

				
/********************************************************************/

void local_open_user_file(mappedFileData* mfd,
			  global_file_info* file_info) {
  
  // The user file's index.
  int ufIndex = file_info->id;
  int numPages = file_info->length/PAGESIZE;


  mfd->userFileFd[ufIndex] = open(file_info->name, O_RDWR | O_CREAT , 0666);
  assert(mfd->userFileFd[ufIndex] != -1);

  // Make sure the file is long enough.  Then set the length and fileId fields in
  //   the GLF.
  extendFileToSpecifiedLength(mfd->userFileFd[ufIndex], numPages);


  // Mmap region for original file.
  mfd->userFileRegion[ufIndex] = mmap(0,
				      (size_t)numPages*PAGESIZE,
				      PROT_READ | PROT_WRITE,
				      MAP_SHARED,
				      mfd->userFileFd[ufIndex],
				      (off_t)0);

  assert(mfd->userFileRegion[ufIndex] != MAP_FAILED);

  
  // Now mmap the actual region of the file that we initially return to the programmer:
  mfd->theMmapRegion = mmap(0,
			    file_info->length,
			    PROT_NONE,
			    MAP_SHARED,
			    mfd->userFileFd[ufIndex],
			    (off_t)0);
  assert(mfd->theMmapRegion != MAP_FAILED);

#ifdef DO_TIMINGS
  mfd->mfdNumOthers = 0;
  mfd->mfdMaxTime = 0;
  mfd->mfdOtherTime = 0;
#endif
}


// This function is called by each process, to open the user file.
void server_open_user_file(globalLogFileInfo* glf,
			   const char* userFileName,
			   int numPages,
			   global_file_info* file_info) {
  
  int ufIndex = USER_FILE_INDEX;

  acquireLogManagerLock(glf);
  // Check to see if this is the first time any process has opened
  //   a user file.  If yes, then do some global init.

  if (!(glf->userFileInUse[USER_FILE_INDEX])) {
    // Global init for user file.

    // Currently, we only support one file.
    // Not added yet.  Add it.
    glf->userFileInUse[USER_FILE_INDEX] = TRUE;

    // Set the name of the user file.
    if (userFileName == NULL) {
      // Open an anonymous file.
      snprintf(glf->userFileInfo[ufIndex].name, (size_t)FILE_NAME_LENGTH, DEFAULT_ANONYMOUS_FILE_NAME);
    }
    else {
      // Opening the user's file...
      strncpy(glf->userFileInfo[ufIndex].name, userFileName, (size_t)FILE_NAME_LENGTH);
    }

    glf->userFileInfo[ufIndex].length = numPages;

    if (glf->userFileInfo[ufIndex].length > MAX_PAGES) {
      fprintf(stderr, "Error! Trying to use transaction system on a file that is bigger than MAX_PAGES = %d\n", MAX_PAGES);
      assert(FALSE);
    }
    
    glf->userFileInfo[ufIndex].fileId = USER_FILE_ID;    
  }
  else {
    // GLF already initialized for this user file.  Just open it
    //  for this process.

    if (userFileName == NULL) {
      assert(strncmp(glf->userFileInfo[ufIndex].name, DEFAULT_ANONYMOUS_FILE_NAME, (size_t)FILE_NAME_LENGTH) == 0);
    }
    else {
      //  Verify that we are trying to open the same file...
      assert(strncmp(glf->userFileInfo[ufIndex].name, userFileName, (size_t)FILE_NAME_LENGTH) == 0);
    }

  }

  releaseLogManagerLock(glf);

  // Set the user's file information that we return from "server"
  file_info->id = USER_FILE_INDEX;
  file_info->length = (size_t)(numPages) * PAGESIZE;
  if (userFileName != NULL) {
    strncpy(file_info->name, userFileName, (size_t)FILE_NAME_LENGTH);
  }
  else {
    strncpy(file_info->name, DEFAULT_ANONYMOUS_FILE_NAME, (size_t)FILE_NAME_LENGTH);
  }  
}



void local_close_user_file(mappedFileData* mfd,
			   global_file_info* file_info) {
 
  munmap(mfd->userFileRegion[file_info->id], file_info->length);
  munmap(mfd->theMmapRegion, file_info->length);
  close(mfd->userFileFd[file_info->id]);
  assert(errno == 0);
}


// Close the user file on this process.

void server_close_user_file(globalLogFileInfo* glf,
			    const char* userFileName __attribute__((__unused__)),
			    global_file_info* file_info) {


  // Set the user's file information
  //  With multipel files, we would look up the file and find its id.
  //  Not implemented yet...
  file_info->id = USER_FILE_INDEX;
  //  file_info->length = (size_t)(num_pages) * PAGESIZE;

  if (userFileName != NULL) {
    strncpy(file_info->name, userFileName, (size_t)FILE_NAME_LENGTH);
  }
  else {
    strncpy(file_info->name, DEFAULT_ANONYMOUS_FILE_NAME, (size_t)FILE_NAME_LENGTH);
  }

  // We don't have multiple files implemented yet...
  //  Usually, we should scan through and find the right
  //  index.  For now, we know exactly where it is


  acquireLogManagerLock(glf);
  glf->userFileInUse[USER_FILE_INDEX] = FALSE;
  file_info->length = glf->userFileInfo[USER_FILE_INDEX].length * PAGESIZE;
  releaseLogManagerLock(glf);

  assert(errno == 0);
}



/******************************************/
//  Functions for manipulating the commit files

// Should only be called while holding the log manager lock.
//  Assumes that the commit file in question has been created
//  already.
static void openCurrentCommitFileForProcess(globalLogFileInfo* glf,
					    mappedFileData* mfd) {

  // Check to make sure this process doesn't have a commit record
  //  file open already.
  assert(glf->currentCommitFileInfo.fileId != mfd->myCurrentCommitFileId);

  mfd->commitFileFd = open(glf->currentCommitFileInfo.name, O_RDWR, 0666);
  mfd->myCurrentCommitFileId = glf->currentCommitFileInfo.fileId;
  assert(mfd->commitFileFd != -1);
}


static void closeCurrentCommitFileForProcess(globalLogFileInfo* glf __attribute__((__unused__)),
					     mappedFileData* mfd) {

  assert(mfd->myCurrentCommitFileId != NULL_FILE_ID);
  assert(mfd->commitFileFd != NULL_FILE);
  
  close(mfd->commitFileFd);
  mfd->commitFileFd = NULL_FILE;
  mfd->myCurrentCommitFileId = NULL_FILE_ID;
}



// Should only be called while holding the log manager lock.
//  Creates a new commit file, and updates the glf info
//   accordingly.
static void createNewCommitFile(globalLogFileInfo* glf, const char* path) {

  int tempFd;

  if (glf->currentCommitFileInfo.fileId == NULL_FILE_ID) {
    // First time creating a commit record file.
    // Start counting the commit records at some ids
    //  that we don't use for the page log files.
    glf->currentCommitFileInfo.fileId = START_COMMIT_FILE_ID;
  }
  else {
    glf->currentCommitFileInfo.fileId++;
  }
  
  // Create the log file with a new name.
  generateCommitFileName(glf->currentCommitFileInfo.name,
			 path,
			 glf->currentCommitFileInfo.fileId);  



  //  No longer using this variable!! 
  glf->currentCommitFileInfo.length = 0;
  // Set the offset in the file we are actually using
  glf->currentCommitFileLengthUsed = 0;
  glf->currentCommitFileInfo.status = ACTIVE;



  printf("Creating a commit file with name %s\n",
	 glf->currentCommitFileInfo.name);
  tempFd = creat(glf->currentCommitFileInfo.name, 0666);   // Create a zero-length file.
  assert(tempFd != -1);

  // Don't write zeros to the end of the commit file!  Otherwise, we
  //   can't be guaranteed that when we write, the last page
  //   of a log entry won't end up on disk before the first entry.
  //  extendFileToSpecifiedLength(tempFd, glf->currentCommitFileInfo.length);

  close(tempFd);
//  fprintf(stderr, "I just made a commit file with name %s !! \n", glf->currentCommitFileInfo.name);
}



// Should only be called while holding the log manager lock.
//  Creates a new page log file, and updates the glf info
//   accordingly.
// Looks almost the same as createNewCommitFile
static void createNewPageLogFile(globalLogFileInfo* glf, const char* path) {

  int tempFd;

  // Make sure we haven't created this file already.
  assert(glf->pageLogFileInfo.fileId == NULL_FILE_ID);

  // Create the log file with a new name.
  generatePageLogFileName(glf->pageLogFileInfo.name,
			  path, 
			  PAGE_LOG_ID);
  
  // Create a file with "MAX_PAGES" pages.
  
  glf->pageLogFileInfo.fileId = PAGE_LOG_ID;
  glf->pageLogFileInfo.length = MAX_PAGES;
  glf->pageLogFileInfo.status = ACTIVE;

  // "Add" the first MAX_PAGES" pages to the free list.
  glf->freeListEnd = MAX_PAGES;
  
  
  // Create the file with something in it, close it.
  tempFd = open(glf->pageLogFileInfo.name, O_RDWR | O_CREAT, 0666);
  assert(tempFd != -1);
  extendFileToSpecifiedLength(tempFd, MAX_PAGES);
  close(tempFd);
  
//  printf("I just made a page log file with name %s !! \n", glf->pageLogFileInfo.name);
}


// Should only be called while holding the log manager lock.
//  Assumes that the commit file in question has been created
//  already.
static void openPageLogFileForProcess(globalLogFileInfo* glf,
				      mappedFileData* mfd) {


  // Check to make sure this process doesn't have a commit record
  //  file open already.
  assert(glf->pageLogFileInfo.fileId != NULL_FILE_ID);

  if (mfd->pageLogFileId != glf->pageLogFileInfo.fileId) {
    mfd->pageLogFileId = glf->pageLogFileInfo.fileId;
    mfd->pageLogFileFd = open(glf->pageLogFileInfo.name, O_RDWR, 0666);
    assert(mfd->pageLogFileFd != -1);
  }

  assert(glf->pageLogFileInfo.length > 0);


  // Actually mmap the page log for this process.
  mfd->logFileMmappedLength = glf->pageLogFileInfo.length;
  mfd->logFileRegion = mmap(0,
			    (size_t)(mfd->logFileMmappedLength * PAGESIZE),
			    PROT_READ | PROT_WRITE,
			    MAP_SHARED,
			    mfd->pageLogFileFd,
			    0);
  assert(mfd->logFileRegion != MAP_FAILED);
}


#ifdef DO_MMAP_TIMINGS
int numMmaps = 0;
long long totalMmapTime = 0;
rtimeStruct mt0, mt1;
#endif


static void closePageLogFileForProcess(mappedFileData* mfd) {
  
  assert(mfd->pageLogFileId != NULL_FILE_ID);
  assert(mfd->pageLogFileFd != NULL_FILE);
  
  close(mfd->pageLogFileFd);

  mfd->pageLogFileFd = NULL_FILE;
  mfd->pageLogFileId = NULL_FILE_ID;


#ifdef DO_MMAP_TIMINGS
  printf("On process %d: TOTAL MMAPS acquire time: \n", getpid());
  printf("Total of %d mmap calls:  Avg. %0.6f cycles per mmap, or %0.6f us per mmap\n",
	 numMmaps,
	 1.0 * totalMmapTime / numMmaps,
	 1e6 * totalMmapTime / (numMmaps * 1.4 * 1e9));

  printf("TOTAL MMAP TIME IS ACTUALLY %0.6f ms\n", 1e3*totalMmapTime/ (1.4e9));
#endif	   

}


static void remapPageLogRegionIfNeeded(globalLogFileInfo* glf,
				       mappedFileData* mfd) {
  int currentLength = glf->pageLogFileInfo.length;
  assert(mfd->logFileMmappedLength <= currentLength);
  
  if (mfd->logFileMmappedLength < currentLength) {

    int error = munmap(0, (size_t)(PAGESIZE*currentLength));
    assert(error == 0);

    // Remap the region.
    mfd->logFileMmappedLength = currentLength;
    mfd->logFileRegion = mmap(0,
			      (size_t)(mfd->logFileMmappedLength * PAGESIZE),
			      PROT_READ | PROT_WRITE,
			      MAP_SHARED,
			      mfd->pageLogFileFd,
			      0);
    assert(mfd->logFileRegion != MAP_FAILED);   
  }
}

// Have the current process grow the size of the page log file.
//  Grows it by increasing the size by MAX_PAGES (up to MAX_PAGELOG_SIZE)
static void expandPageLogFile(globalLogFileInfo* glf,
			      mappedFileData* mfd) {
  int newLength;
  int oldLength;

  // assert this process already has the file open.
  assert(glf->pageLogFileInfo.fileId != NULL_FILE_ID);
  assert(mfd->pageLogFileId == glf->pageLogFileInfo.fileId);

  if (mfd->pageLogFileId != glf->pageLogFileInfo.fileId) {
    mfd->pageLogFileId = glf->pageLogFileInfo.fileId;
    mfd->pageLogFileFd = open(glf->pageLogFileInfo.name, O_RDWR, 0666);
    assert(mfd->pageLogFileFd != -1);
  }

  oldLength = glf->pageLogFileInfo.length;
  // Check that this process has a current mapping.
  assert(oldLength > 0);
  assert(mfd->logFileMmappedLength == oldLength);


  // Figure out the new length;
  newLength = oldLength + MAX_PAGES;
  if (newLength > MAX_PAGELOG_SIZE) {
    newLength = MAX_PAGELOG_SIZE;
  }
  
  extendFileToSpecifiedLength(mfd->pageLogFileFd, newLength);
  // remap the pageLogRegion for this process.
  remapPageLogRegionIfNeeded(glf, mfd);
}



// Called by the process the first time it attaches to the
//  system.
// This method should open the current commit file and the
//   current page log file.

void openLogFiles(globalLogFileInfo* glf, mappedFileData* mfd) {

  // Start by initializing my mfd structure.

  mfd->pageLogFileId = NULL_FILE_ID;
  mfd->pageLogFileFd = NULL_FILE;

  mfd->commitFileFd = NULL_FILE;
  mfd->myCurrentCommitFileId = NULL_FILE_ID;

  mfd->readSourceTable = createDPHashTable();

  
  acquireLogManagerLock(glf);

  
  //  printf("TRying to open a commit recod file here.\n");
  // Open the current commit record file.  
  openCurrentCommitFileForProcess(glf, mfd);

  //  printf("TRying to open a page log recod file here.\n");

  // Open the current page log file.
  openPageLogFileForProcess(glf, mfd);
  
  assert(glf->pageLogFileInfo.fileId != NULL_FILE_ID);

/*   printf("shoudl be calling open page log file for process %d, on log fileId %d\n", */
/* 	 getpid(), */
/* 	 glf->pageLogFileInfo.fileId); */
  
  releaseLogManagerLock(glf);
}

void closeLogFiles(globalLogFileInfo* glf, mappedFileData* mfd) {
  free(mfd->readSourceTable);
  closePageLogFileForProcess(mfd);
  closeCurrentCommitFileForProcess(glf, mfd);
}


/***********************************************/
// Private helper methods


// Function that converts a file id to the index where its located.
/* static inline int logFileIdToIndex(globalLogFileInfo* glf __attribute__((__unused__)), */
/* 				   int fileId) { */
/*   return fileId % MAX_NUM_LOG_FILES; */
/* } */


/**
 * Adds pages to the specified file until the length is at least
 *  numPages.
 * Returns the final length of the file, in pages.
 */
static int extendFileToSpecifiedLength(int fd, int numPages) {
  int fileSize, additionalSize;
  fileSize = lseek(fd, (off_t)0, SEEK_END);

  if (fileSize == -1) {
    perror("Can not seek to end of file.");
    assert(FALSE);
  }
  
  additionalSize = numPages - fileSize/PAGESIZE;
  if (additionalSize > 0) {
    // We need to add pages
    int count;
    for (count = 0; count < additionalSize; count++) {
      write(fd, (void*) &emptyArray, (size_t)PAGESIZE);
    }
    return numPages;
  }
  else {
    return fileSize/PAGESIZE + 1*(fileSize%PAGESIZE != 0);
  }
}





// Gets the file descriptor of the file referred to in diskPage.
static int getFdFromDiskPtr(mappedFileData* mfd,
			    dpPtr diskPage) {
  if (diskPage.fileId < MAX_NUM_USER_FILES) {
    // This is one of the user files.
    
    // For now, we only have one user file.
    assert(diskPage.fileId == USER_FILE_ID);

    // Original file should already be open for the process.
    assert(mfd->userFileFd[USER_FILE_INDEX] != NULL_FILE);
    
    return mfd->userFileFd[USER_FILE_INDEX];
  }
  else {
    // We should be in the page log file.

    assert(mfd->pageLogFileFd != NULL_FILE);
    assert(mfd->pageLogFileId == diskPage.fileId);
    return mfd->pageLogFileFd;
  }
}



void mmapDiskPage(mappedFileData* mfd,
		  int pageNumber,
		  dpPtr diskPage,
		  int memProt) {

  int fd;
  void* newAddr;

  eventType befType, aftType;

  switch (memProt) {
      case PROT_NONE:
	  befType = LOC_BEFORE_MMAP_NONE;
	  aftType = LOC_AFTER_MMAP_NONE;
	  break;
      case PROT_READ:
	  befType = LOC_BEFORE_MMAP_READ;
	  aftType = LOC_AFTER_MMAP_READ;
	  break;
      default:
	  befType = LOC_BEFORE_MMAP_WRITE;
	  aftType = LOC_AFTER_MMAP_WRITE;     	 
  }

  fd = getFdFromDiskPtr(mfd, diskPage);
  PLOG_PRINT(stderr, "I want to map page %d to disk page %d, fileId %d\n",
	    pageNumber, diskPage.dp, diskPage.fileId);


/*   addEventToLocalBuffer(currentXC->lcbf, */
/* 			currentXC->currentXId, */
/* 			befType); */

#ifdef DO_MMAP_TIMINGS
  checkCycleCount(&mt0);  
#endif
  newAddr = mmap((void*)((size_t)(mfd->theMmapRegion) + pageNumber*PAGESIZE),
		 (size_t)PAGESIZE,
		 memProt,
		 MAP_SHARED | MAP_FIXED,
		 fd, 
		 //		 getFdFromDiskPtr(glf, mfd, diskPage),
		 (off_t)diskPage.dp*PAGESIZE);
  if (newAddr == MAP_FAILED) {
    perror("CRashing here... why?\n");
    assert(FALSE);
  }

  assert(newAddr != MAP_FAILED);



/*   addEventToLocalBuffer(currentXC->lcbf, */
/* 			currentXC->currentXId, */
/* 			aftType); */
#ifdef DO_MMAP_TIMINGS
  checkCycleCount(&mt1);
  numMmaps++;
  totalMmapTime += clockTimeDiff(mt0, mt1);
#endif

}


// Must hold lock while manipulating this list!
static dpPtr getFreePageLogPage(globalLogFileInfo* glf, mappedFileData* mfd) {
  
  dpPtr freePage;
  freePage.fileId = PAGE_LOG_ID;


  // Some other process may have grown the log file.
  //  Need to remap the page log file if this is true.
  remapPageLogRegionIfNeeded(glf, mfd);

  if (glf->freeListTop >= glf->freeListEnd) {
    // Free list has no more space
    // expand the pagelog file before getting a new page.
    expandPageLogFile(glf, mfd);
  }

  freePage.dp = glf->freeList[glf->freeListTop];
  glf->freeListTop++;

  REF_CT_PRINT(stderr, "I am getting page (%d, %d) as free page!!! \n", freePage.fileId, freePage.dp);
  return freePage;
}

static void returnFreePageLogPage(globalLogFileInfo* glf, dpPtr freePage) {
  if (glf->freeListTop <= 0) {
    printf("ERROR!!! Attempting to return a page (%d, %d) as free page, but it isn't free...\n",
	   freePage.fileId, freePage.dp);
  }
  assert(glf->freeListTop > 0);
  assert(freePage.fileId == PAGE_LOG_ID);

  REF_CT_PRINT(stderr, "I am returning page (%d, %d) as free page!!! \n", freePage.fileId, freePage.dp);
  
  glf->freeListTop--;
  glf->freeList[glf->freeListTop] = freePage.dp;
}
			 

dpPtr writeNewPagesToLogFile(globalLogFileInfo* glf,
			     mappedFileData* mfd,
			     void* memoryRange __attribute__((__unused__)),
			     int numPages, 
			     dpPtr pageToCopy __attribute__((__unused__))) {
  dpPtr answer = nullPagePtr();
  int i;
  
  acquireLogManagerLock(glf);
  for (i = 0; i < numPages; i++) {
    assert(mfd->pageLogFileFd != NULL_FILE);
    answer = getFreePageLogPage(glf, mfd);

    memcpy((void*)((size_t)mfd->logFileRegion + (size_t)answer.dp*PAGESIZE),
	   (void*)((size_t)memoryRange + (size_t)i*PAGESIZE), 
	   (size_t)PAGESIZE);
  }

  releaseLogManagerLock(glf);
  return answer;
}


void copyRangeToUserFile(globalLogFileInfo* glf __attribute__((__unused__)),
			 mappedFileData* mfd,
			 int xactionPageStart,
			 dpPtr diskSourceStart,
			 int numPages) {
  
  void* baseAddr = mfd->logFileRegion;

  assert(diskSourceStart.fileId == PAGE_LOG_ID);
  assert(diskSourceStart.dp + numPages < mfd->logFileMmappedLength);

  memcpy((void*)((size_t)mfd->userFileRegion[USER_FILE_INDEX] + xactionPageStart*PAGESIZE),
	 (void*)((size_t)baseAddr + diskSourceStart.dp * PAGESIZE),
	 (size_t)PAGESIZE*numPages);
  
  assert(errno == 0);
}





// Returns TRUE if the fileId is for a log file, o.w. it is a user file.
static int isLogFileId(int fileId) {
  return fileId == PAGE_LOG_ID;
}


/********************************************************************/

dpPtr createUserFilePtr(int dp) {
  dpPtr answer;
  answer.fileId = USER_FILE_ID;
  answer.dp = dp;
  return answer;
}


// These two methods should be called while holding the log manager lock.
void incRefCount(globalLogFileInfo* glf,
		 dpPtr diskPage) {
  if (isLogFileId(diskPage.fileId)) {

    assert(glf->refCount[diskPage.dp] >= 0);
    glf->refCount[diskPage.dp]++;
    REF_CT_PRINT(stderr, "Just inc. refcount for page (%d, %d) to %d\n",
		 diskPage.fileId,
		 diskPage.dp,
		 glf->refCount[diskPage.dp]);
  }
}


void decRefCount(globalLogFileInfo* glf,
		 dpPtr diskPage) {
  if (isLogFileId(diskPage.fileId)) {


    if (glf->refCount[diskPage.dp] == 0) {
      printf("Error!! Attempting to decrement refCount for a page (%d, %d)\n",
	     diskPage.fileId, diskPage.dp);
      sleep(1000);
    }
    
    glf->refCount[diskPage.dp]--;
    REF_CT_PRINT(stderr,
		 "Just dec. refcount for page (%d, %d) to %d\n",
		 diskPage.fileId,
		 diskPage.dp,
		 glf->refCount[diskPage.dp]);



    //    if (glf->refCount[diskPage.dp] < 0) {
    //      glf->refCount[diskPage.dp] = 0;
    //    }
    assert(glf->refCount[diskPage.dp] >= 0);

    // No more accesses to this page.  Can safely return to free list.
    if (glf->refCount[diskPage.dp] == 0) {
      returnFreePageLogPage(glf, diskPage);
    }
  }
}





#define MAX_LOG_SIZE (10*1024*1024)

void writeDataToCommitFile(globalLogFileInfo* glf,
			   TID currentXId,
			   localCommitBuffer* lcbf, 
			   mappedFileData* mfd,
			   void* buffer, int numBytes) {

  acquireLogManagerLock(glf);


  // Insert a line here which splits the log file if the old one
  //  is greater than a certain size.

  if (glf->currentCommitFileLengthUsed > MAX_LOG_SIZE) {
      createNewCommitFile(glf, glf->control_path);
  }
  
  if (glf->currentCommitFileInfo.fileId != mfd->myCurrentCommitFileId) {
/*     printf("Process %d opening new commit file %d\n", */
/* 	   getpid(), */
/* 	   glf->currentCommitFileInfo.fileId); */

    // close the existing file
    closeCurrentCommitFileForProcess(glf, mfd);
    
    // this function will automatically open the next one.
    openCurrentCommitFileForProcess(glf, mfd);
  }



  assert(mfd->commitFileFd != NULL_FILE);
  assert(numBytes >= 0);
  
  
  if (numBytes > 0) {
    int bytesActuallyWritten = 0;
    int retryCount = 0;

    lseek(mfd->commitFileFd, 0, SEEK_END);
//    lseek(mfd->commitFileFd, glf->currentCommitFileLengthUsed, SEEK_SET);

    addEventToLocalBuffer(lcbf,
			  currentXId,
			  LOC_BEFORE_WRITE);

#ifdef GATHER_STATS
    checkCycleCount(&xlc.xs.writeStartTime);
#endif

    while ((bytesActuallyWritten == 0)  && (retryCount < 10)) {
      bytesActuallyWritten = write(mfd->commitFileFd, buffer, numBytes);
      retryCount++;
    }
    assert(bytesActuallyWritten != 0);

#ifdef GATHER_STATS
    checkCycleCount(&xlc.xs.writeEndTime);
    xlc.xs.bytesLogged = numBytes;
#endif

    addEventToLocalBuffer(lcbf,
			  currentXId,
			  LOC_AFTER_WRITE);

    glf->currentCommitFileLengthUsed += numBytes;
  }
  
  releaseLogManagerLock(glf);
}


void computePageDiff(TID currentXId,
		     localCommitBuffer* lcbf,
		     mappedFileData*mfd,
		     dpPtr diskPage,
		     int pageNum,
		     void* buffer,
		     size_t bufferSize,
		     size_t *n_bytes_written) {
  int fd;
  void* sourceAddr;
  void* newPage;
  //  size_t i;
  int error;

  //  acquireLogManagerLock(glf);
  fd = getFdFromDiskPtr(mfd, diskPage);
  //  releaseLogManagerLock(glf);

  newPage = (void*)((size_t)mfd->theMmapRegion + (size_t)pageNum* PAGESIZE);


  //  fprintf(stderr, "I want to read from page %d with dp. (%d, %d) to compute pagediff\n",
  //	  pageNum, diskPage.fileId, diskPage.dp);
  PLOG_PRINT(stderr, "I want to read from page %d with dp. (%d, %d) to compute pagediff\n",
	     pageNum, diskPage.dp, diskPage.fileId);

  //  printf("What fd did i get? %d\n", fd);
  // Actually map the page I want to read from.  

  addEventToLocalBuffer(lcbf,
			currentXId,
			LOC_BEFORE_MMAP_IN_DIFF);

  sourceAddr = mmap(0,
		    (size_t)PAGESIZE,
		    PROT_READ,
		    MAP_SHARED,
		    fd,
		    (off_t)diskPage.dp*PAGESIZE);


  addEventToLocalBuffer(lcbf,
			currentXId,
			LOC_AFTER_MMAP_IN_DIFF);


  
  if (sourceAddr == MAP_FAILED) {
    perror("CRashing here... why?\n");
    assert(FALSE);
  }

#ifdef GATHER_STATS
  checkCycleCount(&(xlc.xs.compressStartTime));
#endif

#ifndef USE_COMPRESSED_LOGS
  /* The simplest thing to do is to concat the two pages together and write them out.  Now redo and undo are easy. */
  assert(bufferSize >= 2*PAGESIZE);
  memcpy(buffer, sourceAddr, PAGESIZE);
  memcpy(((char*)buffer)+PAGESIZE, newPage, PAGESIZE);
  *n_bytes_written = 2*PAGESIZE; 
#else
  /* Alternatively, we could compress those two pages, preceded by the number of bytes in the compressed representation. */
 {
     char ucbuf[2*PAGESIZE];
     uLongf destlen = bufferSize-2;
     int r;
     memcpy(ucbuf, sourceAddr, PAGESIZE);
     memcpy(ucbuf+PAGESIZE, newPage, PAGESIZE);
     r = compress(((char*)buffer)+4, &destlen, ucbuf, 2*PAGESIZE);
     assert(r==Z_OK);
     assert(destlen+2<=bufferSize);
     ((char*)buffer)[0] = (destlen>>8)&255; /* save the number of bytes in the compressed representation. */
     ((char*)buffer)[1] =  destlen&255;
     *n_bytes_written = destlen+2;
 }
 /* A more complex (and risky) strategy is to try to write enough information to do or undo without writing
  * both pages. */
 /* For example, write an MD5 sum of both the old and new pages, and then only write enough to go forward or backward
  * from a known page... */ 
#endif
  

#ifdef GATHER_STATS  
  checkCycleCount(&(xlc.xs.compressEndTime));
  xlc.xs.totalCompressTime += (xlc.xs.compressEndTime - xlc.xs.compressStartTime);
#endif
/*   printf("First int:  old--> new is %d --> %d\n", */
/* 	 ((int*)sourceAddr)[0], */
/* 	 ((int*)newPage)[0]); */
  
//  snprintf(buffer, bufferSize,
//	   "First int:  old--> new is %d --> %d\n",
//	   ((int*)sourceAddr)[0],
//	   ((int*)newPage)[0]);

  //  for (i = 0; i < bufferSize; i++) {
  //    ((char*)buffer)[i] = ((char*)newPage)[i] -  ((char*)sourceAddr)[i];    
  //  }

 
  
  //  printf("Diff Buffer for page %d (in ints) is: \n", pageNum);
  //  for (i = 0; i < bufferSize / sizeof(int); i++) {
  //    printf("%d  ", ((int*)buffer)[i]);
  //  }
  //  printf("\n");

  error = munmap(sourceAddr, PAGESIZE);
  assert(error == 0);
}



// Actually syncs the log file to disk.
void syncCurrentCommitRecord(globalLogFileInfo* glf,
			     mappedFileData* mfd) {

  int error;
  assert(mfd->myCurrentCommitFileId == glf->currentCommitFileInfo.fileId);
#ifdef GATHER_STATS
  checkCycleCount(&(xlc.xs.fsyncStartTime));
#endif
  error = fsync(mfd->commitFileFd);  

#ifdef GATHER_STATS
  checkCycleCount(&(xlc.xs.fsyncEndTime));
#endif
  assert(error == 0);
}

// Syncs the user file, and see
void syncUserFile(globalLogFileInfo* glf __attribute__((__unused__)),
		  mappedFileData* mfd) {
  assert(mfd->userFileFd[USER_FILE_INDEX] != NULL_FILE);
  fsync(mfd->userFileFd[USER_FILE_INDEX]);
  assert(errno == 0);
}


/******************************************************************/
// Functions manipulating the read source table

void addPageToReadSourceTable(mappedFileData* mfd, int virtualPageNum, dpPtr diskPage) {
  insertDiskPage(mfd->readSourceTable, virtualPageNum, diskPage);
}

dpPtr removePageFromReadSourceTable(mappedFileData* mfd, int virtualPageNum) {
  return deleteDiskPage(mfd->readSourceTable, virtualPageNum);
}

dpPtr getPageFromReadSourceTable(mappedFileData* mfd, int virtualPageNum) {
  return getDiskPage(mfd->readSourceTable, virtualPageNum);
}

int numPagesInReadSourceTable(mappedFileData* mfd) {
  return hTableSize(mfd->readSourceTable);
}



/******************************************************************/
// Print functions for debugging


void printFinalRefCounts(globalLogFileInfo* glf) {
  int i = 0;
  int sum = 0;

  //  printf("RefCounts from 1 to 20\n");
  //  for (i = 0; i < 20; i++) {
  //    printf("%d:  %d\n", i, glf->refCount[i]);
  //  }

  
  for (i = 0; i < MAX_PAGELOG_SIZE; i++) {
    if (glf->refCount[i] != 0) {
      printf("Error on page %d: refCount is %d\n",
	     i, glf->refCount[i]);
    }
    sum += (glf->refCount[i] != 0);
  }
//  printf("The num. of things we got wrong in the end: %d\n", sum);
}
