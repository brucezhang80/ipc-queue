#ifndef __GLOBAL_TYPES_H
#define __GLOBAL_TYPES_H

#include "basics.h"
#include "commitBuffer.h"
#include "cycle_counter.h"
#include "file_manager.h"
#include "lockTest.h"
#include "xactionNodeList.h"

#include "xStats.h"



#include "global_file_dir.h"


/**********************************************************/
// Information about a particular transaction.

typedef enum {FAILED, PENDING, ABORTED, COMMITTED, COMMITTED_ON_DISK} xactionStatus;
typedef enum {NONE, READING, WRITING, TRANSFER} accessStatus;


// Types of policies for concurrency control
typedef enum {SIMPLE, TIME_STAMP} AbortPolicy;

// This struct is the information
//  about a transaction.
typedef struct xactionInfo {
  int id;
  int timeStamp;
  xactionStatus status;
  //  pageList readSet;
  //  pageList writeSet;
  int pageSet[MAX_PAGES];
  int nextPage[MAX_PAGES];
  int prevPage[MAX_PAGES];

  int numPages;
  int readSetIndex;
  int writeSetIndex;
  
  accessStatus pageStatusCount[MAX_PAGES];
  int pagePtrs[MAX_PAGES];
} xactionInfo;


typedef struct xinfoFreeListStruct{
  int freeList[MAX_XACTIONS];
  int freeListTop;
  int timeStampCounter;
} xinfoFreeListStruct;




// Information pointing us to a disk page in some log file.


typedef struct xactionMmap {
  // This array maps a transactional page number to a disk page in a file
  dpPtr pageMap[MAX_XACTIONS+1][MAX_PAGES];

  
  // For each disk page, this keeps track of the number
  //   of references to each page.
  //  int refCount[MAX_PAGES*(MAX_XACTIONS+1)];
  
} xactionMmap;


// This structure is not really a queue -- its just a list.
typedef struct unmapQueue {
  int length;
  int page[MAX_PAGES];
  dpPtr dpage[MAX_PAGES];
  int pageIsWrite[MAX_PAGES];
  
} unmapQueue;


/******************************************************/
// The structures for a dep. tree

#define NULL_ID -1
#define NULL_LIST -2
#define NUM_LISTS (3*(MAX_XACTIONS+1))

typedef struct xDepList {
  int parent;
  int v[MAX_XACTIONS];
  int length;
} xDepList;


// The structure for the entire dependency tree.
typedef struct xDepTree {

  int parent[MAX_XACTIONS+1];
  int next[MAX_XACTIONS+1];

  int pendingListPtr[MAX_XACTIONS+1];
  int failedListPtr[MAX_XACTIONS+1];
  int readOnlyListPtr[MAX_XACTIONS+1];
  int isCommitted[MAX_XACTIONS+1];

  xDepList lists[NUM_LISTS];
  int lFreeList[NUM_LISTS];
  int lFreeTop;

  int lastCommitted;
  
} xDepTree;


/**
 * ALL the global variables a process needs to 
 *  work with the transactional system...
 *
 */


#define X_NAME_LENGTH 100  // The maximum length of a file name





typedef struct xactionContext {

  /********************************************************************
   * These top fields are all pointers into the control file.
   *  These pointers are set when we attach a process to the control file.
   *
   ********************************************************************/

  int controlFd;        // A file descriptor to the control file.
  void* controlRegion;  // A memory-mapped address into the control region.

  // The global lock
  Cilk_lockvar* xactionGlobal;

    // Stuff for log sequencing
    Cilk_lockvar* lsnNumLock;

#ifdef USE_LSN
    unsigned long long* lsnPtr;
    unsigned long long* lsnLastCommitted;
#endif
//  Cilk_lockvar* gbcollectLock;
  
  // From xactionInfo
  xactionInfo* transactionArray;
  int* xactionArrayInUse;
  xactionNodeList* pageToXactionReads;
  xactionNodeList* pageToXactionWrites;
  xinfoFreeListStruct* theXinfoFLStruct;


  // the dependency tree
  xDepTree* t;

  // From xactionMmap
  xactionMmap* theMmap;
  globalLogFileInfo* glf;


  globalCommitBuffer* gcbf;


  global_file_directory* gfiledir;
  
  /********************************************************************
   * These rest of the fields are variables that are local
   *  to each process.  Each process has a different 
   *  copy of these variables.
   ********************************************************************/

  
  //  localCommitBuffer* lcbf;  // The local commit buffer  
  //  mappedFileData* mfd;

  
  //  int insideXaction;
  //  int xactionNestCounter;
  //  int currentXId;

  unsigned long long myLSN;

  // Trash storage for the queue of pages to unmap
  //  unmapQueue pagesToUnmap;
  
  //  xactionMetaDataPtr xmdPtr;
  //  int isDurable;
  //  int isReadOnlyXaction;
  //  int pid;

  // For colllecting statistics....  
  //  int numAborts;

#ifdef DO_LOCK_TIMINGS    
  rtimeStruct lockT1;
  rtimeStruct lockT2;
  long long lockTime;
  int numLocks;
#endif

  int logTestModeOn;

    
} xactionContext;


typedef struct actualGlobalStruct {

  Cilk_lockvar actualXactionGlobal;
//  Cilk_lockvar actualGbcollectLock;


#ifdef USE_LSN
    // Stuff for log sequencing
    Cilk_lockvar actualLsnNumLock;
    unsigned long long actualLsnCounter;
    unsigned long long actualLsnLastCommitted;
#endif
    
  xactionInfo actualTransactionArray[MAX_XACTIONS+1];
  int actualXactionArrayInUse[MAX_XACTIONS+1];
  xactionNodeList actualPageToXactionReads[MAX_PAGES];
  xactionNodeList actualPageToXactionWrites[MAX_PAGES];
  xinfoFreeListStruct actualXInfoFLStruct;

  xDepTree actualT;

  xactionMmap actualMmap;
  globalLogFileInfo actualGLF;
  Cilk_lockvar actualLogManagerLock;

  globalCommitBuffer actualGCBF;
  
  //  int actualMmapFreeList[MAX_XACTIONS*MAX_PAGES];
  //  freeListStruct actualFLStruct;

  int globalLogLength;
  char logName[X_NAME_LENGTH];
  char uFName[X_NAME_LENGTH];
} actualGlobalStruct;


/** Functions for initializing the data structures **/

void initXactionInfoTable(xactionContext* xc);
void initPageInfoTable(xactionContext* xc); 
AbortPolicy currentAbortPolicy(xactionContext* xc); 




#endif
