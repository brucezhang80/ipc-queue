/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * xactionLib.h
 *
 *  Implements most of the high level functions that deal with
 *   global stuff (xInit/xShutdown for example)
 */


#ifndef __XACTION_LIB_H
#define __XACTION_LIB_H

#include <errno.h>
#include <sched.h>
#include <signal.h>
#include <string.h>
#include <sys/file.h>

#include "libxac.h"
#include "xactionLib.h"

#include "cycle_counter.h"
#include "debugTools.h"
#include "globalControl.h"
#include "lockTest.h"
#include "pageMap.h"
#include "xactionHelpers.h"
#include "xConflict.h"
#include "xDep.h"
#include "xStats.h"

#include "libxac_client_types.h"
#include "file_defs.h"

TID get_transaction_id(xaction_local_context* xlocal,
		       int is_query);

void xMmap_server_side(xaction_local_context* xlocal,
		       const char* userFileName,
		       int numPages);

void xMunmap_server_side(xaction_local_context* xlocal,
			 const char* fileName);


void checkForConflict(xaction_local_context* xlc,
		      TID id,
		      int pageNumber);


void setPageAccess(xaction_local_context* xlocal,
		   TID id,
		   int pageNum,
		   int doOnlyRead);


int xend_server_side_step1(xaction_local_context* xlocal);

// Call this function to prepare a log entry for commit, and
//  to sync. the log entry to file.
void xend_server_side_step2(xaction_local_context* xlocal);
void xend_server_side_step3(xaction_local_context* xlocal,
			    int didCommit);
void xend_server_side_step4(xaction_local_context* xlocal);

void xendQuery_server_side_step1(xaction_local_context* xlocal);

#endif
