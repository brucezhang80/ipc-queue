/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2006    Massachusetts Institute of Technology
 * Copyright (c) 2006    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * lbxc_malloc.h
 *
 *    Header file for simple buddy-system implementation of malloc
 *    
 */

#ifndef __LBXC_MALLOC_H
#define __LBXC_MALLOC_H

#include <stdio.h>
#include <stdlib.h>

#include "lbxc_math.h"

typedef size_t OFFSET_PTR;

#define NULL_OFFSET 0

#define CONTROL_BLOCK_SIZE 4096


#define BUCKET_BEGIN 6     // Smallest size memory block we can allocate is 2^6 = 64 bytes.
#define SMALLEST_BLOCK (1 << BUCKET_BEGIN)  // The size of the smallest block we can malloc

#define BUCKET_END 64      // Maximum size of bucket is 2^63.  This
			   // should be more than plenty...

#define NO_BLOCK 0

typedef struct {
  unsigned int largest_block_index;
  size_t current_arena_size;
  OFFSET_PTR free_blocks[BUCKET_END];
} bucket_list;


#define IN_USE 0
#define FREE 15
#define TAG_SIZE 1

// The tag on a block.
typedef struct {
  char tag;              // 1 == IN_USE, 0 == FREE
  unsigned int k;                // Size of block is 2^k

  OFFSET_PTR next;          // next and 
  OFFSET_PTR prev;          //  previous pointers     

  //  char pad[sizeof(size_t) - TAG_SIZE];
} block_tag;



typedef struct {
  bucket_list free_buckets;
} arena_header;



// This is 2^k
#define BUCKET_SIZE(k) ((size_t)(1LL << (k)))


// Converts an offset into a pointer
#define OFFSET_TO_PTR(offset, base_addr) ((void*) ((offset) + (size_t)(base_addr)))



// Initializes an arena of memory of the specified size, 
//  starting at the specified address.
//  Returns 0 if successful, -1 otherwise.

int lbxc_arena_init(size_t arena_size, void* base_addr);

// Returns an offset into the file.
//  (or 0) if no memory is available.
size_t lbxc_malloc(size_t size, void* base_addr);

// Returns 0 on success and -1 on error.
int lbxc_free(size_t user_offset, void* base_addr);



// A function to resize the arena..
//  new_size is the size of memory now available to
//  the arena.  It should be greater than the current size.
//  Returns 0 if successfully resized, and non-zero if error
int lbxc_arena_grow(size_t new_size, void* base_addr);


// Return the size of the current arena.
size_t lbxc_arena_length(void* base_addr);


void* lbxc_arena_control_data_ptr(void* base_addr);
size_t lbxc_arena_control_data_size(void* base_addr);



#endif
