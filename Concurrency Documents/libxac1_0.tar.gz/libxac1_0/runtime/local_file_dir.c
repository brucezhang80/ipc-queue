/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * local_file_dir.c
 *
 */

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>



#include "lbxc_math.h"
#include "local_file_dir.h"


#define INIT_FARRAY_SIZE 5

// Malloc's a local file directory and initializes it.
local_file_directory* create_local_file_directory(void) {

  int i;
  local_file_directory* filedir;

  filedir = (local_file_directory*)malloc(sizeof(local_file_directory));
  assert(filedir != NULL);

  
  filedir->num_files = 0;
  filedir->farray_size = 10;


  filedir->farray = (local_file_info*)malloc((size_t)filedir->farray_size * (sizeof(local_file_info)));
  assert(filedir->farray != NULL);

  for (i = 0; i < filedir->farray_size; i++) {
    filedir->farray[i].fid = NO_FILE_ID;
  }
  
  return filedir;
}

// Free the local file directory structure.
void destroy_local_file_directory(local_file_directory* filedir) {
  assert(filedir != NULL);

  if (filedir->num_files != 0) {
    fprintf(stderr, "WARNING: trying to destroy a localfile directory that is not empty.\n");
  }

  // Free the file directory array
  free(filedir->farray);
  free(filedir);
}


static inline int lfinfo_empty(local_file_info* lfinfo) {
  return (lfinfo->fid == NO_FILE_ID);
}


static int local_dir_contains_helper(local_file_directory* filedir, FILE_ID id) {
  int i;
  for (i = 0; i < filedir->farray_size; i++) {
    if (filedir->farray[i].fid == id) {
      return i;
    }
  }

  return -1;
}


static int local_dir_contains(local_file_directory* filedir,
			      global_file_info* finfo) {

  int i;
  if (finfo == NULL) {
    return -1;
  }
  
  i = local_dir_contains_helper(filedir, finfo->id);
  if (i == -1) return -1;

  // We should find the file at index i.

  // Check the file names to make sure they are the same.
  assert(strncmp(filedir->farray[i].name,
		 finfo->name,
		 XFNAME_LENGTH) == 0);

  return i;
}



static int add_file_to_directory(local_file_directory* filedir,
				 global_file_info* finfo) {

  int i;
  int first_free_id = -1;
  int correct_index = -1;
  if (finfo == NULL) {
    return -1;
  }

  // Scan through unsorted list of files to search.
  for (i = filedir->farray_size-1; i >= 0; i--) {
    if (lfinfo_empty(&filedir->farray[i])) {
      first_free_id = i;
    }
    else {

      if (filedir->farray[i].fid == finfo->id) {
	// check that file names also match
	assert(strncmp(finfo->name, filedir->farray[i].name, XFNAME_LENGTH) == 0);
	correct_index = i;
	break;
      }
    }
  }

  if (correct_index != -1) {
    // Trying to add a file that already exists..
    printf("File %s already exists in directory..\n",
	   finfo->name);
    return correct_index;
  }
  else {
    if (first_free_id == -1) {
      // We don't have space in the array. resize it..
      void* temp;
      int j;

      temp = realloc(filedir->farray,
		     filedir->farray_size * 2 * sizeof(local_file_info));

      printf("RESIZED ARRAY TO SIZE %d\n", filedir->farray_size);
      assert(temp != NULL);
      filedir->farray = temp;

      for (j = filedir->farray_size; j < filedir->farray_size*2; j++) {
	filedir->farray[j].fid = NO_FILE_ID;
      }
      
      first_free_id = filedir->farray_size;
      filedir->farray_size *= 2;            
    }

    // Add the new info to the free id.
    filedir->farray[first_free_id].fid = finfo->id;
    strncpy(filedir->farray[first_free_id].name,
	    finfo->name,
	    XFNAME_LENGTH);

    filedir->farray[first_free_id].fd = -1;
    filedir->farray[first_free_id].addr = NULL;
    filedir->farray[first_free_id].current_length = 0;
    filedir->num_files++;
    return first_free_id;
  }
}

static int delete_file_from_directory(local_file_directory* filedir,
				      global_file_info* finfo) {
  int i;
  assert(finfo != NULL);

  i = local_dir_contains(filedir, finfo);

  if (i == -1)  {
    // File not found.
    return -1;
  }
  else {
    filedir->farray[i].fid = NO_FILE_ID;
    filedir->num_files--;
    return 0;
  }
}



// This function takes in the file information 
//  (from the main server), adds it to the directory,
//  opens the file on this process,
//   and memory-maps the region.
// Returns 0 if successful and -1 if error.
int open_user_file(local_file_directory* filedir,
		   global_file_info* finfo) {

  int i;
  local_file_info* temp_info;

  // Get the index in the directory of this file.
  i = add_file_to_directory(filedir, finfo);
  
  temp_info = &filedir->farray[i];


  if (temp_info->addr == NULL) {
    printf("Opening file %s\n" , temp_info->name);
    temp_info->fd = open(temp_info->name, O_RDWR, 0666);
    assert(temp_info->fd != -1);

    
    // Check that the file is actually large enough.
    {
      off_t end_of_file = lseek(temp_info->fd, 0, SEEK_END);

      printf("File has length %zd.  Specified length in info is %zd\n",
	     (size_t)end_of_file,
	     (size_t)finfo->length);
      assert((size_t)end_of_file >= finfo->length);
    }



    // Actually mmap the user file and set its length field.
    temp_info->current_length = page_length_ceil(finfo->length);
    temp_info->addr = mmap(temp_info->addr,
			   temp_info->current_length,
			   PROT_READ | PROT_WRITE,
			   MAP_SHARED,
			   temp_info->fd,
			   (off_t)0);
    assert(temp_info != MAP_FAILED);

    printf("File %s mmapped at address %p\n",
	   temp_info->name,
	   temp_info->addr);
  }
  else {
    printf("ERROR! File %s should already be mapped at address %p\n",
	   finfo->name,
	   temp_info->addr);
    assert(temp_info->fd != -1);
    assert(temp_info->current_length == 0);
  }

  printf("Done opening user file %s\n", temp_info->name);
  return 0;
}


// Changes the memory-map of the file if necessary to
//  match the new length
// Returns 0 if successful and -1 if error.
//  (i.e., if that file is not in the directory)
int resize_user_file(local_file_directory* filedir __attribute__((__unused__)),
		     global_file_info* finfo __attribute__((__unused__))) {

  printf("RESIZE USER FILE NOT IMPLEMENTED!! \n");
  return -1;
}



static void print_local_file_info(local_file_info* finfo) {
  assert(finfo != NULL);

  if (finfo->fid != NO_FILE_ID) {
    printf("**********************\n");
    printf("Local File info %p:  \n", finfo);

    printf("Name = %s.  FID = %d\n", finfo->name, finfo->fid);
    printf("fd = %d, addr = %p, current_length = %zd\n",
	   finfo->fd, finfo->addr, finfo->current_length);
    printf("***********************\n");
  }
  else {
    printf("**** NO_FILE ****\n");
  }
}


void print_local_file_directory(local_file_directory* filedir, int show_details) {
  int i;
  assert(filedir != NULL);
  printf("Local File directory %p: \n", filedir);

  printf("Num files = %d\n", filedir->num_files);
  for (i = 0; i < filedir->farray_size; i++) {
    if (show_details || (filedir->farray[i].fid != NO_FILE_ID)) {
      printf("File %d: \n", i);
      print_local_file_info(&filedir->farray[i]);
    }
  }  
  printf("----------------\n");
}
				

// Unmaps the user file, closes the file, and removes the
//  file from the local directory.
int close_user_file(local_file_directory* filedir,
		    global_file_info* finfo) {

  int i;
  local_file_info* temp_info;


  assert(finfo != NULL);
  
  
  i = local_dir_contains(filedir, finfo);
  
  
  if (i != -1) {
    int error;
    temp_info = &filedir->farray[i];

    assert(temp_info->addr != NULL);
    assert(temp_info->current_length > 0);
    error = munmap(temp_info->addr,
		   temp_info->current_length);
    printf("just munmap'ed address %p\n", temp_info->addr);
    assert(error == 0);


    assert(temp_info->fd != -1);
    error = close(temp_info->fd);
    assert(error == 0);

    // Clear the info just in case...
    temp_info->addr = NULL;
    temp_info->fd = -1;
    temp_info->current_length = 0;
    
    printf("Done closing file %s\n", finfo->name);
    
    return 0;
  }
  else {
    printf("ERROR! Trying to close a user file %s that isn't open...\n",
	   finfo->name);
  }

  
  return -1;
}


/******************************************************/
//  All the functions below are test code.

static void test_create_destroy_local_file_directory(void) {

  local_file_directory* filedir;

  filedir = create_local_file_directory();
  assert(filedir != NULL);
  printf("Created local file directory.\n");

  print_local_file_directory(filedir, 0);

  destroy_local_file_directory(filedir);
  printf("Destroyed local file directory\n");  
}


static void test_add_delete_file_directory(void) {

  local_file_directory* filedir;
  global_file_info ftest1, ftest2;
  int error;


  strncpy(ftest1.name, "foo.dat", XFNAME_LENGTH);  
  ftest1.id = 10;
  strncpy(ftest2.name, "bar.dat", XFNAME_LENGTH);
  ftest2.id = 13;

  filedir = create_local_file_directory();
  assert(filedir != NULL);
  printf("Created local file directory.\n");
  print_local_file_directory(filedir, 0);


  add_file_to_directory(filedir, &ftest1);
  //  print_local_file_directory(filedir, 0);

  assert(local_dir_contains(filedir, &ftest1) != -1);
  assert(local_dir_contains(filedir, &ftest2) == -1);

  add_file_to_directory(filedir, &ftest2);
  //  print_local_file_directory(filedir, 0);
  
  assert(local_dir_contains(filedir, &ftest1) != -1);
  assert(local_dir_contains(filedir, &ftest2) != -1);


  error = delete_file_from_directory(filedir, &ftest1);
  assert(error == 0);
  assert(local_dir_contains(filedir, &ftest1) == -1);
  assert(local_dir_contains(filedir, &ftest2) != -1);


  error = delete_file_from_directory(filedir, &ftest1);
  assert(error == -1);
  assert(local_dir_contains(filedir, &ftest1) == -1);
  assert(local_dir_contains(filedir, &ftest2) != -1);
  print_local_file_directory(filedir, 0);

  error = delete_file_from_directory(filedir, &ftest2);
  assert(error == 0);
  assert(local_dir_contains(filedir, &ftest1) == -1);
  assert(local_dir_contains(filedir, &ftest2) == -1);
  


  destroy_local_file_directory(filedir);
  printf("Destroyed local file directory\n");  
}


static void test_random_add_delete(void) {


  const int num_files = 200;  
  local_file_directory* filedir;
  global_file_info ftest[num_files];
  int in_directory[num_files];
  int i, j;

  int num_tests = 10*num_files;

  

  // Assign each file a different name and id.
  for (i = 0; i < num_files; i++) {
    in_directory[i] = 0;
    snprintf(ftest[i].name, XFNAME_LENGTH,
	     "foo%d.dat", i);
    ftest[i].id = 10 + 2*i;
  }



  filedir = create_local_file_directory();
  assert(filedir != NULL);
  printf("Created local file directory.\n");


  for (j = 0; j < num_tests; j++) {
    int rand_file;
    rand_file = (int)(num_files*1.0*rand()/(RAND_MAX+1.0));

    if (in_directory[rand_file]) {
      int error;
      printf("Deleting %d from directory\n", rand_file);
      assert(local_dir_contains(filedir, &ftest[rand_file]) != -1);
      error = delete_file_from_directory(filedir, &ftest[rand_file]);
      assert(error == 0);      
      assert(local_dir_contains(filedir, &ftest[rand_file]) == -1);
      in_directory[rand_file] = 0;
    }
    else {
      printf("Inserting %d into directory\n", rand_file);
      assert(local_dir_contains(filedir, &ftest[rand_file]) == -1);
      add_file_to_directory(filedir, &ftest[rand_file]);
      assert(local_dir_contains(filedir, &ftest[rand_file]) != -1);      
      in_directory[rand_file] = 1;
    }

    {
      int k;
      for (k = 0; k < 10; k++) {
	rand_file = (int)(num_files*1.0*rand()/(RAND_MAX+1.0));
	if (in_directory[rand_file]) {
	  assert(local_dir_contains(filedir, &ftest[rand_file]) != -1);
	}
	else {
	  assert(local_dir_contains(filedir, &ftest[rand_file]) == -1);	  
	}
      }
    }

    printf("Directory size is %d\n", filedir->num_files);
  }


  for (i = 0; i < num_files; i++) {
    if (in_directory[i]) {
      delete_file_from_directory(filedir, &ftest[i]);
    }
  }

  destroy_local_file_directory(filedir);

  printf("Finished test_random_add_delete\n");
}


static void test_open_close_file(void) {
  
  const int num_files = 10;  
  local_file_directory* filedir;
  global_file_info ftest[num_files];
  int i;

  

  // Assign each file a different name and id.
  for (i = 0; i < num_files; i++) {
    snprintf(ftest[i].name, XFNAME_LENGTH,
	     "foo%d.dat", i);
    ftest[i].id = 10 + 2*i;
    ftest[i].length = (5 + (rand()%30))*(size_t)(4096);

    // Make sure the file is long enough.
    {
      int fd;
      unsigned int k;
      char emptyArray[4096];

      fd = open(ftest[i].name, O_CREAT | O_RDWR, 0666);
      assert(fd != -1);

      for (k = 0; k < ftest[i].length; k++) {
	write(fd, emptyArray, 4096);
      }      
      close(fd);
      
      printf("Created file %s of length %zd\n", ftest[i].name, ftest[i].length);
    }  
  }

  printf("Running test_open_close_file\n");


  filedir = create_local_file_directory();
  assert(filedir != NULL);
  printf("Created local file directory.\n");

  for (i = 0; i < num_files; i++) {

    int error;
    printf("Opening file %s\n", ftest[i].name);
    error = open_user_file(filedir, &ftest[i]);
    assert(error == 0);    
  }


  for (i = 0; i < num_files; i++) {
    int error;
    printf("Closing file %s\n", ftest[i].name);
    error = close_user_file(filedir, &ftest[i]);
    assert(error == 0);    
  }

  printf("Done with test_open_close_file\n");
}



int local_file_dir_test_code(void) {
  test_create_destroy_local_file_directory();
  test_add_delete_file_directory();
  test_random_add_delete();
  test_open_close_file();
  return 0;
}

