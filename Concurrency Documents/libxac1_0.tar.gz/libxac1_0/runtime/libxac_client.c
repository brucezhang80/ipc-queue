/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * libxac_client.c
 *
 */

#include <errno.h>
#include <sched.h>
#include <signal.h>
#include <string.h>
#include <sys/file.h>

#include "libxac.h"

#include "debugTools.h"
#include "globalControl.h"
#include "lockTest.h"
#include "xactionHelpers.h"
#include "xDep.h"


#include "libxac_client_types.h"
#include "xactionLib.h"


xaction_local_context xlc;
int isDurableTempFlag;
mappedFileData actualMFD;


int process_init_done = FALSE;

/**
 * The seg-fault handler.  This is called whenever a transaction 
 *  tries to read or write to a page for the first time.
 * We change the protections of the page inside.
 */
static void segv_handler(int sig __attribute__((__unused__)),
 			 siginfo_t *si,
			 void *x __attribute__((__unused__))) {

  void *addr = si->si_addr;
  void *page = (void*)(((PTR_INT)addr)&~(PAGESIZE-1));
  int pageNum = ((PTR_INT)page - (PTR_INT)(xlc.mfd->theMmapRegion))/PAGESIZE;

#ifdef DO_TIMINGS
  checkTimer(&xlc.pageT1);
#endif
  if ((!xlc.insideXaction)
      || (pageNum < 0)
      || (pageNum > MAX_PAGES)) {
    fprintf(stderr, "Fatal error: we have a seg. fault outside a transaction\n");
    fprintf(stderr, "We are attempgint to access Address %p, on page %d.\n", addr, pageNum);
    fprintf(stderr, "The mmap region address is %p, difference is %zd\n",
	    xlc.mfd->theMmapRegion,
	    (PTR_INT)addr - (PTR_INT)(xlc.mfd->theMmapRegion));
    fprintf(stderr, "What is my nest counter? %d \n", xlc.xactionNestCounter);
    sleep(1000);
    exit(1);
  }


  
  DBPRINT(stderr, "********************************\n");
  DBPRINT(stderr, "Inside seg fault handler on process %d. Handling address %p, page %p, pageNum %d\n trans %d\n",
	  getpid(),
	  addr,
	  page,
	  pageNum,
	  xlc.currentXId);
  

  // This function acquires the global lock
  checkForConflict(&xlc, xlc.currentXId, pageNum);

  
  DBPRINT(stderr, "***  End segv %d *****************************\n\n", xlc.currentXId);

#ifdef DO_TIMINGS
  checkTimer(&xlc.pageT2);
  {
    double value = timeDiff(xlc.pageT1, xlc.pageT2);
    if (value > xlc.maxWriteTime) {
      //      printf("replacinv value with %0.6f\n", value);
      xlc.maxWriteTime = value;
    }
    xlc.pageTime += timeDiff(xlc.pageT1, xlc.pageT2);
    xlc.numPageCounts++;
  }
#endif
}

// (Black) magic to setup the seg fault handler...
static int setup_segv_handler(void) {
  struct sigaction action;
  action.sa_sigaction = segv_handler;

  if (sigemptyset(&action.sa_mask)) return -1;

  action.sa_flags = (SA_SIGINFO);

  if (sigaction(SIGSEGV, &action, 0)) return -1;
  return 0;
}



#ifdef DO_PAGE_ACCESS

// The advisory function looks like a seg fault
void xAdvisory(void* addr, int doOnlyRead) {
  void *page = (void*)(((PTR_INT)addr)&~(PAGESIZE-1));
  int pageNum = ((PTR_INT)page - (PTR_INT)(xlc.mfd->theMmapRegion))/PAGESIZE;
  int id = xlc.currentXId;
  //  int isPending;
  //  int releasedLock = FALSE;
  //  accessStatus currentStatus;

  //  fprintf(stderr, "CALLED SET PAGE ACCESS ON addr %p, page %d\n", addr, pageNum);
  if (xlc.insideXaction) {
    if ((pageNum < 0) || (pageNum > MAX_PAGES)) {
      fprintf(stderr, "Fatal error: we are calling setPageRead on an invalid page...\n");
      fprintf(stderr, "We are attempgint to access Address %p, on page %d.\n", addr, pageNum);
      fprintf(stderr, "The mmap region address is %p, difference is %zd\n",
	      xlc.mfd->theMmapRegion,
	      (PTR_INT)addr - (PTR_INT)(xlc.mfd->theMmapRegion));
      return;
    }

    setPageAccess(&xlc, id, pageNum, doOnlyRead);
  }
  else {
    fprintf(stderr, "Error: attempting to call setPageAccess outside a transaction. \n");
  }
}

#else
void xAdvisory(void* addr __attribute_((__unused__)),
	       int doOnlyRead __attribute__((__unused__))) {

}
#endif



void* xMmap(const char* userFileName, int numPages) {
  if ((numPages > 0) && (numPages <= MAX_PAGES)) {

//    fprintf(stderr, "Before attach tronl.\n");
//    currentXC = attachControlRegion(userFileName);

    if (!process_init_done) {
      xlc.isDurable = isDurableTempFlag;    
      xlc.insideXaction = FALSE;
      xlc.isReadOnlyXaction = FALSE;
      xlc.currentXId = NULL_TRANS_ID;
      xlc.xactionNestCounter = 0;
      xlc.mfd = &actualMFD;

      // This doesn't actually work unless every process calls attach
      //   by itself.
      xlc.pid = getpid();

      //    printf("About to enter per-process init.\n");
      //    perProcessControlInitialization(currentXC, userFileName, numPages);

      setup_segv_handler();

      process_init_done = TRUE;
    }


    // Make a call to the "server" to attach to the global control region.
    //  This function grabs the necessary locks..    
    xMmap_server_side(&xlc, userFileName, numPages);




#ifdef COUNT_STATS
    xlc.numXactions = 0;
    xlc.numPagesRead = 0;
    xlc.numPagesWritten = 0;
#endif

#ifdef DO_TIMINGS
    xlc.numAborts = 0;
    xlc.numLocks = 0;

    xlc.numSyncs = 0;
    xlc.syncTime = 0;
    xlc.maxSyncTime = 0;

    xlc.numUSyncs = 0;
    xlc.uSyncTime = 0;
    xlc.maxUSyncTime = 0;

    xlc.numOthers = 0;
    xlc.otherTime = 0;
    xlc.lockTime = 0;
    xlc.maxSyncTime = 0;
  
    xlc.pageTime = 0;
    xlc.numPageCounts = 0;
    xlc.maxWriteTime = 0;

    xlc.numOthers = 0;
    xlc.maxOther = 0;
    xlc.otherTime = 0;
#endif
    
#ifdef GATHER_STATS
    clearXactionStats(&xlc.xs);
#endif

/*     fprintf(stderr, "Process %d attached %d pages from %s at address %p\n", */
/* 	    getpid(), */
/* 	    numPages, */
/* 	    userFileName, */
/* 	    xlc.mfd->theMmapRegion); */
    
    return xlc.mfd->theMmapRegion;
  }
  else {
    fprintf(stderr, "Error! %d is invalid number of pages for user file %s\n", numPages, userFileName);
    assert(FALSE);
    return NULL;
  }
}


void xMunmap(const char* fileName) {

  xMunmap_server_side(&xlc, fileName);

  assert(errno == 0);
}


// returns TRUE if we are inside a transaction, FALSE otherwise.
int insideTransaction(void) {
  return xlc.insideXaction;
}


static int xbegin_helper(int is_query) {
    int failCounter = 0;

  if (xlc.xactionNestCounter == 0) {    
    xlc.insideXaction = TRUE;

    xlc.isReadOnlyXaction = is_query;
    
#ifdef GATHER_STATS
    clearXactionStats(&xlc.xs);
#endif

    if (durableXactions()) {
      addEventToLocalBuffer(xlc.lcbf,
			    -2,
			    XBEGIN_START);
    }

    xlc.currentXId = -1;
    while (xlc.currentXId == -1) {
      //      printf("TRying to get a transaction id here...\n");

      // This function grabs the global lock.
      xlc.currentXId = get_transaction_id(&xlc, is_query);
      //      printf("Got back %d\n", xlc.currentXId);
      
      if (xlc.currentXId == -1) {
	failCounter++;
	printf("Process %d stalled here %d time(s)... \n", getpid(), failCounter);
	usleep(100);
      }
    }

#ifdef GATHER_STATS
    xlc.xs.myId = xlc.currentXId;
#endif

#ifdef COUNT_STATS
    xlc.numXactions++;
#endif

    if (durableXactions()) {
      //      writeTaggedPageToLog(currentXC, &currentXC->xmdPtr, XBEGIN);
      assert(errno == 0);
    }

    if (durableXactions()) {
      addEventToLocalBuffer(xlc.lcbf,
			    xlc.currentXId,
			    XBEGIN_FINISH);
    }

  }
  else {
    if (xlc.isReadOnlyXaction  && (!is_query)) {
      fprintf(stderr, "ERROR! trying to nest xbegin() inside a readonly xaction.\n");
      assert(FALSE);
    }
  }
  xlc.xactionNestCounter++;
  return SUCCESS;
}


int xbegin(void) {
  return xbegin_helper(FALSE);
}

int xbeginQuery(void) {
  return xbegin_helper(TRUE);
}

// Ends a transaction.  Returns SUCCESS or
//  FAILURE
int xend() {
  int result = SUCCESS;
  int didCommit = FALSE;
  
  xlc.xactionNestCounter--;
  if (xlc.xactionNestCounter == 0) {

    if (durableXactions()) {
      addEventToLocalBuffer(xlc.lcbf,
			    xlc.currentXId,
			    XEND_START);
    }

    // Determine whether we commit or not.
    didCommit = xend_server_side_step1(&xlc);

    if (didCommit) {
      // Generate the log entry and write it to disk.
      xend_server_side_step2(&xlc);
    }
    else {
      result = FAILURE;
    }

    // Remove pages this transaction accessed from
    //  global table to stop conflicts.
    xend_server_side_step3(&xlc, didCommit);

#ifdef GATHER_STATS
    xlc.xs.commitStatus = didCommit;
#endif
    if (durableXactions()) {
      addEventToLocalBuffer(xlc.lcbf,
			    xlc.currentXId,
			    didCommit ? XCOMMIT_FIN : XABORT_FIN);
    }
  
    // Actually unmap pages...
    xend_server_side_step4(&xlc);

    // Finally, local cleanup...
    xlc.insideXaction = FALSE;
    DBPRINT(stderr, "Completed %d***********\n\n", xlc.currentXId);    
    xlc.currentXId = NULL_TRANS_ID;

#ifdef GATHER_STATS
    addStatToLocalBuffer(xlc.lcbf,
			 &xlc.xs);
#endif
    return result;
  }
  else {
    DBPRINT(stderr,
	   "Xend(). Transaction %d is now nested only %d deep.\n",
	   xlc.currentXId,
	   xlc.xactionNestCounter);
    return SUCCESS;
  }
}



int xendQuery(void) {
  int result = SUCCESS;
  
  xlc.xactionNestCounter--;
  if (xlc.xactionNestCounter == 0) {
    assert(xlc.isReadOnlyXaction);

    xendQuery_server_side_step1(&xlc);

    // Proces the unmap queue.
    xend_server_side_step4(&xlc);

    // Clear local state...
    xlc.insideXaction = FALSE;
    xlc.isReadOnlyXaction = FALSE;

    DBPRINT(stderr, "Completed %d***********\n\n", xlc.currentXId);
    xlc.currentXId = NULL_TRANS_ID;    
    return result;
  }
  else {
    DBPRINT(stderr,
	   "Xend(). Transaction %d is now nested only %d deep.\n",
	   xlc.currentXId,
	   xlc.xactionNestCounter);
    return SUCCESS;
  }
}



// Report all the local statistics collected for this process.
void reportStatsOnProcess() {
  int myPid = getpid();
  printf("Number of aborts on process %d: %d\n", myPid, xlc.numAborts);

//  printf("NUM_PAGE_PTRS_PER_PAGE is %d\n", PAGE_PTRS_PER_LOG_PAGE);
#ifdef DO_TIMINGS
  printf("On process %d, the timing results for sync.\n", myPid);
  reportTime("Sync time", xlc.syncTime, xlc.numSyncs);
  printf("The MAX SYNC TIME: %0.6f ms\n", xlc.maxSyncTime*1e3);
  printf("Number of lock acquisitions on %d: %d\n", myPid, xlc.numLocks);
  reportTime("Lock time", xlc.lockTime, xlc.numLocks);

  printf("On process %d, user file sync times.\n", myPid);
  reportTime("User sync", xlc.uSyncTime, xlc.numUSyncs);
  printf("THE MAX USER_SYNC time: %0.6f ms \n", xlc.maxUSyncTime*1e3);
  
  //  printf("Global report on glf lock:\n");
  //  reportTime("Log Manager lock", currentXC->glf->lockTime, currentXC->glf->numLocks);
  printf("Write time\n");
  reportTime("Write Time", xlc.mfd->writeTime, xlc.mfd->numWrites);

  reportTime("Time for page access", xlc.pageTime, xlc.numPageCounts);
  printf("Max write time: %0.6f us\n", xlc.maxWriteTime*1e6);

/*   reportTime("Other time", currentXC->otherTime, currentXC->numOthers); */
/*   printf("Max other time: %0.6f us\n", currentXC->maxOther*1e6); */
   reportTime("Other time", xlc.mfd->mfdOtherTime, xlc.mfd->mfdNumOthers); 
   printf("Max mfd other time: %0.6f us\n", xlc.mfd->mfdMaxTime*1e6); 
#endif

#ifdef COUNT_STATS
   printf("Number of transactions executed: %d\n", xlc.numXactions);
   printf("Total pages read: %d, avg is %0.6f\n", xlc.numPagesRead, xlc.numPagesRead*1.0/xlc.numXactions );
   printf("Total pages written: %d, avg is %0.6f\n", xlc.numPagesWritten, xlc.numPagesWritten*1.0/xlc.numXactions );
#endif
}


inline int durableXactions(void) {
  return xlc.isDurable;
}


void* regionAddr(void) {
  return xlc.mfd->theMmapRegion;
}


