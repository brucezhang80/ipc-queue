/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * cycle_counter.h
 *  
 *  Functions to call rdtsc.  So far, only x86 platforms supported.
 */

#ifndef __CYCLE_COUNTER_H
#define __CYCLE_COUNTER_H


#define ALF 1395013
#define PRUNELLA 2992576
#include <sys/time.h>

//  #define PERF_COUNTER_TIMERS

#ifdef PERF_COUNTER_TIMERS
#include "libperfctr.h"
typedef long long timeStruct;
#else


typedef struct timeval timeStruct;
//typedef long long timeStruct;
#endif


typedef unsigned long long rtimeStruct;

void setupTimers(void);


inline void checkTimer(timeStruct* tv);
inline void checkRealTimer(rtimeStruct* tv);

/**
 * Takes in two timeval structs and returns
 *  the time difference between them, in micro-seconds.
 */
double timeDiff(timeStruct tv0, timeStruct tv1);


/**
 * Takes in two timeval structs and returns
 *  the time difference between them, in micro-seconds.
 */
double rtimeDiff(rtimeStruct tv0, rtimeStruct tv1);

/**
 * Outputs the time taken and average time taken for a task to stdout.
 *   desc: the string description of the task
 *   time: how long the task took (in us)
 *   num:  how many times the task was repeated
 */
void reportTime(const char* desc, double runningTime, int num);


inline void checkCycleCount(rtimeStruct* tv);
unsigned long long clockTimeDiff(rtimeStruct tv0, rtimeStruct tv1);

void reportCycles(const char* desc, long long cycleCount, int num);
#endif
