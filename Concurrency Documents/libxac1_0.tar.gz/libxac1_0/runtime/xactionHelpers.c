/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * xactionHelpers.c
 *
 *
 *  Contains helper functions for our implementing our
 *   transactional system.
 *
 *  These functions all simultaneously manipulate
 *   the tree structure (xactionDepTree.h),
 *   the info structure (xactionInfo.h), and
 *   the mmap structure (xactionMmap.h)
 *
 */

#include "debugTools.h"
#include "xactionHelpers.h"
#include "xConflict.h"
#include "xDep.h"
#include "globalControl.h"
#include "logTester.h"

#include "xStats.h"

extern xactionContext* currentXC;



#ifdef XACTION_PRINT
#define DBPRINT fprintf
#define TREEPRINT outputDepTree
#else
#define DBPRINT emptyPrint
#define TREEPRINT emptyTreePrint
#endif


/**
 * Returns the id of the transaction who wrote the
 *  value of transaction page "pageNumber" that
 *  "currentXId" should see (or 0 if main memory
 *  has the last value.)
 *  This is the last ancestor in the tree that
 *   wrote to the page.
 */
int findLastWriter(int currentXId, int pageNumber) {
  int nextAncestor = currentXId;
  int foundWriter = FALSE;
  
  while (!foundWriter) {
    nextAncestor = getCommittedParent(currentXC->t, nextAncestor);

    foundWriter = ((nextAncestor == 0) ||
		   (pageStatusForXaction(currentXC, nextAncestor, pageNumber) == WRITING) ||
		   (pageStatusForXaction(currentXC, nextAncestor, pageNumber) == TRANSFER));
  }
  return nextAncestor;
}


/**
 * What to do when a transaction reads a page for the first time.
 *   This function also releases the global Cilk_lock
 */
void handlePageRead(xaction_local_context* xlc,
		    TID id,
		    int pageNumber,
		    int xactionIsStillPending,
		    int isReadOnly) {
  int lastWriter;
  //  checkTimer(&currentXC->pageT1);
  addToReadSet(currentXC, id, pageNumber);
  if ((xactionIsStillPending) && (!isReadOnly)) {
    addReaderForPage(currentXC, id, pageNumber);
  }

  // Figure out who we read the page from and
  //   increment. 
  lastWriter = findLastWriter(id, pageNumber);

  // readFrom call releases the global lock.   It must come last.
  readFrom(currentXC, xlc, lastWriter, pageNumber, TRUE);    
}



/**
 * What to do when a transaction writes to a page for the first time.
 *   This function also releases the global Cilk_lock
 */
void handlePageWrite(xaction_local_context* xlc,
		     TID id,
		     int pageNumber,
		     int xactionIsStillPending,
		     int hasBeenRead) {
  // Take it out of the read set and move it to the write set.
  if (hasBeenRead) {
    switchFromReadToWriteSet(currentXC, id, pageNumber);
  }
  else {
    int lastWriter;

    assert(verifyGlobalIsLocked(currentXC));
    lastWriter = findLastWriter(id, pageNumber);

    
    // read from the page without releasing a lock.
    readFrom(currentXC, xlc, lastWriter, pageNumber, FALSE);
    addToWriteSet(currentXC, id, pageNumber);
  }

  if (xactionIsStillPending) {
    if (hasBeenRead) {
      removeReaderForPage(currentXC, id, pageNumber);
    }
    addWriterForPage(currentXC, id, pageNumber);
  }


  assert(verifyGlobalIsLocked(currentXC));
  createPageRangeCopy(currentXC,
		      xlc,
		      (void*) (  (size_t)xlc->mfd->theMmapRegion+(size_t)pageNumber*PAGESIZE),
		      pageNumber,
		      1,
		      TRUE);
}







/* /\** */
/*  * Goes through the specified transaction and modifies the memory */
/*  *  map to unmap all the pages in the read and write set of the */
/*  *  transaction. */
/*  * */
/*  *  This function only queues up pages to be unmapped and  */
/*  *   modifies the global data structures.  The actual */
/*  *   calls to munmap/mmap must be done separately by */
/*  *   calling processUnmapQueue() */
/*  * */
/*  *  If isCommit is TRUE, then the behavior correspond to */
/*  *    a commit.  Otherwise, it is an abort.  The differences are: */
/*  * */
/*  *   1. On a commit, we also need to remove the pages in the read and write */
/*  *       set from the page->transaction array. */
/*  *      On an abort, we already removed these pages when we failed the transaction. */
/*  *   2. On an abort, we can automatically delete pages that we wrote to, */
/*  *        because we made our own copy that no one else should have touched. */
/*  *\/ */
/* static void unmapReadWriteSets(xactionContext* xc, int isCommit) { */
/*   int touchedPage; */
/*   int currentPtr; */

/*   currentPtr = firstReadSetIndex(xc, xc->currentXId); */
/*   while (!endOfReadSet(xc, xc->currentXId, currentPtr)) { */
/*     touchedPage = currentReadSetPage(xc, xc->currentXId, currentPtr); */
/*     currentPtr = nextReadSetIndex(xc, xc->currentXId, currentPtr); */
    
/*     if ((isCommit) && (!xc->isReadOnlyXaction)) { */
/*       removeReaderForPage(xc, xc->currentXId, touchedPage); */
/*     } */

/*     queuePageUnmap(xc, touchedPage, isCommit, FALSE); */



/*     //    queuePageUnmap(xc, touchedPage, FALSE); */
    
/*     clearPageStatusForXaction(xc, xc->currentXId, touchedPage); */
/* #ifdef COUNT_STATS */
/*     xc->numPagesRead++; */
/* #endif */
/*   } */

  
/*   currentPtr = firstWriteSetIndex(xc, xc->currentXId); */
/*   while (!endOfWriteSet(xc, xc->currentXId, currentPtr)) { */
/*     touchedPage = currentWriteSetPage(xc, xc->currentXId, currentPtr); */
/*     currentPtr = nextWriteSetIndex(xc, xc->currentXId, currentPtr); */

/* #ifdef COUNT_STATS */
/*     xc->numPagesWritten++; */
/* #endif */

/*     queuePageUnmap(xc, touchedPage, isCommit, TRUE); */
    
/*     if (isCommit) {       */
/*       DBPRINT(stderr, "unmapReadWriteSets tying to rmeove a write page %d\n", touchedPage);      */
/*       removeWriterForPage(xc, xc->currentXId, touchedPage); */
/*       //      queuePageUnmap(xc, touchedPage, TRUE, TRUE); */
/*     } */
/*     else { */
/*       //      queuePageUnmap(xc, touchedPage, FALSE, TRUE); */
/*       clearPageStatusForXaction(xc, xc->currentXId, touchedPage); */
/*     } */
/*   } */
/* } */




/**
 * Goes through the specified transaction and modifies the memory
 *  map to unmap all the pages in the read and write set of the
 *  transaction.
 *
 *  This function only queues up pages to be unmapped and 
 *   modifies the global data structures.  The actual
 *   calls to munmap/mmap must be done separately by
 *   calling processUnmapQueue()
 *
 *  If isCommit is TRUE, then the behavior correspond to
 *    a commit.  Otherwise, it is an abort.  The differences are:
 *
 *   1. On a commit, we also need to remove the pages in the read and write
 *       set from the page->transaction array.
 *      On an abort, we already removed these pages when we failed the transaction.
 *   2. On an abort, we can automatically delete pages that we wrote to,
 *        because we made our own copy that no one else should have touched.
 */
static void unmapReadSet(xactionContext* xc,
			 xaction_local_context* xlc, 
			 TID currentXId,
			 int isCommit) {
  int touchedPage;
  int currentPtr;

  currentPtr = firstReadSetIndex(xc, currentXId);
  while (!endOfReadSet(xc, currentXId, currentPtr)) {
    touchedPage = currentReadSetPage(xc, currentXId, currentPtr);
    currentPtr = nextReadSetIndex(xc, currentXId, currentPtr);
    
    if ((isCommit) && (!xlc->isReadOnlyXaction)) {
      removeReaderForPage(xc, currentXId, touchedPage);
    }

    queuePageUnmap(xc, xlc, touchedPage, isCommit, FALSE);



    //    queuePageUnmap(xc, touchedPage, FALSE);
    
    clearPageStatusForXaction(xc, currentXId, touchedPage);

#ifdef GATHER_STATS
    xlc->xs.pagesRead++;
#endif

#ifdef COUNT_STATS
    xlc->numPagesRead++;
#endif
  }
}




/**
 * Goes through the specified transaction and modifies the memory
 *  map to unmap all the pages in the read and write set of the
 *  transaction.
 *
 *  This function only queues up pages to be unmapped and 
 *   modifies the global data structures.  The actual
 *   calls to munmap/mmap must be done separately by
 *   calling processUnmapQueue()
 *
 *  If isCommit is TRUE, then the behavior correspond to
 *    a commit.  Otherwise, it is an abort.  The differences are:
 *
 *   1. On a commit, we also need to remove the pages in the read and write
 *       set from the page->transaction array.
 *      On an abort, we already removed these pages when we failed the transaction.
 *   2. On an abort, we can automatically delete pages that we wrote to,
 *        because we made our own copy that no one else should have touched.
 */
static void unmapWriteSet(xactionContext* xc,
			  xaction_local_context* xlc,
			  TID currentXId,
			  int isCommit) {
  int touchedPage;
  int currentPtr;

  currentPtr = firstWriteSetIndex(xc, currentXId);
  while (!endOfWriteSet(xc, currentXId, currentPtr)) {
    touchedPage = currentWriteSetPage(xc, currentXId, currentPtr);
    currentPtr = nextWriteSetIndex(xc, currentXId, currentPtr);

#ifdef GATHER_STATS
    xlc->xs.pagesWritten++;
#endif

#ifdef COUNT_STATS
    xlc->numPagesWritten++;
#endif

    queuePageUnmap(xc, xlc, touchedPage, isCommit, TRUE);
    
    if (isCommit) {      
      DBPRINT(stderr, "unmapWriteSet tying to rmeove a write page %d\n", touchedPage);     
      removeWriterForPage(xc, currentXId, touchedPage);
      //      queuePageUnmap(xc, touchedPage, TRUE, TRUE);
    }
    else {
      //      queuePageUnmap(xc, touchedPage, FALSE, TRUE);
      clearPageStatusForXaction(xc, currentXId, touchedPage);
    }
  }
}





// Merges the specified transaction into its
//  parent.
// If "force" is true, then garbage collection is run no matter what.
void garbageCollectTransactions(xaction_local_context* xlc, int force) {

  int currentId = 0;
  int i;

  int trashStack[MAX_XACTIONS];
  int trashCounter = 0;
  

  //    assert(!gbLockIsHeld(currentXC));
  //    acquireGbLock(currentXC);
  //  printf("BEGINNING WITH ONE GBCOLLECT!!!!!!!!!!\n");
  
  //  printf("Calling gbcollect on %d, tree is\n", getpid());
  //  printf("What is the last committed xaction? %d\n", lastCommittedXaction(currentXC->t));
  //  TREEPRINT(currentXC->t);





  assert(verifyGlobalIsLocked(currentXC));
  //  assert(getXactionStatus(currentXC, currentXC->currentXId) == COMMITTED_ON_DISK);
  // Our criteria for when we need to garbage collect...
  //  if ((numberOfFreeXactionIds(currentXC) < MAX_XACTIONS/2 + 1) || force) {
  if ((numberOfFreeXactionIds(currentXC) < 4) || force) {

    //    printf("Doing gbCollect on %d, tree is \n", getpid());
    //    outputDepTree(currentXC->t);
    TREEPRINT(currentXC->t);

    assert(verifyGlobalIsLocked(currentXC));
    while ((currentId != lastCommittedXaction(currentXC->t))){
      int nextMerge;
      //      printf("CurrentId is %d\n", currentId);
      //      outputDepTree(currentXC->t);

      if (!(currentXC->t->isCommitted[currentId])) {
	outputDepTree(currentXC->t);
	printf("Error on process %d, currentId == %d\n", getpid(), currentId);
	assert(verifyGlobalIsLocked(currentXC));
	assert(FALSE);
      }
      
      nextMerge = forwardActiveChildrenQuery(currentXC, currentId);
      //      printf("What did we get for nextMerge? %d\n", nextMerge);
      if (nextMerge == currentId) {
	int nextId;
	// If this condition is true, this means there is nothing to merge.
	//  Skip forward, see if we can find the next section to garbage collect.

	//	printf("Don't need to merge %d into %d\n", nextMerge, currentId);

	if (!currentXC->t->isCommitted[currentId]) {
	  outputDepTree(currentXC->t);
	  assert(FALSE);
	}
	
	nextId = getCommittedChild(currentXC->t, currentId);
	//	printf("Cycling to next current id is %d, ,curent is %d\n", nextId, currentId);
	if (!currentXC->t->isCommitted[currentId]) {
	  outputDepTree(currentXC->t);
	  assert(FALSE);
	}
	currentId = nextId;
	//	currentId = getCommittedChild(currentXC->t, currentId);
      }
      else {
	int currentPtr, currentWrittenPage;
	int backCounter = nextMerge;  
	// We are going to transfer pages backwards, from nextMerge to currentId,
	//   until all the pages are given to currentId.  Then it
	//   it is safe to merge the transactions in the trees together.

	//	printf("NextMerge here was %d, currentId was %d\n", nextMerge, currentId);

	while (backCounter != currentId) {
	  int parent = getCommittedParent(currentXC->t, backCounter);
	  xactionInfo* currentXaction = getXactionFromId(currentXC, backCounter);


	  //	  printf("Garbage collecting pages for %d, into parent %d\n", backCounter, parent);
	  assert(backCounter != 0);
	  //	  assert(currentXC->t->isCommitted[backCounter]);
	  //  	  assert(currentXC->t->isCommitted[currentId]);
	  
/* 	  if (!(getXactionStatus(currentXC, backCounter) == COMMITTED_ON_DISK)) { */
/* 	    printf("Error! the xaction status for transaction %d is something else...\n", backCounter); */
/* 	    printXactionStatus(getXactionStatus(currentXC, backCounter)); */
/* 	  } */
/* 	  assert(getXactionStatus(currentXC, backCounter) == COMMITTED_ON_DISK); */

	  // Go through write-set, transfer the pages to parent if necessary.
	  currentPtr = currentXaction->writeSetIndex;
	  while (currentPtr != NULL_INDEX) {
	    currentWrittenPage = currentXaction->pageSet[currentPtr];

	    if (currentWrittenPage == -1) {
	      printTransactionInfo(currentXC, backCounter);
	      if (parent != 0) printTransactionInfo(currentXC, parent);
	    }
	    if (parent == 0) {
	      //	      assert(getXactionStatus(currentXC, backCounter) == COMMITTED_ON_DISK);
	      replaceOriginalPageRange(currentXC,
				       xlc, 
				       backCounter, currentWrittenPage, 1);
	      clearPageStatusForXaction(currentXC, backCounter, currentWrittenPage);
	    }
	    else {
	      // Otherwise, if we merge into another committed transaction,
	      //  we just move ownership of that disk page to the parent.

	      // THis doesn't quite work because of pages that are read... they get turned
	      // into something...

	      int parentOwnedXaction;
	      //      	      assert(getXactionStatus(currentXC, backCounter) == COMMITTED_ON_DISK);
	      //	      assert(getXactionStatus(currentXC, parent) == COMMITTED_ON_DISK);
	      if (pageStatusForXaction(currentXC, parent, currentWrittenPage) == READING) {
		printf("BUG!!! in transferTo, transferrring page %d from %d back to %d, parent %d is reading page\n",
		       currentWrittenPage, backCounter, parent, parent);
	      }
	      parentOwnedXaction = givePageToOtherXaction(currentXC, backCounter, currentWrittenPage, parent);
	      //	      assert(pageStatusForXaction(currentXC, parent, currentWrittenPage) != READING);
	      transferTo(currentXC,
			 parent, backCounter, currentWrittenPage, parentOwnedXaction);
	    }
	    currentPtr = currentXaction->nextPage[currentWrittenPage];
	  }

	  // Keep track of the transactions we are going to have to delete at the end.
	  trashStack[trashCounter] = backCounter;
	  trashCounter++;

	  backCounter = parent;
	}

	// We finished with that section of the tree, fix the actual tree.
	//      printf("Tree before collapse:\n");
        TREEPRINT(currentXC->t);


	{
	  //	  int processNum = getpid();

	  //	  printf("Tree before collapse on process %d:\n", processNum);
	  //	  outputDepTree(currentXC->t);
	  
	  // Collapse the tree
	  collapseRangeBackward(currentXC, nextMerge);
	
	  //     printf("Tree after collapse:\n");	
	  TREEPRINT(currentXC->t);

	  //	  printf("Tree after collapse on process %d:\n", processNum);
	  //	  outputDepTree(currentXC->t);
	  //	  printf("What is currentId after the collapse? %d\n",  currentId);
	}
      }
    }


    i = 0;
    while (i < trashCounter) {
      // Get rid of transaction information.  This frees the transaction id.
      //    printf("Deleting transaction info for %d\n", trashStack[i]);

      if (!(getXactionStatus(currentXC, trashStack[i]) == COMMITTED_ON_DISK)) {
	printf("ERROR!!! Deleting info for transaction %d even though it is not committed on disk yet.\n",
	       trashStack[i]);
	outputDepTree(currentXC->t);
	sleep(1000);
	assert(FALSE);
      }

      //      printf("TStack element %d is deleting..\n", trashStack[i]);
      deleteTransactionInfo(currentXC, trashStack[i]);
      i++;
    }

    DBPRINT(stderr, "After the gbcollect:\n");    
    TREEPRINT(currentXC->t);
  }
  else {
    DBPRINT(stderr, "Don't need to gbCollect. Number of free ids is still %d\n", numberOfFreeXactionIds(currentXC));
  }

  //  assert(gbLockIsHeld(currentXC));
  //  printf("FINISHED WITH ONE GBCOLLECT!!!!!!!!!!\n");
  //  releaseGbLock(currentXC);

}





//  Does the final garbage collection at the end of the program.
//   Only one process should actually call this function.
void finalGarbageCollectTransactions(xaction_local_context* xlc) {
//  printf("Calling Final gbcollect on %d, tree is\n", getpid());
  // First do a normal gb collection.
  acquireGlobalLock(currentXC);
  garbageCollectTransactions(xlc, TRUE);
  releaseGlobalLock(currentXC);
}






// This function generates the log entry page on a transaction commit.
//  It should be called before the read/write sets for this transaction
//  have been cleared.

// Should not need to hold the lock during this operation, because
//  the read/write set of this transaction should not be changing??

void generateLogEntryForCommit(xactionContext* xc,
			       xaction_local_context* xlc,
			       TID currentXId, int isDurable) {
  int currentPtr, touchedPage;

//  int numPagesWritten = 0;


      assert(getLocalBufferLength(xlc->lcbf) == 0);
      if (isDurable) {
	  storeTagToBuffer(xc, xlc->lcbf,
			   XCOMMIT_START,
			   getXactionFromId(xc, currentXId)->timeStamp,
			   xc->myLSN);
      }

      currentPtr = firstWriteSetIndex(xc, currentXId);
      while (!endOfWriteSet(xc, currentXId, currentPtr)) {
	  touchedPage = currentWriteSetPage(xc, currentXId, currentPtr);
	  currentPtr = nextWriteSetIndex(xc, currentXId, currentPtr);

	  if (isDurable) {
	      //    printf("About to call storePageDiff on page %d\n", touchedPage);

	      if (!xc->logTestModeOn) {
		storePageDiff(xlc,
			      xlc->lcbf, touchedPage);
	      }
	      else {
		  char buffer[DEFAULT_TEST_BUFFER_SIZE];
		  size_t entryLength;

		  entryLength = generateLogEntry(buffer, DEFAULT_TEST_BUFFER_SIZE, currentXId);
		  addDataToLocalBuffer(xlc->lcbf, buffer, entryLength);
	      }
	  }
	  // Remove that page from the readSourceTable.

	  acquireLogManagerLock(xc->glf);
	  clearSourcePage(xc, xlc, touchedPage);
	  releaseLogManagerLock(xc->glf);

//    numPagesWritten++;
      }  


//  if (numPagesWritten > 8) {
//      printf("Process %d writing %d pages...\n", getpid(), numPagesWritten);    
//  }
      if (isDurable) {
	  storeTagToBuffer(xc, xlc->lcbf, XCOMMIT_FINISH,
			   getXactionFromId(xc, currentXId)->timeStamp,
			   xc->myLSN);
      }
}


void xactionCommitHelper(xactionContext* xc,
			 xaction_local_context* xlc,
			 TID id) {
  int previousLastCommitted;
  assert(getXactionStatus(xc, id) == PENDING);
  // At this point, we can commit.
  setXactionStatus(xc, id, COMMITTED);

#ifdef USE_LSN
  // This function acquires the LSN lock,
  //  and sets the  LSN for this process.
  getNextLSN(xc);
#endif
  
  assert(getXactionStatus(xc, id) == COMMITTED);
  //  unmapReadWriteSets(currentXC, TRUE);
  unmapReadSet(xc, xlc, id, TRUE);

#ifdef DO_EARLY_RELEASE_ON_WRITES
  // This is wrong here. but let's try. :)
  unmapWriteSet(xc, xlc, id, TRUE);
//  End of wrong section.
#endif

  previousLastCommitted = lastCommittedXaction(xc->t);  
  commitXaction(xc->t, id);
  movePendingListToEnd(xc->t, previousLastCommitted);  
}

void xactionAbortHelper(xactionContext* xc,
			xaction_local_context* xlc,
			TID id) {  
  if (getXactionStatus(xc, id) != FAILED) {
    printf("bad! transaction %d does not have status failed. \n", id);
    printTransactionInfo(xc, id);
    sleep(1000);
  }
  assert(getXactionStatus(xc, id)== FAILED);

  setXactionStatus(xc, id, ABORTED);
  //  unmapReadWriteSets(xc, FALSE);
  unmapReadSet(xc, xlc, id,  FALSE);
  unmapWriteSet(xc, xlc, id, FALSE);
  
  // Delete this transaction's info
  abortXaction(xc->t, id);
}

void handleXactionCommitStage3(xaction_local_context* xlc,
			       TID id) {
  //  unmapReadWriteSets(currentXC, TRUE);
#ifndef DO_EARLY_RELEASE_ON_WRITES
    // Release it now if we didn't before.
  unmapWriteSet(currentXC, xlc, id, TRUE);
#endif

    setXactionStatus(currentXC, id, COMMITTED_ON_DISK);
}


void xactionCommitReadOnlyHelper(xaction_local_context* xlc) {  
  int id = xlc->currentXId;  
  assert(getXactionStatus(currentXC, id) == PENDING);
  
  // At this point, we can commit.
  setXactionStatus(currentXC, id, COMMITTED_ON_DISK);  
  //  unmapReadWriteSets(currentXC, TRUE);

  unmapReadSet(currentXC, xlc, id,  TRUE);
  commitReadOnly(currentXC->t, id);
}


/* void handleXactionCommit(xaction_local_context* xlc __attribute__((__unused__)), */
/* 			 TID id, */
/* 			 int isDurable __attribute__((__unused__))) {   */
/*   assert(getXactionStatus(currentXC, id) == PENDING); */
/*   // At this point, we can commit. */
/*   setXactionStatus(currentXC, id, COMMITTED); */

/* #ifdef USE_LSN */
/*   // This function acquires the LSN lock, */
/*   //  and sets the  LSN for this process. */
/*   getNextLSN(currentXC); */
/* #endif */
/* } */

/* void handleXactionCommitStage2(xaction_local_context* xlc, */
/* 			       TID id) { */
/*   int previousLastCommitted;    */
/*   assert(getXactionStatus(currentXC, id) == COMMITTED); */
/*   //  unmapReadWriteSets(currentXC, TRUE); */
/*   unmapReadSet(currentXC, xlc, id, TRUE); */

/* #ifdef DO_EARLY_RELEASE_ON_WRITES */
/*   // This is wrong here. but let's try. :) */
/*   unmapWriteSet(currentXC, xlc, id, TRUE); */
/* //  End of wrong section. */
/* #endif */

/*   previousLastCommitted = lastCommittedXaction(currentXC->t);   */
/*   commitXaction(currentXC->t, id); */
/*   movePendingListToEnd(currentXC->t, previousLastCommitted);  */
/* } */





/* void handleXactionAbort(xaction_local_context* xlc, */
/* 			TID id, */
/* 			int isDurable) { */

/*   if (getXactionStatus(currentXC, id) != FAILED) { */
/*     printf("bad! transaction %d does not have status failed. \n", id); */
/*     printTransactionInfo(currentXC, id); */
/*     sleep(1000); */
/*   } */
/*   assert(getXactionStatus(currentXC, id)== FAILED); */

  
/*   setXactionStatus(currentXC, id, ABORTED); */
/*   //  unmapReadWriteSets(currentXC, FALSE); */
/*   unmapReadSet(currentXC, xlc, id,  FALSE); */
/*   unmapWriteSet(currentXC, xlc, id, FALSE); */
  
/*   // Delete this transaction's info */
/*   abortXaction(currentXC->t, id); */

/*   //  releaseGlobalLock(currentXC); */
/*   //  Cilk_unlock(*(currentXC->xactionGlobal)); */
/*   if (isDurable) { */
/*     //    writeTaggedPageToLog(currentXC, &currentXC->xmdPtr, XABORT); */
/*   } */

/*   xlc->numAborts++; */
/* } */

