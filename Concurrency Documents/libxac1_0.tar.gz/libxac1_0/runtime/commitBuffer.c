/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * commitBuffer.c
 */

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>


#include "basics.h"
#include "cycle_counter.h"
#include "commitBuffer.h"

#ifdef GATHER_STATS

static void printOutAllStats(xactionStats* allStats,
			     int numStats, int mypid);

#endif

// #define PERFORM_EVENT_LOGGING
//#define TIME_PRIMARY_BUFFER_LOCK
//#define TIME_SECONDARY_BUFFER_LOCK

char emptyArray[PAGESIZE];


static void printEventKeyHelper(FILE* f, eventType e) {

    char tempString[100];

    switch (e) {
	case EMPTY_EVENT:
	    strncpy(tempString, "EMPTY_EVENT", 100);
	    break;
	case XBEGIN_START:
	    strncpy(tempString, "XBEGIN_START", 100);
	    break;
	case XBEGIN_FINISH:
	    strncpy(tempString, "XBEGIN_FINISH", 100);
	    break;
	case XEND_START:
	    strncpy(tempString, "XEND_START", 100);
	    break;
	case XCOMMIT_FIN:
	    strncpy(tempString, "XCOMMIT_FIN", 100);
	    break;
	case XABORT_FIN:
	    strncpy(tempString, "XABORT_FIN", 100);
	    break;
	case LOC_BEFORE_MMAP_READ:
	    strncpy(tempString, "LOC_BEFORE_MMAP_READ", 100);	    
	    break;
	case LOC_AFTER_MMAP_READ:
	    strncpy(tempString, "LOC_AFTER_MMAP_READ", 100);	    
	    break;
	case LOC_BEFORE_MMAP_WRITE:
	    strncpy(tempString, "LOC_BEFORE_MMAP_WRITE", 100);	    
	    break;
	case LOC_AFTER_MMAP_WRITE:
	    strncpy(tempString, "LOC_AFTER_MMAP_WRITE", 100);
	    break;
	case LOC_BEFORE_MMAP_NONE:
 	    strncpy(tempString, "LOC_BEFORE_MMAP_NONE", 100);
	    break;
	case LOC_AFTER_MMAP_NONE:
 	    strncpy(tempString, "LOC_AFTER_MMAP_NONE", 100);
	    break;
	case LOC_BEFORE_MMAP_IN_DIFF:
 	    strncpy(tempString, "LOC_BEFORE_MMAP_IN_DIFF", 100);
	    break;
	case LOC_AFTER_MMAP_IN_DIFF:
	    strncpy(tempString, "LOC_AFTER_MMAP_IN_DIFF", 100);
	    break;
	case LOC_BEFORE_WRITE:
	    strncpy(tempString, "LOC_BEFORE_WRITE", 100);
	    break;
	case LOC_AFTER_WRITE:
	    strncpy(tempString, "LOC_AFTER_WRITE", 100);
	    break;
	case LOC_BEFORE_SYNC:
	    strncpy(tempString, "LOC_BEFORE_SYNC", 100);
	    break;
	case LOC_AFTER_SYNC:
	    strncpy(tempString, "LOC_AFTER_SYNC", 100);
	    break;
	case SYNC_SCHED_BEGIN: 
	    strncpy(tempString, "SYNC_SCHED_BEGIN", 100);
	    break;
	case SYNC_DONE: 
	    strncpy(tempString, "SYNC_SCHED_DONE", 100);
	    break;
	case LAST_NULL_EVENT:
	    strncpy(tempString, "LAST_NULL_EVENT", 100);
	    break;

	default:
	    strncpy(tempString, "INVALID", 100);
    }

    fprintf(f, "%s = %d;  ", tempString, e);    
}

void printEventKey(FILE* f) {
    int i = EMPTY_EVENT;

    for (i = EMPTY_EVENT; i < LAST_NULL_EVENT; i++) {
	printEventKeyHelper(f, i);
	fprintf(f, "\n");
    }
}

//  This method is duplicated from simpleLogFileManager.c
/**
 * Adds pages to the specified file until the length is at least
 *  numPages.
 * Returns the final length of the file, in pages.
 */
static int extendFileToSpecifiedLength(int fd, int numPages) {
  int fileSize, additionalSize;
  fileSize = lseek(fd, (off_t)0, SEEK_END);

  if (fileSize == -1) {
    perror("Can not seek to end of file.");
    assert(FALSE);
  }
  
  additionalSize = numPages - fileSize/PAGESIZE;
  if (additionalSize > 0) {
    // We need to add pages
    int count;
    for (count = 0; count < additionalSize; count++) {
      write(fd, (void*) &emptyArray, (size_t)PAGESIZE);
    }
    return numPages;
  }
  else {
    return fileSize/PAGESIZE + 1*(fileSize%PAGESIZE != 0);
  }
}



// Assumes memory has been allocated for gcbf
void initGlobalBuffer(globalCommitBuffer* gcbf, const char* path, int bufferNum) {
  int fd, error;

  memset(&emptyArray,0,  PAGESIZE);

  gcbf->bufferNumber = bufferNum;
  gcbf->maxLength = ((long)MAX_GLOBAL_BUFFER*PAGESIZE);
  assert(gcbf->maxLength > 0);
  gcbf->length = 0;

  
  // Initialize the locks
  Cilk_lock_init(gcbf->primaryBufferLock);
  Cilk_lock_init(gcbf->primaryMetaBufferLock);
  gcbf->primaryBufferLockHeld = FALSE;

  Cilk_lock_init(gcbf->secondaryBufferLock);
  memset(&(gcbf->xQueueWaiting), 0, sizeof(int)*(MAX_XACTIONS+1));  
  memset(&(gcbf->xQueueRunning), 0, sizeof(int)*(MAX_XACTIONS+1));




  assert(errno == 0);
  gettimeofday(&gcbf->lastSyncTime, NULL);
  assert(errno == 0);

  if (path != NULL) {
    snprintf(gcbf->bufferName, BUFFER_FILE_NAME_SIZE-1,
	     "%s/LbxcComBuffer%d",
	     path, 
	     bufferNum);	     
  }
  else {
    snprintf(gcbf->bufferName, BUFFER_FILE_NAME_SIZE-1,
	     "xDefaultComBuffer%d.log",
	     bufferNum);    
  }

  fd = open(gcbf->bufferName, O_RDWR | O_CREAT, 0666);
  assert(fd != -1);
  extendFileToSpecifiedLength(fd, gcbf->maxLength/PAGESIZE);
  error = close(fd);
  assert(error == 0);  
}

// Initializies the local commit buffer, and
//  links it to the global buffer
localCommitBuffer* createLocalCommitBuffer(globalCommitBuffer* gcbf) {

  localCommitBuffer* lcbf = (localCommitBuffer*)malloc(sizeof(localCommitBuffer));
  assert (lcbf != NULL);

  lcbf->commitBufferFd = open(gcbf->bufferName, O_RDWR, 0666);
  assert(lcbf->commitBufferFd !=-1);

  lcbf->localMmapLength = gcbf->maxLength / PAGESIZE;
  assert(lcbf->localMmapLength > 0);
  
  lcbf->commitBufferRegion = mmap(0,
				  (size_t)(PAGESIZE * lcbf->localMmapLength),
				  PROT_READ | PROT_WRITE,
				  MAP_SHARED,
				  lcbf->commitBufferFd,
				  0);
  assert((ssize_t)lcbf->commitBufferRegion != -1);
  //  lcbf->globalBufferLock = &(gcbf->actualBufferLock);

  // Initialize the local buffer structure
  lcbf->currentLength = 0;
  lcbf->currentMax = MAX_LOCAL_BUFFER;
  lcbf->buffer = malloc(lcbf->currentMax);
  assert((ssize_t)(lcbf->buffer) != -1);


  lcbf->numEventsRecorded = 0;
  lcbf->eventBufferSize = DEFAULT_NUM_EVENTS;
  lcbf->allEvents = (eventRecord*)malloc(DEFAULT_NUM_EVENTS * sizeof(eventRecord));
  
#ifdef GATHER_STATS
  lcbf->numStatsRecorded = 0;
  lcbf->statBufferSize = DEFAULT_NUM_EVENTS;
  lcbf->allStats = (xactionStats*)malloc(DEFAULT_NUM_EVENTS * sizeof(xactionStats));
#endif

/*   if (errno != 0) { */
/*     perror("Why??"); */
/*     assert(FALSE); */
/*   } */
  
  return lcbf;  
}


#ifdef TIME_SECONDARY_BUFFER_LOCK
int numLockAcquires = 0;
long long totalLockTime = 0;
#endif

#ifdef TIME_PRIMARY_BUFFER_LOCK
int numPrimaryLocks = 0;
long long primaryLockTime = 0;
#endif


char eventLogNamePrefix[100] = "eventLog";


void setEventLogName(char* newName) {
    strncpy(eventLogNamePrefix, newName, 100);
}

#ifdef PERFORM_EVENT_LOGGING
static void printOutAllEvents(eventRecord* allEvents,
			      int numEvents, int mypid) {
    int i;
    char fileName[100];
    FILE* f;

    snprintf(fileName, 100, "%s%d.elg", eventLogNamePrefix, mypid);
    
    f = fopen(fileName, "w+");

//    fprintf(f, "###   EVENT LOG FOR PROCESS %d\n\n", mypid);
//    printEventKey(f);
    fprintf(f, "\n\n\n");
    assert(f != NULL);
    for (i = 0; i < numEvents; i++) {
	fprintf(f, "%5d   %3d   %3d  %llu;\n",
		mypid,
		allEvents[i].xId,
		allEvents[i].etType,
		allEvents[i].ts);
    }
    fclose(f);    
}
#endif


#ifdef PERFORM_EVENT_LOGGING

void addEventToLocalBuffer(localCommitBuffer* lcbf,
			   int myXid,
			   eventType e) {

    int newSize = lcbf->eventBufferSize;
    eventRecord* newBuffer;
    eventRecord newE;


    // Double the buffer size if we dont' have space.
    if (lcbf->numEventsRecorded + 1 >= newSize) {

//	printf("Doublign the buffer to size %d\n", newSize);
	newSize *= 2;

	newBuffer = malloc(newSize* (sizeof(eventRecord)));
//	printf("finished malloc the buffer to size %d\n", newSize);
	assert((ssize_t)newBuffer != -1);

	memcpy(newBuffer, lcbf->allEvents,
	       lcbf->numEventsRecorded*sizeof(eventRecord));

	free(lcbf->allEvents);
	lcbf->allEvents = newBuffer;
	lcbf->eventBufferSize = newSize;		
    }

    assert(lcbf->numEventsRecorded + 1 < lcbf->eventBufferSize);

    // Create new event and add it.
    newE.xId = myXid;
    newE.etType = e;
    checkCycleCount(&newE.ts);
    lcbf->allEvents[lcbf->numEventsRecorded] = newE;

//    printf("I just added an event? what was it? %d = ",	   e);
//    printEventKeyHelper(stdout, e);
//    printf("\n\n");
	   
    lcbf->numEventsRecorded++;
}
#else


void addEventToLocalBuffer(localCommitBuffer* lcbf __attribute__((__unused__)), 
			   int myXid __attribute__((__unused__)),
			   eventType e __attribute__((__unused__))) {

}

#endif


void destroyLocalCommitBuffer(localCommitBuffer* lcbf) {
  int error;
  assert((ssize_t)(lcbf->commitBufferRegion) != -1);

  error = munmap(lcbf->commitBufferRegion,
		 (size_t)(PAGESIZE*lcbf->localMmapLength));
  assert(error == 0);

  error = close(lcbf->commitBufferFd);
  assert(error == 0);

#ifdef TIME_SECONDARY_BUFFER_LOCK
  printf("***** TOTAL LOCK TIME ON PROCESS %d:  %0.6f clockCycles per insert, or %0.6f ms per acquire.\n",
	 getpid(),
	 1.0*totalLockTime/ numLockAcquires,
	 (1e3 *totalLockTime / numLockAcquires) / (1.4*1e9));
#endif

#ifdef TIME_PRIMARY_BUFFER_LOCK
  printf("***** TOTAL PRIMARY META LOCK TIME ON PROCESS %d:  %0.6f clockCycles per insert, or %0.6f ms per acquire.\n",
	 getpid(),
	 1.0*primaryLockTime/ numPrimaryLocks,
	 (1e3 *primaryLockTime / numPrimaryLocks) / (1.4*1e9));
#endif

#ifdef PERFORM_EVENT_LOGGING
  printOutAllEvents(lcbf->allEvents, lcbf->numEventsRecorded, getpid());
#endif
  free(lcbf->allEvents);
  
#ifdef GATHER_STATS
  printOutAllStats(lcbf->allStats, lcbf->numStatsRecorded, getpid());
  free(lcbf->allStats);
#endif

  free(lcbf->buffer);  
  free(lcbf);
}


void addDataToLocalBuffer(localCommitBuffer* lcbf, void* data, size_t numBytes) {

  size_t newSize = lcbf->currentMax;

  // Double the buffer size until it is big enough.
  while (lcbf->currentLength + numBytes > newSize) {
    newSize *= 2;
  }  
  // Create a bigger buffer if necessary
  if (newSize > lcbf->currentMax) { 
    void* newBuffer = malloc(newSize);
    assert((ssize_t)newBuffer != -1);
    memcpy(newBuffer, lcbf->buffer, lcbf->currentLength);
    
    free(lcbf->buffer);
    lcbf->buffer = newBuffer;
    lcbf->currentMax = newSize;
  }

  
  assert(lcbf->currentLength + numBytes <= lcbf->currentMax);
  

  memcpy((void*)((size_t)lcbf->buffer + lcbf->currentLength),
	 data,
	 numBytes);

  lcbf->currentLength += numBytes;
}
void* getLocalBufferPointer(localCommitBuffer* lcbf) {
  return lcbf->buffer;
}
int getLocalBufferLength(localCommitBuffer* lcbf) {
  return lcbf->currentLength;
}

void clearLocalBuffer(localCommitBuffer* lcbf) {
  lcbf->currentLength = 0;
}



inline int tryToAcquirePrimaryBufferLock(globalCommitBuffer* gcbf __attribute__((__unused__))) {
  int gotIt = FALSE;

#ifdef TIME_PRIMARY_BUFFER_LOCK
  rtimeStruct t0, t1;
  checkCycleCount(&t0);
#endif

  Cilk_lock((gcbf->primaryMetaBufferLock));

#ifdef TIME_PRIMARY_BUFFER_LOCK
  checkCycleCount(&t1);
#endif

  if (!gcbf->primaryBufferLockHeld) {
    gcbf->primaryBufferLockHeld = TRUE;
    Cilk_lock((gcbf->primaryBufferLock));
    gotIt = TRUE;
  }
  Cilk_unlock((gcbf->primaryMetaBufferLock));



#ifdef TIME_PRIMARY_BUFFER_LOCK
  numPrimaryLocks++;
  primaryLockTime += clockTimeDiff(t0, t1);
#endif
  
  return gotIt;  
  //  assert(errno == 0);
}


inline void acquirePrimaryBufferLock(globalCommitBuffer* gcbf ) {

  int gotIt = FALSE;
  while (!gotIt) {
    Cilk_lock((gcbf->primaryMetaBufferLock));
    if (!gcbf->primaryBufferLockHeld) {
      gcbf->primaryBufferLockHeld = TRUE;
      Cilk_lock((gcbf->primaryBufferLock));
      gotIt = TRUE;
    }
    Cilk_unlock((gcbf->primaryMetaBufferLock));
  }

  //  assert(errno == 0);
}


inline void releasePrimaryBufferLock(globalCommitBuffer* gcbf ) {
  Cilk_lock((gcbf->primaryMetaBufferLock));
  assert(gcbf->primaryBufferLockHeld);

  gcbf->primaryBufferLockHeld = FALSE;
  Cilk_unlock(gcbf->primaryBufferLock);

  Cilk_unlock((gcbf->primaryMetaBufferLock));
}



inline void acquireSecondaryBufferLock(globalCommitBuffer* gcbf) {
#ifdef TIME_SECONDARY_BUFFER_LOCK
    rtimeStruct t0, t1;
    checkCycleCount(&t0);
#endif

    Cilk_lock(gcbf->secondaryBufferLock);

#ifdef TIME_SECONDARY_BUFFER_LOCK
    checkCycleCount(&t1);
    numLockAcquires++;
    totalLockTime += clockTimeDiff(t0, t1);
#endif
}

inline void releaseSecondaryBufferLock(globalCommitBuffer* gcbf) {
  Cilk_unlock(gcbf->secondaryBufferLock);
}

// Still confused about this... 
void emptyLocalIntoGlobalBuffer(localCommitBuffer* lcbf,
				globalCommitBuffer* gcbf) {

  assert(errno == 0);

  //  acquirePrimaryBufferLock(gcbf);
  if (lcbf->currentLength + gcbf->length > gcbf->maxLength) {
    printf("ERROR FOR NOW! Overflowing global buffer file... \n");
    printf("What is local length? %zd.  Global length? %zd, Global max length? %zd\n",
	   lcbf->currentLength, gcbf->length, gcbf->maxLength);
    assert(FALSE);
  }

  // Copy one buffer into the other, and empty the 
  //  local buffer
  memcpy((void*)((size_t)lcbf->commitBufferRegion + gcbf->length),
	 lcbf->buffer,
	 lcbf->currentLength);

  gcbf->length += lcbf->currentLength;
  lcbf->currentLength = 0;
	   
  //  releasePrimaryBufferLock(gcbf);
}

void clearGlobalBuffer(localCommitBuffer* lcbf __attribute__((__unused__)),
		       globalCommitBuffer* gcbf) {

  //  acquirePrimaryBufferLock(gcbf);
  gcbf->length = 0;
  //  releasePrimaryBufferLock(gcbf);
  assert(errno == 0);
}



int addIdToWaitersList(globalCommitBuffer* gcbf,
		       int myId) {
/*     int i; */
/*     int numWaiters = 0; */
/*     int numRunners = 0; */

    assert((myId > 0) &&( myId <= MAX_XACTIONS));

/*     for (i = 0; i <= MAX_XACTIONS; i++) { */
/* 	numWaiters += gcbf->xQueueWaiting[i]; */
/* 	numRunners += gcbf->xQueueRunning[i]; */
/*     } */

    if (gcbf->xQueueWaiting[myId]) {
	printf("ERROR! why is id = %d waiting? \n", myId);
	printAllWaiters(gcbf);
    }
    assert(gcbf->xQueueWaiting[myId] == FALSE);
/*     if (numWaiters + numRunners > 2) { */
/* 	printf("Here for id %d, we have %d waiters and %d runners\n", */
/* 	       myId, numWaiters, numRunners); */
/*     } */

    gcbf->xQueueWaiting[myId] = TRUE;
    return 0;
}


int stillWaiting(globalCommitBuffer* gcbf, int myId) {
  assert((myId > 0) &&( myId <= MAX_XACTIONS));
  return ((gcbf->xQueueWaiting[myId]));
}

int stillWaitingOrRunning(globalCommitBuffer* gcbf,
			  int myId) {
  assert((myId > 0) &&( myId <= MAX_XACTIONS));

  return ((gcbf->xQueueWaiting[myId]) ||
	  (gcbf->xQueueRunning[myId]));
  
}
int stillRunning(globalCommitBuffer* gcbf,
		 int myId) {
  assert((myId > 0) &&( myId <= MAX_XACTIONS));
  return  gcbf->xQueueRunning[myId];
}

void changeStatusOnWaitersToStarted(globalCommitBuffer* gcbf,
				    localCommitBuffer* lcbf __attribute__((__unused__))) {

  //  int i;
/*   int numWaiters = 0; */
/*   int numRunners = 0; */
/*   int newWaiters = 0; */
/*   int newRunners = 0; */
  
/*   for (i = 0; i < MAX_XACTIONS+1; i++) { */
/*     if (gcbf->xQueueWaiting[i]) numWaiters++; */
/*     if (gcbf->xQueueRunning[i]) numRunners++; */
/*   } */

/*   if (numRunners > 0) { */
/*     printf("ERROR!! Why do we have runners when changing waiters to started...\n"); */
/*     printAllWaiters(gcbf); */
/*   } */
  memcpy((void*)gcbf->xQueueRunning, (void*)gcbf->xQueueWaiting, (sizeof(int)*(MAX_XACTIONS+1)));
  memset(gcbf->xQueueWaiting, 0, (sizeof(int)*(MAX_XACTIONS+1)));


/*   for (i = 0; i < MAX_XACTIONS+1; i++) { */
/*     if (gcbf->xQueueWaiting[i]) newWaiters++; */
/*     if (gcbf->xQueueRunning[i]) newRunners++; */
/*   } */
/*   assert(newRunners == numWaiters); */
/*   assert(newWaiters == 0); */

}


int clearAllRunningIds(globalCommitBuffer* gcbf,
		       localCommitBuffer* lcbf __attribute__((__unused__))) {

    int num = -3;

#ifdef GATHER_STATS
    int i;
    num = 0;
    for (i = 0; i < MAX_XACTIONS+1; i++) {
	if (gcbf->xQueueRunning[i]) num++;
    }
#endif
    
    memset(gcbf->xQueueRunning, 0, (sizeof(int)*(MAX_XACTIONS+1)));
    return num;
}

void printAllWaiters(globalCommitBuffer* gcbf) {
  int i = 0;
  printf("Waiting: ");
  for (i = 0; i <= MAX_XACTIONS; i++) {
    printf("%d = %d,  ", i, gcbf->xQueueWaiting[i]);
  }
  printf("\n");

  printf("Running: ");
  for (i = 0; i <= MAX_XACTIONS; i++) {
    printf("%d = %d,  ", i, gcbf->xQueueRunning[i]);
  }
  printf("\n");
}




#ifdef GATHER_STATS

void addStatToLocalBuffer(localCommitBuffer* lcbf,
			  xactionStats* xs) {
    
    int newSize = lcbf->statBufferSize;
    xactionStats* newBuffer;


    // Double the buffer size if we dont' have space.
    if (lcbf->numStatsRecorded + 1 >= newSize) {

//	printf("Doublign the buffer to size %d\n", newSize);
	newSize *= 2;

	newBuffer = malloc(newSize* (sizeof(xactionStats)));
//	printf("finished malloc the buffer to size %d\n", newSize);
	assert((ssize_t)newBuffer != -1);

	memcpy(newBuffer, lcbf->allStats,
	       lcbf->numStatsRecorded*sizeof(xactionStats));

	free(lcbf->allStats);
	lcbf->allStats = newBuffer;
	lcbf->statBufferSize = newSize;		
    }

    assert(lcbf->numStatsRecorded + 1 < lcbf->statBufferSize);

    lcbf->allStats[lcbf->numStatsRecorded] = *xs;
    
//    printf("I just added an event? what was it? %d = ",	   e);
//    printEventKeyHelper(stdout, e);
//    printf("\n\n");
    lcbf->numStatsRecorded++;
}



char statLogNamePrefix[100] = "statLog";

void setStatLogName(char* newName) {
    strncpy(statLogNamePrefix, newName, 100);
}


static void printOutAllStats(xactionStats* allStats,
			     int numStats, int mypid) {
    int i;
    char fileName[100];
    FILE* f;

    snprintf(fileName, 100, "%s%d.elg", statLogNamePrefix, mypid);
    f = fopen(fileName, "w+");


    fprintf(f, "###   Stat LOG FOR PROCESS %d\n\n", mypid);
//    printEventKey(f);
    printXStatsKey(f);

    fprintf(f, "\n\n\n");
    assert(f != NULL);

    for (i = 0; i < numStats; i++) {
	printXStats(f, mypid, &allStats[i]);
    }
    fclose(f);    
}


#endif
