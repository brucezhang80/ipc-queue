/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * libxac.h
 *
 *  The main header file that Libxac users should include.
 */



#ifndef __LIBXAC_H
#define __LIBXAC_H

#include "basics.h"


#define DO_PAGE_ACCESS
#define IS_DURABLE FALSE


// Old interface... 
void* setupXactionSystem(int isDurable);
int cleanupXactionSystem(void);


/**
 *  xInit and xShutdown should only be called once,
 *    on a single process.
 */

/**
 * Sets up a control file and other
 *  global data structures for handling transactions
 *  on the specified file.
 *  
 * path is the directory where all the generated files (including
 *   commit file) is stored. 
 * isDurable == TRUE specifies that all transactions should be
 *   durable.
 */
int xInit(const char* path, int isDurable);
void xShutdown(void);


// These functions should be called once on every process.
void* xMmap(const char* userFileName, int numPages);
void xMunmap(const char* userFileName);

// Begins a transaction.  Returns SUCCESS
//  or FAILURE
int xbegin(void);

// Ends a transaction.  Returns SUCCESS if transaction
//  committed, or FAILURE if aborted.
int xend(void);


// Read-only transactions.
int xbeginQuery(void);
int xendQuery(void);


// These two checkpoint functions aren't implemented yet.
void xCheckpointBegin(void);
void xCheckpointEnd(void);


// returns TRUE if we are inside a transaction, FALSE otherwise.
int insideTransaction(void);
// Returns TRUE if we are doing durable transactions
inline int durableXactions(void);

// For the current process, returns a pointer to the beginning of the
// transactionally mapped region.
void* regionAddr(void);


/**
 * Advisory function 
 *
 * Tells the runtime system that we want to page containing the
 * specified address.  readOnly should be TRUE to ask for read-only
 * permission, and FALSE if we want write-permission.
 */
void xAdvisory(void* addr, int readOnly);


/**
 *  Print some information about final statistics.
 */
void reportStatsOnProcess(void);



void setLogTestMode(int newLogTestMode);
#endif
