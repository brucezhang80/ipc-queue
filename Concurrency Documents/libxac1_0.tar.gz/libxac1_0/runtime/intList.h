/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * intList.h
 *
 *  Maintains a sorted list of integers in a packed array.
 *   Not efficient. (i.e., insert is O(n^2), search is O(lg n))
 */

#include "basics.h"

#ifndef __INT_LIST_H
#define __INT_LIST_H



/**
 * Adds x to the array, if it isn't already there.
 * Returns -1 if there is an error, 0
 *  otherwise.
 * Does not check to see if there is space in the array. This must
 *   be done before.
 */
inline int addIntToList(int* array, int* length, int x);

/** Returns TRUE if x is in the array **/
inline int containsInt(int* array, int* length, int x);

/** Returns TRUE if we removed x from the array **/
inline int removeIntFromList(int* array, int* length, int x);

#endif
