/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004    Massachusetts Institute of Technology
 * Copyright (c) 2004    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * global_file_dir.c
 *
 *  Search, add, and delete of "global_file_info" elements.
 *   Implemented as a B-tree (keys stored in the tree)
 */

#include <string.h>

#include "basics.h"
#include "global_file_dir.h"
#include "globalTypes.h"
#include "globalControl.h"


extern xactionContext* currentXC;


static inline int key_cmp(global_file_info* k1, global_file_info* k2) {
/*   printf("Is %s < %s? strncmp returns %d\n", */
/* 	 k1->name, */
/* 	 k2->name, */
/* 	 strncmp(k1->name, k2->name, XFNAME_LENGTH)); */
  return strncmp(k1->name, k2->name, XFNAME_LENGTH);
}

void key_print(global_file_info* k1) {
  printf("(Key: Name = %s, id = %d, length = %zd)",
	 k1->name, k1->id, k1->length);
}


// This function is used to break ties in the B-tree.
// Replaces k1's length field with max(k1->length, k2->length)
static inline void key_update(global_file_info* k1, global_file_info* k2) {
  assert(strncmp(k1->name, k2->name, XFNAME_LENGTH) == 0);
  assert(k1->id == k2->id);


  if (k2->length > k1->length) {
    k1->length = k2->length;
  }
}


static OFFSET_PTR create_block(global_file_directory* gfd __attribute__((__unused__)),
			       int is_leaf) {

  OFFSET_PTR new_block;
  global_file_dblock* the_block;

  new_block = cfile_malloc(sizeof(global_file_dblock),
			   currentXC);
  assert(new_block != NULL_OFFSET);
  
  the_block = OFFSET_TO_PTR(new_block, currentXC->controlRegion);

  the_block->num_keys = 0;
  the_block->is_leaf = is_leaf;
  the_block->children[0] = NULL_OFFSET;

  return new_block;
}

static void destroy_block(global_file_directory* gfd __attribute__((__unused__)),
			  OFFSET_PTR unused_offset) {
  cfile_free(unused_offset, currentXC);
}


void init_global_file_dir(global_file_directory* gfd) {
  gfd->num_files = 0;

  // The root starts as a leaf. 
  gfd->root_block = create_block(gfd, 1);  
}


// We should at some point write the check_gfd function to check
//  whether the entire tree is in sorted order...
//  But not doing that now.

/* static void check_gfd_block(global_file_directory* gfd __attribute__((__unused__)), */
/* 			    OFFSET_PTR block_offset) { */
/*   global_file_dblock* child_block; */
/*   global_file_dblock* the_block = OFFSET_TO_PTR(block_offset, currentXC->controlRegion); */

/*   int i; */
  
/*   the_block = OFFSET_TO_PTR(block_offset, */
/* 			    currentXC->controlRegion); */

/*   if (!the_block->is_leaf) { */
/*   for (i = 0; i < the_block->num_keys+1; i++) { */
/*     child_block = OFFSET_TO_PTR(the_block->children[i], currentXC->controlRegion); */

/*     if (child_block->parent != block_offset) { */
/*       printf("ERROR! Child %zd has parent %zd instead of %zd\n", */
/* 	     the_block->children[i], child_block->parent, block_offset); */
/*       assert(FALSE); */
/*     }     */
/*   } */
/*   } */
/* } */

/* static void check_gfd_helper(global_file_directory* gfd, OFFSET_PTR block_offset) { */

/*   int i; */
/*   global_file_dblock* the_block; */
/*   the_block = OFFSET_TO_PTR(block_offset, */
/* 			    currentXC->controlRegion); */

/*   printf("Checking block %zd\n", block_offset); */
/*   check_gfd_block(gfd, block_offset); */
  
/*   if (!the_block->is_leaf) { */
/*     for (i = 0; i < the_block->num_keys+1; i++) { */
/*       check_gfd_helper(gfd, the_block->children[i]); */
/*     } */
/*   }   */
/* } */

/* void check_gfd(global_file_directory* gfd) { */
/*   check_gfd_helper(gfd, gfd->root_block);   */
/* } */



static void print_block(global_file_directory* gfd __attribute__((__unused__)),
			OFFSET_PTR block_offset) {
  int i;
  global_file_dblock* the_block;
  the_block = OFFSET_TO_PTR(block_offset,
			    currentXC->controlRegion);
  printf("***********************\n");
  printf("Block offset = %zd\n", block_offset);
  printf("%d keys: ", the_block->num_keys);
  printf("Is a leaf? %d\n", the_block->is_leaf);
  for (i = 0; i < the_block->num_keys; i++) {
    key_print(&the_block->keys[i]);
    printf("   ");
  }
  
  if (!the_block->is_leaf) {
    printf("\nChildren = ");
    for (i = 0; i < the_block->num_keys+1; i++) {
      printf("%zd  ", the_block->children[i]);
    }
  }
  else {
    printf("LEAF \n");
  }
  printf("\n");
  printf("************************\n");
}

static void print_global_file_directory_helper(global_file_directory* gfd,
					       OFFSET_PTR block_offset) {
  if (block_offset == NULL_OFFSET) {
    printf("NULL\n");
  }
  else {
    int i;
    global_file_dblock* the_block;
    the_block = OFFSET_TO_PTR(block_offset,
			      currentXC->controlRegion);

    
    print_block(gfd, block_offset);
    
    if (!the_block->is_leaf) {
      for (i = 0; i < the_block->num_keys+1; i++) {
	print_global_file_directory_helper(gfd, the_block->children[i]);
      }
    }
  }
}

void print_global_file_directory(global_file_directory* gfd) {
  printf("============================\n");
  printf("GlobalFileDirectory %p\n", gfd);
  print_global_file_directory_helper(gfd, gfd->root_block);
  printf("============================\n");
}
					

// new child is the sucessor child...
static int add_key_to_block(global_file_directory* gfd,
			    OFFSET_PTR block,
			    global_file_info* new_key,
			    OFFSET_PTR new_child) {
  int current_key;
  int cmpvalue;
  global_file_dblock* the_block;
  the_block = OFFSET_TO_PTR(block, currentXC->controlRegion);

  //  printf("Adding key with new_child %zd \n", new_child);
  assert(the_block != NULL);

  // Make sure we have space for the key.
  assert(the_block->num_keys < GFD_B-1);

  current_key = 0;

  while (current_key < the_block->num_keys) {
    cmpvalue = key_cmp(new_key, &the_block->keys[current_key]);
    if (cmpvalue <= 0)  {
      break;
    }
    else {
      current_key++;
    }   
  }


  if (the_block->num_keys == 0) {
    // This should only happen at the root really...
    assert(gfd->root_block == block);
    key_copy(&the_block->keys[0], new_key);
    the_block->children[0] = NULL_OFFSET;
    the_block->children[1] = NULL_OFFSET;
    the_block->num_keys++;
  }
  else { 


    //    printf("Adding key with new_child %zd 2! \n", new_child);
    if (cmpvalue == 0) {
      //      printf("Found element in B-tree already.\n");
      key_print(new_key);
      key_update(&the_block->keys[current_key], new_key);
    }
    else {
      int i;

      //      printf("How many keys do we have? %d\n", the_block->num_keys);
      // Not found, and there is at least 1 key in the tree.
      for (i = the_block->num_keys-1; i >= current_key; i--) {
	key_copy(&the_block->keys[i+1], &the_block->keys[i]);
	//	printf("At index i+2 = %d, moving  %zd from i+1 = %d index\n",
	//	       i+2, the_block->children[i+1], i+1);
	the_block->children[i+2] = the_block->children[i+1];
      }
      // Insert the new key into the right place.
      key_copy(&the_block->keys[current_key], new_key);
      //      printf("ABout to copy into slot %d the child %zd\n",
      //	     i+2, new_child);
      the_block->children[i+2] = new_child;
      the_block->num_keys++;
    }

  }

  return 0;
}

static void insert_key_into_gfd_helper(global_file_directory* gfd,
				       global_file_info* new_key,
				       OFFSET_PTR current_offset,
				       OFFSET_PTR parent_offset) {

  global_file_dblock* current_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);

  //  printf("Called insert key on offset %zd\n", current_offset);
  //  key_print(new_key);
  //  print_block(gfd, current_offset);
  
  //  assert(current_block->parent != NULL_OFFSET);
  
  if (current_block->num_keys >= GFD_B-1) {
    int split_key = GFD_B/2 - 1;
    int new_block_offset;

    int cmp_value;
    assert(current_block->num_keys == GFD_B-1);


    // Allocate space for a new block.
    new_block_offset = create_block(gfd,
				    current_block->is_leaf);
    assert(new_block_offset != 0);


    cmp_value = key_cmp(new_key,
			&current_block->keys[split_key]);

    if (cmp_value == 0) {
      key_update(&current_block->keys[split_key], new_key);
    }

/*     printf("Current block is %zd, block's parent is %zd\n", current_offset, parent_offset); */
/*     printf("Before adding split key %s to parent...\n", */
/* 	   current_block->keys[split_key].name); */
/*     print_block(gfd, parent_offset); */
/*     printf("Who is the parent? %zd\n", parent_offset); */
    
    // Put the middle key into the parent block.
    add_key_to_block(gfd,
		     parent_offset,
		     &current_block->keys[split_key],
		     new_block_offset);

    //    printf("After adding split key %s to parent...\n",
    //	   current_block->keys[split_key].name);
    //    print_block(gfd, parent_offset);

    // Fix left block
    current_block->num_keys = split_key;

    // Fix the contents of the right block.
    {
      global_file_dblock* right_block;
      int j;
      right_block = OFFSET_TO_PTR(new_block_offset, currentXC->controlRegion);

      for (j = 0; j < split_key; j++) {
	key_copy(&right_block->keys[j],
		 &current_block->keys[1+split_key+j]);
	right_block->children[j] = current_block->children[1+split_key+j];	
      }
      right_block->children[split_key] = current_block->children[1+2*split_key];
      right_block->num_keys = split_key;
    }

    if (cmp_value == 0) {
      // We already fixed this above.
    }
    else {
      if (cmp_value > 0) {       
	// Insert into right block
	printf("INserting key %s into right block\n", new_key->name);
	insert_key_into_gfd_helper(gfd,
				   new_key,
				   new_block_offset,
				   parent_offset);
      }
      else {
	// Insert into left block.
	printf("INserting key %s into left block\n", new_key->name);
	insert_key_into_gfd_helper(gfd,
				   new_key,
				   current_offset,
				   parent_offset);
      }
    }
  }
  else {
    // We have space in this node in case something gets split...
    if (current_block->is_leaf) {
      add_key_to_block(gfd,
		       current_offset,
		       new_key,
		       NULL_OFFSET);
    }
    else {
      int current_key = 0;
      int cmp_value;

      while (current_key < current_block->num_keys) {
	cmp_value = key_cmp(new_key,
			    &current_block->keys[current_key]);
	if (cmp_value <= 0) {
	  break;
	}
	current_key++;
      }

      // We found the value here in this non-leaf...
      if (cmp_value == 0) {
	key_update(&current_block->keys[current_key],
		   new_key);
	printf("Found key in block at %zd\n", current_offset);
	key_print(&current_block->keys[current_key]);
      }
      else {
	assert(current_block->children[current_key] != NULL_OFFSET);	
	insert_key_into_gfd_helper(gfd,
				   new_key,
				   current_block->children[current_key],
				   current_offset);
      }
    }        
  }  
}

void insert_key_into_gfd(global_file_directory* gfd,
			 global_file_info* new_key) {
  OFFSET_PTR root_offset;
  global_file_dblock* root_block;

  assert(gfd != NULL);

  root_offset = gfd->root_block;
  root_block = (global_file_dblock*)OFFSET_TO_PTR(root_offset,
						  currentXC->controlRegion);


  // If the root is full, split the root node pre-emptively.
  if (root_block->num_keys >= GFD_B-1) {

    int split_key = GFD_B/2 - 1;
    OFFSET_PTR new_block_offset;
    global_file_dblock* new_block_ptr;

    OFFSET_PTR new_child_offset;
    global_file_dblock* new_child_ptr;


    // Create a new root node.
    new_block_offset = create_block(gfd,
				    0); // Not a leaf.
    
    new_block_ptr = OFFSET_TO_PTR(new_block_offset,
				  currentXC->controlRegion);
    
    // Create a block for the new right node.
    new_child_offset = create_block(gfd,
				    root_block->is_leaf);
    
    new_child_ptr = OFFSET_TO_PTR(new_child_offset,
				  currentXC->controlRegion);

    {
      // Move the children to the new right block.
      int j;

      for (j = 0; j < split_key; j++) {
	key_copy(&new_child_ptr->keys[j],
		 &root_block->keys[1+split_key+j]);
	new_child_ptr->children[j] = root_block->children[1+split_key+j];	  
      }
      new_child_ptr->children[split_key] = root_block->children[1+2*split_key];

      new_child_ptr->num_keys = split_key;
    }
    
    // Cut the children from the left block.
    //  and fix the parent pointer of the left block.
    root_block->num_keys = split_key;

    // Fix the new root block.
    new_block_ptr->keys[0] = root_block->keys[split_key];   
    new_block_ptr->children[0] = root_offset;
    new_block_ptr->children[1] = new_child_offset;
    new_block_ptr->num_keys = 1;
  
    assert(new_block_offset != NULL_OFFSET);
    
    // Finally, change root pointer for the entire tree.
    gfd->root_block = new_block_offset;    				            
  }

  // Insert starting at the (original) root.
  insert_key_into_gfd_helper(gfd, new_key, gfd->root_block, NULL_OFFSET);
}


static int find_key_in_block_helper(global_file_directory* gfd,
				    OFFSET_PTR block_offset,
				    global_file_info* element) {
  
  int i = 0;
  int cmpvalue;
  global_file_dblock* current_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(block_offset, currentXC->controlRegion);

  // Set i to be the index of the last key such that
  //  element <= key[i]
  for (i = 0; i < current_block->num_keys; i++) {
    cmpvalue = key_cmp(element, &current_block->keys[i]);
    if (cmpvalue <= 0) {
      break;
    }    
  }


  if (cmpvalue == 0) {
    key_copy(element, &current_block->keys[i]);
    return 1;
  }
  else {

    if (current_block->is_leaf) {
      // If we are at a leaf, then not found.
      return 0;
    }
    else {
      // Search down the tree.
      return find_key_in_block_helper(gfd,
				      current_block->children[i],
				      element);      
    }
  }
}


int find_key_in_gfd(global_file_directory* gfd,
		    global_file_info* elem) {

  //  printf("searching for element with name %s\n", elem->name);
  return find_key_in_block_helper(gfd,
				  gfd->root_block,
				  elem);
}



#define MIN_KEYS (GFD_B/2 -2)

static int delete_key_from_block_using_index(global_file_directory* gfd,
					     OFFSET_PTR block_offset,
					     int i) {
  // i is the index of the key to get rid of..
  global_file_dblock* current_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(block_offset, currentXC->controlRegion);
  int j;


  // Every block but the root should have the minimum # of children
  //  before we can delete the key.
  // Make sure after the delete, we will have enough children.
  
  if (block_offset != gfd->root_block) {
    assert(current_block->num_keys > MIN_KEYS);
  }

  // Slide all keys starting at index i+1 left by one.
  for (j = i+1; j < current_block->num_keys; j++) {
    key_copy(&current_block->keys[j-1],
	     &current_block->keys[j]);
  }

  if (!current_block->is_leaf) {
    // Have to move the children down by 1 as well...
    
    // At least one of the children of this key must be null.
    assert((current_block->children[i] == NULL_OFFSET) ||
	   (current_block->children[i+1] == NULL_OFFSET));

    // Set the left one to be a correct value. 
    if (current_block->children[i] == NULL_OFFSET) {
      // child to the left of key is null
      current_block->children[i] = current_block->children[i+1];
    }

    // Slide the rest of the children down by 1.
    for (j = i+1; j < current_block->num_keys+1; j++) {
      current_block->children[j] = current_block->children[j+1];
    }
  }
    
  current_block->num_keys--;
  return 0;
}

static int delete_key_from_block(global_file_directory* gfd,
				 OFFSET_PTR block_offset,
				 global_file_info* key) {
  
  global_file_dblock* current_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(block_offset, currentXC->controlRegion);

  // Every block but the root should have the minimum # of children
  //  before we can delete the key.
  int i = 0;
  int cmpvalue;

  // Make sure after the delete, we will have enough children.
  if (block_offset != gfd->root_block) {
    assert(current_block->num_keys > MIN_KEYS);
  }

  // Find the place in the block where the key goes...
  while (i < current_block->num_keys) {
    cmpvalue = key_cmp(key, &current_block->keys[i]);
    if (cmpvalue <= 0) {
      break;
    }
    i++;
  }

  if ((cmpvalue != 0) || (i >= current_block->num_keys)) {
    return 1;  // error. value not found.
  }
  else {
    key_copy(key, &current_block->keys[i]);
    return delete_key_from_block_using_index(gfd, block_offset, i);
  }  
}


// Used when merging blocks together for a delete
static OFFSET_PTR merge_steal_from_sibling(global_file_directory* gfd __attribute__((__unused__)),
					   OFFSET_PTR current_offset,
					   OFFSET_PTR parent_offset) {
  int i;
  int parent_index;
  int stolen = 0;
  global_file_dblock* current_block;
  global_file_dblock* parent_block;
  global_file_dblock* sibling_block;

  assert(parent_offset != NULL_OFFSET);
  current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);
  parent_block = (global_file_dblock*)OFFSET_TO_PTR(parent_offset, currentXC->controlRegion);


  // We only do this if the current block has the min. number of keys..
  assert(current_block->num_keys == MIN_KEYS);

  i = 0;
  while ((i < parent_block->num_keys+1) && (parent_block->children[i] != current_offset)) {
    i++;
  }
  assert(i <= parent_block->num_keys);

  // The child pointer of the parent. 
  parent_index = i;


  // try stealing from left child 
  if (parent_index > 0) {
    OFFSET_PTR sibling_offset = parent_block->children[parent_index-1];
    sibling_block = (global_file_dblock*)OFFSET_TO_PTR(parent_block->children[parent_index-1],
						       currentXC->controlRegion);
    // Only steal if we have enough to steal from..
    if (sibling_block->num_keys > MIN_KEYS) {
      int j;
      // Shift right by 1 all keys and children pointers.

      for (j = current_block->num_keys-1; j >= 0; j --) {
	key_copy(&current_block->keys[j+1], &current_block->keys[j]);	
      }

      if (!current_block->is_leaf) {
	for (j = current_block->num_keys; j >= 0; j --) {
	  current_block->children[j+1] = current_block->children[j];
	}	
      }

      // Take the parent's element and the sibling's rightmost child subtree.
      key_copy(&current_block->keys[0], &parent_block->keys[parent_index-1]);
      
      if (!current_block->is_leaf) {
	current_block->children[0] = sibling_block->children[sibling_block->num_keys];
      }
     
      // Move the sibling's last element up to parent.
      key_copy(&parent_block->keys[parent_index-1], &sibling_block->keys[sibling_block->num_keys-1]);

      // Fix number of keys in both blocks.
      sibling_block->num_keys--;
      current_block->num_keys++;

    }
    else {
      int j;
      // We are going to merge current block into the left child.
      assert(sibling_block->num_keys == MIN_KEYS);

      // Move the parent element down into the array.
      key_copy(&sibling_block->keys[MIN_KEYS], &parent_block->keys[parent_index-1]);

      // Copy current block's keys into sibling
      for (j = 0; j < MIN_KEYS; j++) {
	key_copy(&sibling_block->keys[MIN_KEYS+1 + j], &current_block->keys[j]);
      }
      
      // Copy current block's children into sibling.
      if (!sibling_block->is_leaf) {
	for (j = 0; j < MIN_KEYS+1; j++) {
	  sibling_block->children[MIN_KEYS+1+j] = current_block->children[j];
	}
      }

      sibling_block->num_keys += (current_block->num_keys + 1);      
      assert(sibling_block->num_keys == (2*MIN_KEYS+1));

      // Free the block now...
      printf("Destroying block 324 %zd\n", current_offset);
      destroy_block(gfd, current_offset);

      // Delete that extra copy of the key in the parent...
      parent_block->children[parent_index] = NULL_OFFSET;
      delete_key_from_block_using_index(gfd,
					parent_offset,
					parent_index-1);

      return sibling_offset;
    }
  }
  else {
    // We steal/merge with the right child..
    
    int j;
    OFFSET_PTR sibling_offset = parent_block->children[parent_index+1];
    assert(parent_index < parent_block->num_keys);
    sibling_block = (global_file_dblock*)OFFSET_TO_PTR(parent_block->children[parent_index+1],
						       currentXC->controlRegion);

    if (sibling_block->num_keys > MIN_KEYS) {

      // Take the parent's element and the sibling's rightmost child subtree.
      key_copy(&current_block->keys[current_block->num_keys], &parent_block->keys[parent_index]);

      if (!current_block->is_leaf) {
	current_block->children[current_block->num_keys+1] = sibling_block->children[0];
      }

      // Move the sibling's first element up to parent.
      key_copy(&parent_block->keys[parent_index], &sibling_block->keys[0]);


      // In the right child, shift all keys/children down by 1.
      for (j = 0; j < sibling_block->num_keys-1; j++) {      
	key_copy(&sibling_block->keys[j], &sibling_block->keys[j+1]);
      }
    
      if (!sibling_block->is_leaf) {
	for (j = 0; j < sibling_block->num_keys; j++) {
	  sibling_block->children[j] = sibling_block->children[j+1];
	}
      }


      // Fix number of keys in both blocks.
      sibling_block->num_keys--;
      current_block->num_keys++;
      stolen = 1;  // Succeed in stealing.
    }
    else {
      // Merge with right child..
      assert(sibling_block->num_keys == MIN_KEYS);
      key_copy(&current_block->keys[MIN_KEYS],
	       &parent_block->keys[parent_index]);

      // Take my sibling's keys..
      for (j = 0; j < MIN_KEYS; j++) {
	key_copy(&current_block->keys[MIN_KEYS+1+j],
		 &sibling_block->keys[j]);	
      }

      if (!current_block->is_leaf) {
	for (j = 0; j < MIN_KEYS+1; j++) {
	  current_block->children[MIN_KEYS+1+j] = sibling_block->children[j];
	}
      }

      // Fix my number of keys.
      current_block->num_keys += (1 + sibling_block->num_keys);
      assert(current_block->num_keys == (2*MIN_KEYS) + 1);

           
      // Free the block now...
      printf("Destroying block 12 %zd\n", sibling_offset);
      destroy_block(gfd, sibling_offset);

      // Delete that extra copy of the key in the parent...
      parent_block->children[parent_index+1] = NULL_OFFSET;
      delete_key_from_block_using_index(gfd,
					parent_offset,
					parent_index);
    }
  }
  // In most cases, the offset will remain the same
  return current_offset;
}


// Delete: works only when key is in a leaf
static int delete_key_helper(global_file_directory* gfd,
			     OFFSET_PTR current_offset,
			     OFFSET_PTR parent_offset,
			     global_file_info* key) {

  int i, cmpvalue;
  global_file_dblock* current_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);

  //  printf("What is the current_offset?%zd\n", current_offset);


  if ((current_block->num_keys == MIN_KEYS) && (!(gfd->root_block == current_offset))){
    // Don't have enough keys. steal one or merge with sibling...
    //    printf("Block %zd merge/steal since it has only %d keys...\n",
    //	   current_offset, current_block->num_keys);

    // The merge operation may change the offset..
    current_offset = merge_steal_from_sibling(gfd,
					      current_offset,
					      parent_offset);
    current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);

    //    print_global_file_directory(gfd);
  }

/*   printf("Now we wish to get rid of key %s\n", key->name); */
/*   printf("Block %zd now has %d keys...\n", */
/* 	 current_offset, current_block->num_keys); */
/*   printf("What is the root block? %zd\n", gfd->root_block); */

  // Now we should have at least the min. number of keys.
  assert((current_block->num_keys > MIN_KEYS) ||
	 (current_offset == gfd->root_block));


  // If its in a leaf, just get rid of it...
  if (current_block->is_leaf) {
    assert((current_block->num_keys > MIN_KEYS) ||
	   (current_offset == gfd->root_block));
    return delete_key_from_block(gfd,
				 current_offset,
				 key);    
  }


  // Otherwise, we aren't in a leaf.
  // Figure out which child to walk down
  for (i = 0; i < current_block->num_keys; i++) {
    cmpvalue = key_cmp(key, &current_block->keys[i]);
    if (cmpvalue <= 0) {
      break;
    }
  }
  
  // Delete from that subtree.
  return delete_key_helper(gfd,
			   current_block->children[i],
			   current_offset,
			   key);
}

static inline int find_index_function(global_file_dblock* current_block,
				      global_file_info* key) {
  int i, cmpvalue;
  for (i = 0; i < current_block->num_keys; i++) {
    cmpvalue = key_cmp(key, &current_block->keys[i]);
    if (cmpvalue <= 0) {
      break;
    }
  }
  return i;
}

// Special handling for the root:
static int special_delete_key(global_file_directory* gfd,
			      global_file_info* key) {

  global_file_dblock* top_block;
  top_block = (global_file_dblock*)OFFSET_TO_PTR(gfd->root_block, currentXC->controlRegion);


  //  printf("Running special delete key on %s\n", key->name);
  if (top_block->num_keys == 1) {
    global_file_dblock* left_block;
    global_file_dblock* right_block;

    left_block = (global_file_dblock*)OFFSET_TO_PTR(top_block->children[0], currentXC->controlRegion);
    right_block = (global_file_dblock*)OFFSET_TO_PTR(top_block->children[1], currentXC->controlRegion);

    if ((left_block->num_keys == MIN_KEYS) && (right_block->num_keys == MIN_KEYS)) {
      int j;
      // Merge the left and right blocks together.

      key_copy(&left_block->keys[MIN_KEYS],
	       &top_block->keys[0]);
      
      for (j = 0; j < MIN_KEYS; j++) {
	key_copy(&left_block->keys[MIN_KEYS+1+j],
		 &right_block->keys[j]);	
      }
      
      // Copy all the children from the right block...
      if (!left_block->is_leaf) {
	for (j = 0; j < MIN_KEYS+1; j++) {
	  left_block->children[MIN_KEYS+1+j] = right_block->children[j];
	}	
      }

      // Fix number of keys now.
      left_block->num_keys += (1 + right_block->num_keys);
      assert(left_block->num_keys == (2*MIN_KEYS+1));

/*       printf("About to delete block at offset %zd\n", */
/* 	     top_block->children[1]); */

      destroy_block(gfd, top_block->children[1]);
      {
	OFFSET_PTR oldroot = gfd->root_block;
	gfd->root_block = top_block->children[0];
	destroy_block(gfd, oldroot);
      }         
    }
    else {
      //      printf("Not merging blocks for some reason...\n");
    }
  }
  else {
    //    printf("not running that weird special case in special-delete...\n");
  }

  // In any case, after we've fixed root, proceed as normal.
  return delete_key_helper(gfd, gfd->root_block, NULL_OFFSET, key);

}


// Searches the tree for "key", and replaces it with
//  the information in "prec"
static int replace_delete_helper(global_file_directory* gfd,
				 global_file_info* key,
				 global_file_info* prec) {
  OFFSET_PTR current_offset;
  global_file_dblock* current_block;

  int i, cmpvalue;

  current_offset = gfd->root_block;

  printf("Key is %s, prec is %s\n", key->name, prec->name);
  while (1) {
    current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset,
						       currentXC->controlRegion);
    for (i = 0; i < current_block->num_keys; i++) {
      cmpvalue = key_cmp(key, &current_block->keys[i]);
      if (cmpvalue <= 0) {

	break;
      }
    }

    if (cmpvalue == 0) {
      key_copy(key, &current_block->keys[i]);
      printf("About to replace key %s with %s\n",
	     current_block->keys[i].name,
	     prec->name);
      key_copy(&current_block->keys[i], prec);
      return 0;
    }

    if (current_block->is_leaf) {
      return 1;
    }

    // If we get to here, then
    // walk down tree.
    current_offset = current_block->children[i];
  }
  return 1;
}

  
  
// The full delete function
int delete_key(global_file_directory* gfd,
	       global_file_info* key) {
  
  int i, cmpvalue;
  OFFSET_PTR current_offset;
  OFFSET_PTR parent_offset;
  global_file_dblock* current_block;

  parent_offset = NULL_OFFSET;
  current_offset = gfd->root_block;
  current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);

  while (!current_block->is_leaf) {
    for (i = 0; i < current_block->num_keys; i++) {
      cmpvalue = key_cmp(key, &current_block->keys[i]);
      if (cmpvalue <= 0) {
	break;
      }
    }

    if (cmpvalue == 0) {
      break;
    }
    else {
      parent_offset = current_offset;
      current_offset = current_block->children[i];
      current_block = (global_file_dblock*)OFFSET_TO_PTR(current_offset, currentXC->controlRegion);
    }
  }

  // If we get to a leaf, then just look for the element in the leaf.
  if (current_block->is_leaf) {
    for (i = 0; i < current_block->num_keys; i++) {
      cmpvalue = key_cmp(key, &current_block->keys[i]);
      if (cmpvalue <= 0) {
	break;
      }
    }    
  }
  
  if (cmpvalue == 0) {
    if (current_block->is_leaf) {
      // Run the normal delete.
      return special_delete_key(gfd, key);
    }
    else {
      global_file_info prec;
      global_file_info* actual_elt_to_delete;
      // Go left once
      OFFSET_PTR child_offset = current_block->children[i];      
      global_file_dblock* next_block;
      OFFSET_PTR next_offset;

      actual_elt_to_delete = &current_block->keys[i];
	
      next_block = (global_file_dblock*)OFFSET_TO_PTR(child_offset, currentXC->controlRegion);

      // Then go all the way right.
      while (!next_block->is_leaf) {
	next_offset = next_block->children[next_block->num_keys];
	next_block = (global_file_dblock*)OFFSET_TO_PTR(next_offset,
							currentXC->controlRegion);	
      }

      key_copy(&prec, &next_block->keys[next_block->num_keys-1]);

      // Perform a special delete on the predecessor      
      special_delete_key(gfd, &prec);


      // Replace the key we were looking for originally with
      // its predecessor.
      {
	int answer = replace_delete_helper(gfd, key, &prec);
	assert(answer == 0);
	return answer;
      }
    }
  }

  return 1;  // Not found
}



