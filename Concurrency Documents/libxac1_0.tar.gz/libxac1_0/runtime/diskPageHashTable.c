/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * diskPageHashTable.c
 * 
 *  Hash table that stores dpPtr's 
 */


#include <stdlib.h>

#include "diskPageHashTable.h"


// HashBucket stuff.  For now, I'm not using any of this stuff.


#define HASH_BUCKET_SIZE 10
typedef struct hashBucketStruct hashBucket;

struct hashBucketStruct {
  short itemLength;
  dpPair items[HASH_BUCKET_SIZE];
  hashBucket* next;
  hashBucket* prev;
};

void printBucket(hashBucket* b);
inline dpPair searchBucket(hashBucket* b, int key);
inline void insertIntoBucket(hashBucket* b, int key, dpPtr diskPage);
inline void deleteFromBucket(hashBucket* b, int key);
void destroyBucket(hashBucket* b);
int verifyBucket(hashBucket* b);

int testHashBuckets(void);
int testHashTable(void);

static void initBucket(hashBucket* b) {
  b->itemLength = 0;
  b->next = NULL;
  b->prev = NULL;
}



static void printBucketHelper(hashBucket* b) {
  int i;
  if (b != NULL) {
    printf("{");
    //    printf("Bucket length is %d\n", b->itemLength);
    for (i = 0; i < b->itemLength; i++) {
      printf("(%d: %d,  %d ) ", b->items[i].key, b->items[i].diskPage.fileId, b->items[i].diskPage.dp);
    }

    printf(" } \n");
  }
}

void printBucket(hashBucket* b) {

  hashBucket* current = b;
  printf("\n***************   \n");
  printf("Bucket:   \n");
  
  while (current != NULL) {
    printBucketHelper(current);
    current = current->next;
  }

  printf("\n***************:   \n");
}






// Returns true if pair is in the bucket.
inline dpPair searchBucket(hashBucket* b, int key) {

  hashBucket* current;
  dpPair answerPair;
  answerPair.key = NULL_KEY;
  answerPair.diskPage = nullPagePtr();
  current = b;

  while (current != NULL) {
    if (current->itemLength == 0)  {
      // If we hit an empty bucket, we must be at the last bucket.
      //      printBucket(b);
      assert(current->next == NULL);
      return answerPair;
    }
    else {
      if (current->items[current->itemLength - 1].key < key) {
	// Check in the next bucket.
	current = current->next;
      }
      else {
	// It should be in this bucket, if it is there.
	int i = 0;
	while (i< current->itemLength) {
	  if (current->items[i].key == key) {
	    answerPair.key = key;
	    answerPair.diskPage = current->items[i].diskPage;
	    break;
	  }
	  else {
	    i++;
	  }
	}

	// here, return null because we didn't find it.
	return answerPair;	
      }
    }   
  }
  
  // If we get to the last bucket, it isn't there.
  return answerPair;  
}

//  Only works if key isn't already in the bucket...
inline void insertIntoBucket(hashBucket* b, int key, dpPtr diskPage) {
  int i;
  
  if (b->itemLength < HASH_BUCKET_SIZE) {
    // There is space in this bucket.    

    i = b->itemLength -1;

    if ((i > 0) && ((key > b->items[i].key) &&( b->next != NULL))) {
      // If there is a bigger bucket, try to insert there first.
      insertIntoBucket(b->next, key, diskPage);
    }
    else {
      if (i < 0) assert( b->next == NULL);
      
      //	printf("My current bucket length is %d.\n",
      //	       b->itemLength);
	
      // We know there is no bigger bucket.
      //   Safe to insert here.
      while ((i >= 0) && (b->items[i].key > key)) {
	// Shift one over.
	//	  printf("Shift: i is %d\n", i);
	b->items[i+1] = b->items[i];
	i--;
      }
	
      //      printf("What is i now? %d\n", i);      
      //      printf("My current bucket length is %d.\n",
      //	     b->itemLength);
      b->items[i+1].key = key;


      //	printf("What is i now? %d\n", i);      
      //	printf("My current bucket length is %d.\n",
      //	       b->itemLength);


      b->items[i+1].diskPage = diskPage;
      //	printf("What is i now? %d\n", i);      
      //	printf("After updating disk page... current bucket length is %d.\n",
      //	       b->itemLength);

      //	printf("I will increment my bucket length from %d.\n",
      //	       b->itemLength);
      b->itemLength++;
    }
    
  }
  else {
    // Add a new bucket if necessary.
    if (b->next == NULL) {
      hashBucket* tempBucket = (malloc)(sizeof(hashBucket));
      initBucket(tempBucket);
      
      // Link the new bucket in.
      b->next = tempBucket;
      b->next->prev = b;
      //      printf("After adding empty bucket: \n");
      //      printBucket(b);
    }

    assert(b->itemLength == HASH_BUCKET_SIZE);
    if (key < b->items[b->itemLength-1].key) {
      // New key belongs in this bucket.
      // Insert the last item from this bucket into the next.
      insertIntoBucket(b->next,
		       b->items[b->itemLength-1].key,
		       b->items[b->itemLength-1].diskPage);

      // Now insert the new element into this bucket.
      // Shift over elements in this bucket to make room for new one.
      i = b->itemLength-2;
      
      //   Safe to insert here.
      while ((i >= 0) && (b->items[i].key > key)) {
	// Shift one over.
	//	  printf("Shift: i is %d\n", i);
	b->items[i+1] = b->items[i];
	i--;
      }
      //      printf("What is i now? %d\n", i);      
      //      printf("My current bucket length is %d.\n",
      //	     b->itemLength);
      b->items[i+1].key = key;
      b->items[i+1].diskPage = diskPage;
    }
    else {
      // New key belongs in next bucket.  Just insert.
      insertIntoBucket(b->next, key, diskPage);
    }
  }
}


inline void deleteFromBucket(hashBucket* b, int key) {
  if ((b != NULL)  && (b->itemLength > 0)) {

    // Item isn't in the bucket...
    if (b->items[b->itemLength - 1].key < key) {      
      if (b->next != NULL) {
	// Recursively delete from the rest of the list.

	//	printf("Recursively deleting %d from next bucket\n", key);
	//	printBucket(b->next);
	deleteFromBucket(b->next, key);
	
	// Delete the next bucket if necessary.
	if (b->next->itemLength == 0) {
	  hashBucket* trash = b->next;
	  b->next = trash->next;
	  free(trash);
	}
      }            
    }
    else {
      // Item should be in this bucket, it if
      //  is here at all.
      int i = 0;

      // Look for item index.
      while (i < b->itemLength -1) {
	if (b->items[i].key >= key) {
	  break;
	}
	i++;
      }

      //      printf("Index we found in bucket is %d\n", i);
      // If we actually found the element,
      //   delete it from this bucket.

      {
	int j;
	for (j = i+1; j < b->itemLength; j++) {
	  b->items[j-1] = b->items[j];
	}
	b->itemLength--;
      }

      // If this bucket became empty, 
      if (b->itemLength == 0) {
	if ((b->prev != NULL) && (b->next != NULL)) {
	  hashBucket* a = b->prev;
	  hashBucket* c = b->next;
	  // Link around and get rid of this bucket.
	  a->next = c;
	  c->prev = a;
	  free(b);
	}
	else {
	  if ((b->prev == NULL) &&(b->next != NULL)) {
	    int j;
	    hashBucket* trash;

	    // The first bucket is empty.
	    // Steal all elements from the bucket in front of me.
	    assert(b->next->itemLength > 0);

	    for (j = 0; j < b->next->itemLength; j++) {
	      b->items[j] = b->next->items[j];	      
	    }
	    b->itemLength = b->next->itemLength;
	    
	    
	    // Link around the next bucket.	    
	    trash = b->next;
	    b->next = trash->next;
	    if (trash->next != NULL) {
	      trash->next->prev = b;
	    }

	    free(trash);
	  }
	}
      }
    }
  }
}



static void destroyBucketHelper(hashBucket* b) {
  if (b != NULL) {
    destroyBucketHelper(b->next);
    free(b);
  }
}

// Free everything but the first bucket.
void destroyBucket(hashBucket* b) {
  if (b != NULL) {
    destroyBucketHelper(b->next);
  }
}


int verifyBucket(hashBucket* b) {
  hashBucket* current = b;
  int currentVal = -1;
  

  while (current != NULL) {
    int i = 0;
    for (i = 0; i < current->itemLength; i++) {
      if (current->items[i].key <= currentVal) {
	return FALSE;
      }
      else {
	currentVal = current->items[i].key;
      }
    }
    current = current->next;
  }

  return TRUE;
}

/********************************************************/
// Main program for testing hash buckets.

#define N 15000
int testHashBuckets(void) {
  int i;
  hashBucket bTest;
  hashBucket* b = &bTest;
  dpPair myPage;
  dpPair testInserts[N];
  dpPair searchAnswer;
  int currentSeed = 10;
  printf("Testing dp hash table code.\n");

  initBucket(b);
  printBucket(b);
  
  srand(currentSeed);
  
  printf("My bucket length is %d\n", b->itemLength);
  myPage.diskPage.fileId = -123;
  printf("Doing %d inserts with random deletes... \n", N);
  for (i = 0; i  < N; i++) {
    int retryCount = 0;
    int repeated = FALSE;

    myPage.key = (int)(N*100 * (1.0*(rand()))/ (RAND_MAX)) + retryCount;
    
    do {
      int j = 0;
      repeated = FALSE;
      myPage.key++;
      for (j = 0; j < i; j++) {
	if (myPage.key == testInserts[j].key) {
	  //	  printf("Bad key is %d, match at index %d\n", myPage.key, j);
	  retryCount++;
	  repeated = TRUE;
	  break;
	}
      }
    }  while (repeated);
    
    myPage.diskPage.dp = rand() % 1000;      
    testInserts[i] = myPage;

    printf("Inserting (%d,  %d)\n", myPage.key, myPage.diskPage.dp);
    insertIntoBucket(b, myPage.key, myPage.diskPage);
    if (! verifyBucket(b)) {
      printBucket(b);
      assert(FALSE);
    }

    searchAnswer = searchBucket(b, myPage.key);
    if (!((searchAnswer.key == myPage.key) &&
	  (searchAnswer.diskPage.dp == myPage.diskPage.dp))) {

      printf("Error! inserted (%d, %d), but found (%d, %d) instead.",
	     myPage.key, myPage.diskPage.dp,
	     searchAnswer.key, searchAnswer.diskPage.dp);
      assert(FALSE);
    }
    else {
      printf("Found (%d, %d).\n",
	     searchAnswer.key,
	     searchAnswer.diskPage.dp);
    }
    //    printBucket(b);


    if ((rand() >> 16) % 11 == 0) {
      printf("We don't actually want (%d, %d).  Delete it \n",
	     testInserts[i].key,
	     testInserts[i].diskPage.dp);
      deleteFromBucket(b, testInserts[i].key);    
      if (! verifyBucket(b)) {
	printBucket(b);
	assert(FALSE);
      }

      searchAnswer = searchBucket(b, testInserts[i].key);
      //      printBucket(b);
      if (! ((searchAnswer.key == (NULL_KEY)) &&
	     (searchAnswer.diskPage.fileId == NULL_FILE_ID) &&
	     (searchAnswer.diskPage.dp == UNMAPPED_PAGE))) {
	printf("Error! Deleted (%d, %d), but still found (%d, %d)\n",
	       testInserts[i].key,
	       testInserts[i].diskPage.dp,
	       searchAnswer.key,
	       searchAnswer.diskPage.dp);
	assert(FALSE);
      }

      i--; 
    }
  }

  for (i = 0; i < N; i++) {
    myPage = testInserts[i];
    searchAnswer = searchBucket(b, myPage.key);
    if (!((searchAnswer.key == myPage.key) &&
	  (searchAnswer.diskPage.dp == myPage.diskPage.dp))) {

      printf("Error! inserted (%d, %d), but found (%d, %d) instead.",
	     myPage.key, myPage.diskPage.dp,
	     searchAnswer.key, searchAnswer.diskPage.dp);
      assert(FALSE);
    }
  }

  printf("Doing %d deletes... \n", N);
  for (i = 0; i < N; i++) {
    printf("Deleting element (%d, %d)\n", testInserts[i].key, testInserts[i].diskPage.dp);
    deleteFromBucket(b, testInserts[i].key);
    
    if (! verifyBucket(b)) {
      printBucket(b);
      assert(FALSE);
    }

    searchAnswer = searchBucket(b, testInserts[i].key);
    //    printBucket(b);
    if (! ((searchAnswer.key == (NULL_KEY)) &&
	   (searchAnswer.diskPage.fileId == NULL_FILE_ID) &&
	   (searchAnswer.diskPage.dp == UNMAPPED_PAGE))) {
      printf("Error! Deleted (%d, %d), but still found (%d, %d)\n",
	     testInserts[i].key,
	     testInserts[i].diskPage.dp,
	     searchAnswer.key,
	     searchAnswer.diskPage.dp);
      printBucket(b);
      assert(FALSE);
    }          
  }
  

  printf("Successfully completed all tests on bucket insert/search/delete.\n");
      
  return 0;
}




/***************************/
// The actual hash table structure.

struct dpHashTableStruct {
  int size;                   // Total num of elements in array.
  int numBuckets;             // current number of buckets
  hashBucket* bucketArray;
};


#define DEFAULT_HASH_TABLE_SIZE 50021 //10007
//#define DEFAULT_HASH_TABLE_SIZE 3

static void initHashTable(dpHashTable* htable, int defaultSize) {
  int i;
  int numBuckets = (defaultSize);
  
  htable->size = 0;
  htable->numBuckets = numBuckets;
  
  htable->bucketArray = (hashBucket*) malloc(sizeof(hashBucket) * numBuckets);
  // initialize the bucket array
  for (i = 0; i < numBuckets; i++) {
    initBucket(&htable->bucketArray[i]);
  }
}


dpHashTable* createDPHashTable(void) {
  dpHashTable* answer = (dpHashTable*) malloc(sizeof(dpHashTable));
  initHashTable(answer, DEFAULT_HASH_TABLE_SIZE);
  return answer;
}


//If the hash table is more than a fraction GAMMA
#define GAMMA 1
inline int hTableIsFull(dpHashTable* htable) {
  return (htable->size > htable->numBuckets * GAMMA);
}


inline int hTableSize(dpHashTable* htable) {
  return htable->size;
}

static inline int hashFunction(int key,
			       int currentSize) {
  return key % currentSize;  
}



int containsPage(dpHashTable* htable, int key) {
  dpPtr answerPage = getDiskPage(htable, key);

  return ((answerPage.fileId != NULL_FILE_ID) &&
	  (answerPage.dp == UNMAPPED_PAGE));  
}

dpPtr getDiskPage(dpHashTable* htable, int key) {
  int hashIndex;
  assert((key >= 0) && (key < MAX_PAGES));
  hashIndex = hashFunction(key, htable->numBuckets);

  return searchBucket(&htable->bucketArray[hashIndex],
		      key).diskPage;
}
/* } */


void insertDiskPage(dpHashTable* htable, int key, dpPtr diskPage) {
  int hashIndex;
  dpPair answer;
  assert((key >= 0) && (key < MAX_PAGES));
  
  hashIndex = hashFunction(key, htable->numBuckets);


  answer = searchBucket(&htable->bucketArray[hashIndex], key);
  if (answer.key == NULL_KEY) {
    insertIntoBucket(&htable->bucketArray[hashIndex],
		     key,
		     diskPage);
    htable->size++;
  }
  else {
    printf("Error! Inserting element (%d, %d) with key %d when element (%d, %d) already exists.\n",
	   diskPage.fileId, diskPage.dp,
	   key,
	   answer.diskPage.fileId, answer.diskPage.dp);

    printHashTable(htable);

    assert(FALSE);
  }
}

dpPtr deleteDiskPage(dpHashTable* htable, int key) {
  int hashIndex;
  dpPair answer;
  answer.diskPage = nullPagePtr();
  assert((key >= 0) && (key < MAX_PAGES));
  
  hashIndex = hashFunction(key, htable->numBuckets);

  answer = searchBucket(&htable->bucketArray[hashIndex], key);
  if (answer.key == NULL_KEY) {
    printf("Error! trying to dleete element (%d, %d) with key %d. Doesn't exist.\n",
	   answer.diskPage.fileId, answer.diskPage.dp,
	   key);
    assert(FALSE);
  }
  else {
    deleteFromBucket(&htable->bucketArray[hashIndex],
		     key);
    htable->size--;
  }

  return answer.diskPage;
}

void destroyHashTable(dpHashTable* htable) {
  int i;
  assert(htable != NULL);
  for (i = 0; i < htable->numBuckets; i++) {
    destroyBucket(&htable->bucketArray[i]);
  }

  free(htable->bucketArray);
  free(htable);
}

void printHashTable(dpHashTable* htable) {

  int i;
  printf("************* Hash Table  ****************\n");
  printf("Size = %d,  numBuckets = %d\n", htable->size, htable->numBuckets);

  for (i = 0; i < htable->numBuckets; i++) {
    printf("Bucket %d\n", i);
    printBucket(&htable->bucketArray[i]);   
  }
  printf("*******************************************\n");
}  



int testHashTable(void) {

  int i;
  dpHashTable hTableStruct;
  dpHashTable* hTable = &hTableStruct;

  
  dpPair myPage;
  dpPair testInserts[N];
  dpPtr searchAnswer;
  int currentSeed = 10;
  printf("Testing dp hash table code.\n");


  initHashTable(hTable, DEFAULT_HASH_TABLE_SIZE);
  printHashTable(hTable);
  
  
  srand(currentSeed);
  
  myPage.diskPage.fileId = -123;
  for (i = 0; i  < N; i++) {
    int retryCount = 0;
    int repeated = FALSE;

    myPage.key = (int)(MAX_PAGES * (1.0*(rand()))/ (RAND_MAX));
    
    do {
      int j = 0;
      repeated = FALSE;
      myPage.key++;
      for (j = 0; j < i; j++) {
	if (myPage.key == testInserts[j].key) {
	  //	  printf("Bad key is %d, match at index %d\n", myPage.key, j);
	  retryCount++;
	  repeated = TRUE;
	  break;
	}
      }
    }  while (repeated);
    
    myPage.diskPage.dp = rand() % 1000;      
    testInserts[i] = myPage;

    //    printf("Inserting (%d,  %d)\n", myPage.key, myPage.diskPage.dp);
    insertDiskPage(hTable, myPage.key, myPage.diskPage);

    searchAnswer = getDiskPage(hTable, myPage.key);
    if (!(searchAnswer.dp == myPage.diskPage.dp)) {

      printf("Error! inserted (%d, %d), but found (%d, %d) instead.",
	     myPage.key, myPage.diskPage.dp,
	     myPage.key, searchAnswer.dp);
      assert(FALSE);
    }
    else {
      //      printf("Found (%d, %d).\n",
      //	     myPage.key,
      //	     searchAnswer.dp);
    }


    if ((rand() >> 16) % 11 == 0) {
      //      printf("We don't actually want (%d, %d).  Delete it \n",
      //	     testInserts[i].key,
      //	     testInserts[i].diskPage.dp);

      deleteDiskPage(hTable, testInserts[i].key);    
      searchAnswer = getDiskPage(hTable, testInserts[i].key);
      
      //      printBucket(b);
      if (! ((searchAnswer.fileId == NULL_FILE_ID) &&
	     (searchAnswer.dp == UNMAPPED_PAGE))) {
	printf("Error! Deleted (%d, %d), but still found (%d, %d)\n",
	       testInserts[i].key,
	       testInserts[i].diskPage.dp,
	       testInserts[i].key,
	       searchAnswer.dp);
	assert(FALSE);
      }

      i--; 
    }
  }

  for (i = 0; i < N; i++) {
    myPage = testInserts[i];
    searchAnswer = getDiskPage(hTable, myPage.key);

    if (!((searchAnswer.dp == myPage.diskPage.dp))) {

      printf("Error! inserted (%d, %d), but found (%d, %d) instead.",
	     myPage.key, myPage.diskPage.dp,
	     myPage.key, searchAnswer.dp);
      assert(FALSE);
    }
  }

  printf("Finished insert test.\n");
  printHashTable(hTable);
  for (i = 0; i < N; i++) {
    //    printf("Deleting element (%d, %d)\n", testInserts[i].key, testInserts[i].diskPage.dp);
    deleteDiskPage(hTable, testInserts[i].key);
    searchAnswer = getDiskPage(hTable, testInserts[i].key);

    if (! ((searchAnswer.fileId == NULL_FILE_ID) &&
	   (searchAnswer.dp == UNMAPPED_PAGE))) {
      printf("Error! Deleted (%d, %d), but still found (%d, %d)\n",
	     testInserts[i].key,
	     testInserts[i].diskPage.dp,
	     testInserts[i].key, 
	     searchAnswer.dp);
      printHashTable(hTable);
      assert(FALSE);
    }          
  }

  
  
  printf("Successfully completed all tests on hash table insert/search/delete.\n");
      
  return 0;
}


//int main(void) {
//  testHashTable();
//  return 0;
//}
