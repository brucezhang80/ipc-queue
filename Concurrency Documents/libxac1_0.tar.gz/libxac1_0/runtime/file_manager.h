/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * file_manager.h
 *  
 *  Contains all the low-level routines that actually open/close files,
 *   calls mmap, fsync, etc.
 *
 *  Actually handles open/close of all the following:
 *    user file (only one supported at the moment)
 *    page log file:  the temporary file we use for mmaping temporary pages
 *    commit file:  the file that represents the actual log for committed transactions.
 */

#ifndef __FILE_MANAGER
#define __FILE_MANAGER

#include "basics.h"
#include "commitBuffer.h"
#include "lockTest.h"
#include "logData.h"

#include "diskPageHashTable.h"

#include "cycle_counter.h"
#include "local_file_dir.h"

#define FILE_NAME_LENGTH 100
#define MAX_NUM_USER_FILES 1
//#define MAX_NUM_LOG_FILES 10
#define NULL_FILE -1

#define USER_FILE_ID 0


#define PAGE_LOG_ID 10
#define START_COMMIT_FILE_ID 20


//#define DISPLAY_REF_COUNT_MESSAGES

#ifdef DISPLAY_REF_COUNT_MESSAGES
#define REF_CT_PRINT fprintf
#else
#define REF_CT_PRINT emptyLogPrint
#endif




/**
 * A different mappedFileData structure is  kept for each 
 *  process that has attached the system.
 */

typedef struct mappedFileData {
  
  int userFileFd[MAX_NUM_USER_FILES];        // The file descriptor for the user's file.
  void* userFileRegion[MAX_NUM_USER_FILES];  //  pointer returned by mmaping the user's file.

  int commitFileFd;                       // File descriptor for the current commit file
  int myCurrentCommitFileId;              // The value that this process thinks is the current commit file id.
  size_t commitFileLength;
  
  
  int pageLogFileId;                      // File id corresponding to
                                          //  the actual page log files
  int pageLogFileFd;                      // The file descriptors for open log files.

  //#ifdef USE_MMAP_LOG_FILES
  int logFileMmappedLength;
  void* logFileRegion;
  //#endif

  void* theMmapRegion;   // This is the address the programmer gets for the mmaped region.

  dpHashTable* readSourceTable;
  // When a process writes to a new page, this hash table for each
  // process records the dpPtr corresponding to the page we read from

#ifdef DO_TIMINGS
  timeStruct writeT1;
  timeStruct writeT2;
  int numWrites;
  double writeTime;

  timeStruct otherT1;
  timeStruct otherT2;
  double mfdOtherTime;
  int mfdNumOthers;
  double mfdMaxTime;
#endif


} mappedFileData; 



/*************************************************************/
// File management


typedef enum {INACTIVE, ACTIVE, FULL, COPIED_BACK, ON_DISK, DELETED} fileStatus;

typedef struct fileInfo {
  char name[FILE_NAME_LENGTH];
  int fileId;
  int length;
  fileStatus status;
  
} fileInfo;


#define MAX_PAGELOG_SIZE MAX_PAGES*4

/**
 * One globalLogFileInfo structure is needed for the entire
 *  system.
 */
typedef struct globalLogFileInfo {

  fileInfo userFileInfo[MAX_NUM_USER_FILES];     // Information for the file the user is opening.
  int userFileInUse[MAX_NUM_USER_FILES];  // Flag recording whether
                                          //  user file has been added to system or not.
  
  fileInfo currentCommitFileInfo;         //  The information about the log file storing the commit record.
  size_t currentCommitFileLengthUsed;
  
  fileInfo pageLogFileInfo;               // Information on the page log file.


  char control_path[FILE_NAME_LENGTH];    // The char storing the path for the commit/control files.

  
  int refCount[MAX_PAGELOG_SIZE];
  int freeList[MAX_PAGELOG_SIZE];
  int freeListTop;
  int freeListEnd;
  

  Cilk_lockvar* logManagerLock;
  //  int latestPageLogFile;
  int durableXactions;


#ifdef DO_TIMINGS
  double lockTime;
  int numLocks;
#endif
  
} globalLogFileInfo;



void acquireLogManagerLock(globalLogFileInfo* glf);
void releaseLogManagerLock(globalLogFileInfo* glf);

/**
 * This function should be called once, when we are initializing
 *  the entire system.
 */
void initGlobalLogFileInfo(globalLogFileInfo* glf,
			   int isDurable,
			   const char* control_prefix);



/******************************************************************/
/** These functions should be called when each process is attaching or
 *   detaching from the system.
 */

// The server_open  function performs the part  the open operation
//  modifies global information, i.e., stores the name of the file
//  we are working with.
void server_open_user_file(globalLogFileInfo* glf,
			   const char* userFileName,
			   int numPages,
			   global_file_info* file_info);
// The local_open performs the part of the open operation that
//  doesn't use global information, i.e., the actual calls to
//  open and mmap
void local_open_user_file(mappedFileData* mfd,
			  global_file_info* file_info);

void server_close_user_file(globalLogFileInfo* glf,
			    const char* userFileName,
			    global_file_info* file_info);
void local_close_user_file(mappedFileData* mfd,
			   global_file_info* file_info);



void openLogFiles(globalLogFileInfo* glf, mappedFileData* mfd);
void closeLogFiles(globalLogFileInfo* glf, mappedFileData* mfd);
/******************************************************************/

/******************************************************************/
// These functions actually make the mmap and munmap system calls.
void mmapDiskPage(mappedFileData* mfd,
		  int pageNumber,
		  dpPtr diskPage,
		  int memProt);

/* void munmapDiskPage(mappedFileData* mfd, */
/* 		    int pageNumber); */
/******************************************************************/


/******************************************************************/
// Functions moving data between the log and user files.

/**
 * Creates new pages in the log file, initialized with the contents
 *  stored at memoryRange.  Returns a pointer to the first page
 *  of the range created.
 */
dpPtr writeNewPagesToLogFile(globalLogFileInfo* glf,
			     mappedFileData* mfd,
			     void* memoryRange,
			     int numPages,
			     dpPtr pageToCopy);

/**
 * Copies the contents of the log pages starting at diskSourceStart, 
 *  back into the original user file.
 */
void copyRangeToUserFile(globalLogFileInfo* glf,
			 mappedFileData* mfd,
			 int xactionPageStart,
			 dpPtr diskSourceStart,
			 int numPages);


/******************************************************************/
// Returns a pointer to the specified disk page from the user file.
dpPtr createUserFilePtr(int dp);

/******************************************************************/


/******************************************************************/
//  Functions for the appropriate counts for the page log file.  
void incRefCount(globalLogFileInfo* glf, dpPtr diskPage);
void decRefCount(globalLogFileInfo* glf, dpPtr diskPage);
/******************************************************************/




/******************************************************************/
// Functions for logging things to the commit file.



void computePageDiff(TID currentXId,
		     localCommitBuffer* lcbf,
		     mappedFileData*mfd,
		     dpPtr diskPage,
		     int pageNum,
		     void* buffer,
		     size_t bufferSize,
		     size_t *n_bytes_written /* Fill in n_bytes_written with the number of bytes actually written. */
		     );


void writeDataToCommitFile(globalLogFileInfo* glf,
			   TID currentXId,
			   localCommitBuffer* lcbf, 
			   mappedFileData* mfd,
			   void* buffer, int numBytes);


/******************************************************************/
// Functions for synching the files to disk.
void syncCurrentCommitRecord(globalLogFileInfo* glf,
			     mappedFileData* mfd);

void syncUserFile(globalLogFileInfo* glf, mappedFileData* mfd);

/******************************************************************/


/******************************************************************/
// Functions manipulating the read source table

void addPageToReadSourceTable(mappedFileData* mfd, int virtualPageNum, dpPtr diskPage);
dpPtr removePageFromReadSourceTable(mappedFileData* mfd, int virtualPageNum);
dpPtr getPageFromReadSourceTable(mappedFileData* mfd, int virtualPageNum);
int numPagesInReadSourceTable(mappedFileData* mfd);




/******************************************************************/
// Print functions for debugging
void printFinalRefCounts(globalLogFileInfo* glf);
void emptyLogPrint(FILE* file, ...);
/******************************************************************/

#endif


