/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * xDep.c
 *
 */

#include <assert.h>
#include <stdio.h>
#include <unistd.h>

#include "cycle_counter.h"
#include "xDep.h"
#include "xactionInfo.h"


//#define DO_INV_CHECKS

int validDepList(xDepTree* t, int indx) {
  int i,j;
  for (i = 0; i < t->lists[indx].length; i++) {
    j = t->lists[indx].v[i];
    if (t->parent[j] != indx) {
      printf("Error in list index %d: element %d has wrong parent %d.\n",
	     indx,
	     j,
	     t->parent[j]);
      return FALSE;
    }
  }
  return TRUE;
}

static int validDepTreeFreeList(xDepTree* t) {
  int i, j;
  for (i = t->lFreeTop; i < NUM_LISTS; i++) {
    for (j = i+1; j < NUM_LISTS; j++) {
      if (t->lFreeList[i] == t->lFreeList[j]) {
	printf("Error! element %d = element %d = %d\n", i, j, t->lFreeList[i]);
	outputDepTree(t);
	sleep(1000);
	return FALSE;
      }
    }
  }

  for (i = t->lFreeTop; i < NUM_LISTS; i++) {
    for (j = 0; j < MAX_XACTIONS+1; j++) {
      //      if (t->isCommitted[j]) {
	if ((t->lFreeList[i] == t->pendingListPtr[j])) {
	  printf("Error! free list has %d even though id %d has it as pending.\n",
		 t->lFreeList[i],
		 j);
	  outputDepTree(t);
	  sleep(1000);
	  assert(FALSE);
	  return FALSE;
	}

	if ((t->lFreeList[i] == t->failedListPtr[j])) {
	  printf("Error! free list has %d even though id %d has it as failed.\n",
		 t->lFreeList[i],
		 j);
	  outputDepTree(t);
	  assert(FALSE);
	  return FALSE;
	}

    }
    //    }
  }
  return TRUE;
}

int validDepTree(xDepTree* t) {
  int i, j;
  int prev;
  int numCommitted =0;
  int numCheck;

#ifndef DO_INV_CHECKS
  assert(FALSE);
#endif
  //Check number of committed xactions,
  for (i = 0; i < MAX_XACTIONS+1; i++) {
    if (t->isCommitted[i]) {
      //      printf("%d is committed\n", i);
      numCommitted++;
    }
  }

  i = 0;
  numCheck = 1;
  if (t->parent[0] != NULL_ID) {
    printf("Error! parent[0] is not %d\n", NULL_ID);
    return FALSE;
  }

  while (t->next[i] != NULL_ID) {
    prev = i;
    i = t->next[i];
    numCheck++;
    if (t->parent[i] != prev) {
      printf("Error! parent(%d) is not %d\n",i, prev);
      outputDepTree(t);
      printf("My pid is %d\n", getpid());
      sleep(1000);
    }
  }

  if (numCheck != numCommitted) {
    printf("Error! isCommitted array says %d committed xactions, tree says %d\n",
	   numCommitted,
	   numCheck);
    return FALSE;
  }


  i = 0;
  while (t->next[i] != NULL_ID) {
    int error = FALSE;
    if (t->pendingListPtr[i] != NULL_LIST) {
      error = !validDepList(t, t->pendingListPtr[i]);
    }

    if (t->failedListPtr[i] != NULL_LIST) {
      error = error || !validDepList(t, t->failedListPtr[i]);
    }
    
    i = t->next[i];
    if (error) {
      printf("error in the lists for %d\n", i);
      return error;
    } 
  }


  for (i = 0; i < NUM_LISTS; i++) {
    if (!validDepList(t, i)) {
      printf("Error! invalid dep list at index %d\n", i);
      return FALSE;
    }
    //    printf("Valid dep list at %d\n", i);
  }


  if (!validDepTreeFreeList(t)) {
    printf("Error! dep. tree has invalid free list.\n");
    return FALSE;
  }

  for (i = 0; i < MAX_XACTIONS+1; i++) {
    if (t->pendingListPtr[i] != NULL_LIST) {
      for (j = i+1; j < MAX_XACTIONS+1; j++) {
	if (t->pendingListPtr[j] == t->pendingListPtr[i]) {
	  printf("Error! pendingListPtr[%d] = plp[%d] = %d\n", j, i, t->pendingListPtr[i]);
	  return FALSE;
	}
      }
      for (j = 0; j < MAX_XACTIONS+1; j++) {
	if (t->failedListPtr[j] == t->pendingListPtr[i]) {
	  printf("Error! failedListPtr[%d] = plp[%d] = %d\n", j, i, t->pendingListPtr[i]);
	  return FALSE;
	}
      }
    }
  }


  for (i = 0; i < MAX_XACTIONS+1; i++) {
    if (t->failedListPtr[i] != NULL_LIST) {
      for (j = i+1; j < MAX_XACTIONS+1; j++) {
	if (t->failedListPtr[j] == t->failedListPtr[i]) {
	  printf("Error! failedListPtr[%d] = flp[%d] = %d\n", j, i, t->failedListPtr[i]);
	  return FALSE;
	}
      }
      for (j = 0; j < MAX_XACTIONS+1; j++) {
	if (t->pendingListPtr[j] == t->failedListPtr[i]) {
	  printf("Error! pendingListPtr[%d] = flp[%d] = %d\n", j, i, t->failedListPtr[i]);
	  return FALSE;
	}
      }
    }
  }

  for (i = 0; i < MAX_XACTIONS+1; i++) {
    if (t->readOnlyListPtr[i] != NULL_LIST) {
      for (j = i+1; j < MAX_XACTIONS+1; j++) {
	if (t->readOnlyListPtr[j] == t->failedListPtr[i]) {
	  printf("Error! readOnlyListPtr[%d] = flp[%d] = %d\n", j, i, t->failedListPtr[i]);
	  return FALSE;
	}
      }
      for (j = 0; j < MAX_XACTIONS+1; j++) {
	if (t->readOnlyListPtr[j] == t->pendingListPtr[i]) {
	  printf("Error! readOnlyListPtr[%d] = flp[%d] = %d\n", j, i, t->failedListPtr[i]);
	  return FALSE;
	}
      }
    }
  }


  return TRUE;
}


void outputDepList(xDepList* w) {
  int i = 0;
  printf("# ");
  while (i < w->length) {
    printf("%d ", w->v[i]);
    i++;
  }
  printf(" #");
}




void outputDepTree(xDepTree* t) {
  int i = 0;
  printf("***********************\n");
  printf("Tree %p:  \n", t);
  if (t != NULL) {
    while (i != NULL_ID) {
      printf("%d:  (parent %d, next %d, isCom=%d  pList %d   fList %d). ", i,
	     t->parent[i], t->next[i], t->isCommitted[i],
	     t->pendingListPtr[i],
	     t->failedListPtr[i]);
      printf("\n    pending = ");
      if (t->pendingListPtr[i] != NULL_LIST) {
	outputDepList(&t->lists[t->pendingListPtr[i]]);
      }
      else {
	printf(" NULL");
      }
      printf("   failed = ");
      if (t->failedListPtr[i] != NULL_LIST) {
	outputDepList(&t->lists[t->failedListPtr[i]]);
      }
      else {
	printf(" NULL");
      }

      printf("   readOnly = ");
      if (t->readOnlyListPtr[i] != NULL_LIST) {
	outputDepList(&t->lists[t->readOnlyListPtr[i]]);
      }
      else {
	printf(" NULL");
      }
      printf("\n");
      i = t->next[i];
    }

    printf("\n");
    printf("Last Committed = %d\n", t->lastCommitted);
    printf("Free List: ");
    for (i = t->lFreeTop; i < NUM_LISTS; i++) {
      printf("%d  ", t->lFreeList[i]);
    }
    printf("\n");
  }
  printf("***********************\n\n");
}
void initDepTree(xDepTree* t) {
  int i, j;

  for (i = 0; i < MAX_XACTIONS+1; i++) {
    t->parent[i] = NULL_ID;
    t->next[i] = NULL_ID;
    t->pendingListPtr[i] = NULL_LIST;
    t->failedListPtr[i] = NULL_LIST;
    t->isCommitted[i] = FALSE;
    
    t->readOnlyListPtr[i] = i;
  }

  // Init. the readonly lists correctly...
  for (j = 0; j < MAX_XACTIONS + 1; j++) {
    t->lists[j].length = 0;
    t->lists[j].parent = j;
  }

  for (j = MAX_XACTIONS+1; j < NUM_LISTS; j++) {
    t->lists[j].length = 0;
    t->lists[j].parent = NULL_ID;
    t->lFreeList[j] = j;
  }
  t->lFreeTop = MAX_XACTIONS+1;

  t->isCommitted[0] = TRUE;
  t->lastCommitted = 0;

  //  printf("the initialized dep tree...\n");
  //  outputDepTree(t);
}


static inline void transferContents(xDepTree* t, int sourceIndex, int destIndex) {
  int i, j;
  xDepList* source = &t->lists[sourceIndex];
  xDepList* dest = &t->lists[destIndex];

  j = dest->length;
  for (i = source->length-1; i >= 0; i--) {
    dest->v[j] = source->v[i];
    t->parent[dest->v[j]] = destIndex;
    j++;
  }
  dest->length = j;
  source->length = 0;
}

static inline void addToDepList(xDepList* w, int value) {
  if (w->length >= MAX_XACTIONS) {
    printf("error!! w->length is %d. we are trying to add %d\n", w->length, value);
    sleep(1000);
  }
  assert(w->length < MAX_XACTIONS);
  w->v[w->length] = value;
  w->length++;
}

static inline int removeFromDepList(xDepList* w, int value) {
  int i = 0;
  if (w->length > 0) {
    while (i < w->length) {
      if (w->v[i] == value) {
	break;
      }
      i++;
    }

    // if we find it shift everything over.
    if (i != w->length) {
      int j;
      for (j = i+1; j < w->length; j++) {
	w->v[j-1] = w->v[j];
      }
      w->length--;
      return value;
    }
    else {
      printf("We just searched for %d. didn't find it...\n", value);
      assert(FALSE);
      return NULL_ID;
    }
  }
  else {
    printf("We just searched for %d here. didn't find it...\n", value);
    assert(FALSE);
    return NULL_ID;
  } 
}

static inline int getFreeDepIndex(xDepTree* t) {
   int newListPtr;
   //   assert(validDepTreeFreeList(t));
   assert(t->lFreeTop < NUM_LISTS);
   newListPtr = t->lFreeList[t->lFreeTop];
   t->lFreeTop++;
   //   assert(validDepTreeFreeList(t));
   return newListPtr;
}

static inline void returnFreeDepIndex(xDepTree* t, int freeVal) {
  //  assert(validDepTreeFreeList(t));
  if (t->lFreeTop == 0) {
    printf("Error! trying to return a list %d that we don't have space for...\n", freeVal);
    outputDepTree(t);
  }
  assert(t->lFreeTop > 0);
  t->lFreeTop--;
  t->lFreeList[t->lFreeTop] = freeVal;
  //  assert(validDepTreeFreeList(t));
}

void addPending(xDepTree* t, int id, int parent) {
  assert((id <= MAX_XACTIONS) && (parent <= MAX_XACTIONS));

#ifdef DO_INV_CHECKS
  if (!t->isCommitted[parent]) {
    printf("error! adding id %d to parent %d failing. \n", id, parent);
    outputDepTree(t);
  }
  if (!validDepTree(t)) {
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }

  assert(t->isCommitted[parent] == TRUE);
  assert(t->isCommitted[id] == FALSE);
#endif

  //  assert(t->pendingListPtr[parent] == NULL_LIST);
  //  assert(t->failedListPtr[parent] == NULL_LIST);
  if (t->pendingListPtr[parent] == NULL_LIST) {
    t->pendingListPtr[parent] = getFreeDepIndex(t);
    t->lists[t->pendingListPtr[parent]].parent = parent;
  }

  // Add it to the pending list.
  addToDepList(&t->lists[t->pendingListPtr[parent]], id);
  t->parent[id] = t->pendingListPtr[parent];

#ifdef DO_INV_CHECKS
  if (!validDepTree(t)) {
    printf("Error! not a valid dep tree here... \n");
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
#endif
}


void addReadOnly(xDepTree* t, int id, int parent) {
  assert((id <= MAX_XACTIONS) && (parent <= MAX_XACTIONS));

#ifdef DO_INV_CHECKS
  if (!t->isCommitted[parent]) {
    printf("error! adding id %d to parent %d failing. \n", id, parent);
    outputDepTree(t);
  }
  if (!validDepTree(t)) {
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
  
  assert(t->isCommitted[parent] == TRUE);
  assert(t->isCommitted[id] == FALSE);
#endif

  // We should never reallocate readOnly stuff.  For now....
  assert(t->readOnlyListPtr[parent] != NULL_LIST);
  
  // Add it to the read-only list.
  addToDepList(&t->lists[t->readOnlyListPtr[parent]], id);
  t->parent[id] = t->readOnlyListPtr[parent];
  
#ifdef DO_INV_CHECKS
  if (!validDepTree(t)) {
    printf("Error! not a valid dep tree here... \n");
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
#endif
}




int failXaction(xDepTree* t, int id) {
  int listIndex = t->parent[id];
  int parent = t->lists[listIndex].parent;
  xDepList* wp;
  xDepList* wf;


  //  printf("Before failing xaction %d, here is the dep tree.\n", id);
  //  outputDepTree(t);
  //  printf("############\n");
#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
  assert(parent == t->lists[listIndex].parent);
  if (t->pendingListPtr[parent] == NULL_LIST) {
    printf("Error. failing an xaction that doesn't have a proper parent...wtf?\n");
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
  
  assert(t->pendingListPtr[parent] != NULL_LIST);
  if (!((t->pendingListPtr[id] == NULL_LIST) ||
	(t->lists[t->pendingListPtr[id]].length == 0))) {
    printf("Error. failing an xaction %d with children. wtf?\n", id);
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }

  if (!((t->failedListPtr[id] == NULL_LIST) ||
	(t->lists[t->failedListPtr[id]].length == 0))) {
    printf("Error. failing an xaction with children. wtf?\n");
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
#endif

  wp= &t->lists[t->pendingListPtr[parent]];

  if (t->failedListPtr[parent] == NULL_LIST) {
    // No failed xactions.
    if (wp->length == 1) {
      // just move entire list over.
      t->failedListPtr[parent] = t->pendingListPtr[parent];
      t->pendingListPtr[parent] = NULL_LIST;
    }
    else {
      t->failedListPtr[parent] = getFreeDepIndex(t);
      t->lists[t->failedListPtr[parent]].parent = parent;
      removeFromDepList(wp, id);
      addToDepList(&t->lists[t->failedListPtr[parent]], id);
      t->parent[id] = t->failedListPtr[parent];
    }
  }
  else {
    wf= &t->lists[t->failedListPtr[parent]];
    removeFromDepList(wp, id);
    addToDepList(wf, id);
    t->parent[id] = t->failedListPtr[parent];
  }

#ifdef DO_INV_CHECKS
  if (!validDepTree(t)) {
    printf("Error in failing xaction. not a valid dep tree after... \n");
    sleep(1000);
  }
  assert(validDepTree(t));
#endif
  return 0;
}

int commitXaction(xDepTree* t, int id) {
  int listIndex = t->parent[id];
  int parent = t->lists[listIndex].parent;
  xDepList* wp;

  assert(t->pendingListPtr[parent] != NULL_LIST);


  if (t->isCommitted[id]) {
    printf("Error! trying to commit xaction %d, when flag is wrong.\n", id);
    outputDepTree(t);
  }
  assert(!t->isCommitted[id]);
  wp= &t->lists[t->pendingListPtr[parent]];

  removeFromDepList(wp, id);

  // Make id the next node in the committed chain.
  t->parent[id] = t->lastCommitted;
  t->isCommitted[id] = TRUE;
  t->next[id] = NULL_ID;
  assert(t->next[t->lastCommitted] == NULL_ID);
  t->next[t->lastCommitted] = id;

  if ((t->pendingListPtr[id] != NULL_LIST) &&
      (t->lists[t->pendingListPtr[id]].length != 0)) {
    printf("Error here at id's list... %d! \n", id);
    outputDepTree(t);
  }
					     
  assert((t->pendingListPtr[id] == NULL_LIST) ||
	 (t->lists[t->pendingListPtr[id]].length == 0));

  assert((t->failedListPtr[id] == NULL_LIST) ||
	 (t->lists[t->failedListPtr[id]].length == 0));

  t->lastCommitted = id;

  return 0;
}

int commitReadOnly(xDepTree* t, int id) {
  int listIndex = t->parent[id];
  int parent = t->lists[listIndex].parent;
  xDepList* wp;
  
  assert(t->readOnlyListPtr[parent] != NULL_LIST);
  
  if (t->isCommitted[id]) {
    printf("Error! trying to commit xaction %d, when flag is wrong.\n", id);
    outputDepTree(t);
  }
  assert(!t->isCommitted[id]);
  wp= &t->lists[t->readOnlyListPtr[parent]];

  removeFromDepList(wp, id);

  // Just get rid of it...  In this sense, its like an abort.
  t->parent[id] = NULL_LIST;

#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
#endif
  return 0;
}

int abortXaction(xDepTree* t, int id) {
  int listIndex = t->parent[id];
  int parent = t->lists[listIndex].parent;
#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
  assert(t->isCommitted[id] == FALSE);
  assert(t->failedListPtr[parent] != NULL_LIST);
#endif

  removeFromDepList(&t->lists[t->failedListPtr[parent]], id);

  t->parent[id] = NULL_LIST;

  assert(t->pendingListPtr[id] == NULL_LIST);
  assert(t->failedListPtr[id] == NULL_LIST);
#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
#endif
  return 0;
}


int mergeIntoParent(xDepTree* t, int id) {
  int parent = t->parent[id];

#ifdef DO_INV_CHECKS
  assert(t->isCommitted[id]);
  assert(t->isCommitted[parent]);

  
  assert((t->pendingListPtr[parent] == NULL_LIST) ||
	 (t->lists[t->pendingListPtr[parent]].length == 0));

  assert((t->failedListPtr[parent] == NULL_LIST) ||
	 (t->lists[t->failedListPtr[parent]].length == 0));

  assert(validDepTree(t));
  assert(validDepTreeFreeList(t));
#endif

  //  outputDepTree(t);
  if (t->pendingListPtr[parent] != NULL_LIST) {
    //    printf("Calling merge with id %d\n", id);
    //    outputDepTree(t);

    returnFreeDepIndex(t, t->pendingListPtr[parent]);
    t->pendingListPtr[parent] = NULL_LIST;
  }

  assert((t->failedListPtr[parent] == NULL_LIST) ||
	 (t->lists[t->failedListPtr[parent]].length == 0));

  if (t->failedListPtr[parent] != NULL_LIST) {
    //    printf("Calling merge with id. failed ptrs this time %d\n", id);
    //    outputDepTree(t);

    returnFreeDepIndex(t, t->failedListPtr[parent]);
    t->failedListPtr[parent] = NULL_LIST;
  }

  //  if (!validDepTree(t)) {
  //    printf("Error! not a valid dep tree here... \n");
  //    outputDepTree(t);
  //    assert(FALSE);
  //  }

  //  assert(validDepTreeFreeList(t));

  t->next[parent] = t->next[id];

  if (t->next[id] != NULL_ID) {
    // If there is a element after "id", set its prev. pointer to be "parent"
    assert(t->parent[id] == parent);
    t->parent[t->next[id]] = t->parent[id];
  }

  t->pendingListPtr[parent] = t->pendingListPtr[id];
  if (t->pendingListPtr[parent] != NULL_LIST) {
    t->lists[t->pendingListPtr[parent]].parent = parent;
  }
  t->pendingListPtr[id] = NULL_LIST;

  t->failedListPtr[parent] = t->failedListPtr[id];
  if (t->failedListPtr[parent] != NULL_LIST) {
    t->lists[t->failedListPtr[parent]].parent = parent;
  }
  t->failedListPtr[id] = NULL_LIST;

  t->isCommitted[id] = FALSE;
  if (t->lastCommitted == id) {
    t->lastCommitted = parent;
  }

#ifdef DO_INV_CHECKS
  assert(validDepTreeFreeList(t));
  assert(validDepTree(t));
#endif

  return 0;
}

int movePendingDepList(xDepTree*t, int sourceId, int destId) {
  int sIndex, dIndex;
  assert(t->isCommitted[sourceId]);
  assert(t->isCommitted[destId]);

#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
#endif

  sIndex = t->pendingListPtr[sourceId];
  dIndex = t->pendingListPtr[destId];
  
  if (sIndex != NULL_LIST) {
    // If dest. doesn't have any items, just move entire list
    if (dIndex == NULL_LIST) {
      t->pendingListPtr[sourceId] = NULL_LIST;
      t->pendingListPtr[destId] = sIndex;
      t->lists[sIndex].parent = destId;
    }
    else {
      // Merge the smaller into the larger
      if (t->lists[sIndex].length < t->lists[dIndex].length) {
	transferContents(t, sIndex, dIndex);
	//	transferContents(&t->lists[sIndex], &t->lists[dIndex]);
      }
      else {
	transferContents(t, dIndex, sIndex);
	//	transferContents(&t->lists[dIndex], &t->lists[sIndex]);

	// swap the two lists
	t->pendingListPtr[destId] = sIndex;
	t->lists[sIndex].parent = destId;

	t->pendingListPtr[sourceId] = dIndex;
	t->lists[dIndex].parent = sourceId;
      }      
    }
  }

#ifdef DO_INV_CHECKS
  assert(validDepTree(t));
#endif

  return 0;
}

int checkValues(void);

int checkValues(void) {

  timeStruct rt0, rt1;
  xDepTree h;
  xDepTree* t = &h;

  setupTimers();
  initDepTree(t);
  printf("Does this do anything? it prints...\n");

  outputDepTree(t);

  addPending(t, 1, 0);
  outputDepTree(t);

  printf("failing 1\n");
  failXaction(t, 1);
  outputDepTree(t);

  addPending(t, 2, 0);
  addPending(t, 3, 0);
  addPending(t, 4, 0);
  outputDepTree(t);
  printf("Failing 2\n");
  failXaction(t, 2);
  printf("Committing 4. \n");
  commitXaction(t, 4);

  outputDepTree(t);
  printf("Failing 3. \n");
  failXaction(t, 3);

  printf("Aborting 2. \n");
  abortXaction(t, 2);
  outputDepTree(t);


  printf("Adding 5, 6 to 4\n");
  addPending(t, 5, 4);
  addPending(t, 6, 4);
  outputDepTree(t);

  printf("Committing 5\n");
  commitXaction(t, 5);
  outputDepTree(t);

  printf("Extending 5\n");
  addPending(t, 7, 5);
  addPending(t, 8, 5);
  failXaction(t, 7);
  failXaction(t, 6);
  abortXaction(t, 6);
  outputDepTree(t);


  assert(validDepTree(t));

  printf("Merging 5.\n");
  checkTimer(&rt0);
  mergeIntoParent(t, 5);
  checkTimer(&rt1);


  reportTime("Merge time", timeDiff(rt0, rt1), 1);
  outputDepTree(t);

  assert(validDepTree(t));  

  addPending(t, 9, 0);
  printf("Added 9... \n");
  outputDepTree(t);
  commitXaction(t, 9);

  printf("After commit 9\n");
  outputDepTree(t);
  addPending(t, 2, 0);
  addPending(t, 6, 0);
  addPending(t, 10, 0);

  printf("Before movePending.\n");
  outputDepTree(t);


  assert(validDepTree(t));
  movePendingDepList(t, 0, 9);
  printf("After move to 9.\n");
  outputDepTree(t);


  assert(validDepTree(t));
  movePendingDepList(t, 9, 4);
  printf("After move to 4.\n");
  outputDepTree(t);

  assert(validDepTree(t));
  movePendingDepList(t, 4, 9);
  printf("After move back to 9.\n");
  outputDepTree(t);

  assert(validDepTree(t));
  abortXaction(t, 1);
  addPending(t, 1, 4);
  printf("Adding new 1.\n");
  outputDepTree(t);
  assert(validDepTree(t));

  movePendingDepList(t, 4, 9);
  printf("After moving 4 to 9\n");
  outputDepTree(t);


  assert(validDepTree(t));
  return 0;
}


int getCommittedChild(xDepTree* t, int id) {
  if (t->isCommitted[id]) {
    assert(t->isCommitted[t->next[id]]);
    return t->next[id];
  }
  else {
    int lIndex = t->parent[id];
    assert(lIndex != NULL_LIST);
    return t->next[t->lists[lIndex].parent];
  }
}

int getCommittedParent(xDepTree* t, int id) {
  if (t->isCommitted[id]) {
    return t->parent[id];
  }
  else {
    int lIndex = t->parent[id];
    assert(lIndex != NULL_LIST);
    return t->lists[lIndex].parent;
  }
}


void movePendingListToEnd(xDepTree* t, int id) {
  //  assert(t->isCommitted[id]);
  if (id != t->lastCommitted) {
    if (t->pendingListPtr[id] != NULL_LIST) {
      movePendingDepList(t, id, t->lastCommitted);      
    }
  }
}

int hasActiveChildren(xDepTree* t, int id) {

#ifdef DO_INV_CHECKS
  if (!validDepTree(t)) {
    printf("EERROR HERE!! \n");
    outputDepTree(t);
    sleep(1000);
  }
  assert(validDepTree(t));
#endif
  
  if (!t->isCommitted[id]) {
    fprintf(stderr, "Error! id = %d not committed\n", id);
    outputDepTree(t);
    sleep(1000);
    assert(FALSE);
  }
  assert(t->isCommitted[id]);
  if ( ((t->pendingListPtr[id] != NULL_LIST) &&
	(t->lists[t->pendingListPtr[id]].length > 0))) {
    return TRUE;
  }
  if ( ((t->failedListPtr[id] != NULL_LIST) &&
	(t->lists[t->failedListPtr[id]].length > 0))) {
    return TRUE;
  }
  
  if ( ((t->readOnlyListPtr[id] != NULL_LIST) &&
	(t->lists[t->readOnlyListPtr[id]].length > 0))) {
    return TRUE;
  }
  return FALSE;
}


// Returns the youngest (committed) transaction, starting at id, that
// does not have an active child and is not COMMITTED_ON_DISK.  This
// is the transaction that will get merged into id, if id has no
// active children and if id is COMMITED_ON_DISK
int forwardActiveChildrenQuery(xactionContext* xc, int id) {

  int prev;
  int current = id;
  
  //  printf("forward query: id = %d has status =  %d, hasActivechildre = %d\n",
  //	 id, getXactionStatus(xc, id), hasActiveChildren(xc->t, id));
  
  if ((getXactionStatus(xc, id) != COMMITTED_ON_DISK)
      || (hasActiveChildren(xc->t, id))
      || (id == xc->t->lastCommitted)) {
    return id;
  }

  if (id == xc->t->lastCommitted) {
    return id;
  }

  
  prev = id;
  current = xc->t->next[id];
  while (current != xc->t->lastCommitted) {
    if ((getXactionStatus(xc, current) != COMMITTED_ON_DISK)
	|| (hasActiveChildren(xc->t, current))) {
      return prev;
    }
    else {
      prev = current;
      current = xc->t->next[current];
    }    
  }



  if ((getXactionStatus(xc, current) == COMMITTED_ON_DISK)
      && (!hasActiveChildren(xc->t, current))) {
    return current;
  }
  else {
    return prev;
  }
  
/*   while (current != xc->t->lastCommitted) { */
/*     if ((getXactionStatus(xc, current) != COMMITTED_ON_DISK)   // Check this condition first. */
/* 	|| (hasActiveChildren(xc->t, current))) { */
/*       printf("forward: current: id = %d has status =  %d, hasActivechildre = %d\n", */
/* 	     current, getXactionStatus(xc, current), hasActiveChildren(xc->t, current)); */
/*       return prev; */
/*     } */
/*     prev = current; */
/*     current = xc->t->next[current]; */
/*   } */
/*   return prev; */
  //  return current;
}

// Returns the oldest transaction, starting at id, that has no active
// children and which is COMMITTED_ON_DISK.  This corresponds to the
// transaction we can merge id into, assuming id also satisfies these properties.

int backwardActiveChildrenQuery(xactionContext* xc, int id) {
  if (id != 0) {
    int current = id;
    int myParent = xc->t->parent[current];

    if ((getXactionStatus(xc, id) != COMMITTED_ON_DISK) ||
	(hasActiveChildren(xc->t, id))) {
      return id;
    }


    while ((getXactionStatus(xc, myParent) == COMMITTED_ON_DISK)
	   && (!hasActiveChildren(xc->t, myParent))
	   && (myParent != 0)) {
      current = myParent;
      myParent = xc->t->parent[myParent];
    }

    if ((myParent == 0)
	&& (!hasActiveChildren(xc->t, 0))) {
      return 0;
    }
    else {
      return current;
    }
  }
  else {
    return 0;
  }
}
/*     while ((getXactionStatus(xc, myParent) == COMMITTED_ON_DISK) */
/* 	   && (!hasActiveChildren(xc->t, myParent)) */
/* 	   && (current != 0)) { */
/*       //    printf("working on id = %d\n", myParent); */

/*       printf("backward: current: id = %d has status =  %d, hasActivechildre = %d\n", */
/* 	     current, getXactionStatus(xc, current), hasActiveChildren(xc->t, current)); */
      
/*       printf("backward: myParent: id = %d has status =  %d, hasActivechildre = %d\n", */
/* 	     myParent, getXactionStatus(xc, myParent), hasActiveChildren(xc->t, myParent)); */
/*       current = myParent; */
/*       myParent = xc->t->parent[myParent];     */
/*     } */
/*     return current; */
/*   } */
/*   else { */
/*     return 0; */
/*   } */
/* } */






void collapseRangeBackward(xactionContext* xc, int id) {
  int mergedParent = backwardActiveChildrenQuery(xc, id);
  int temp;


  if (mergedParent != id) {
#ifdef DO_INV_CHECKS

    assert(mergedParent != id);
    assert(xc->t->isCommitted[id]);
    assert(xc->t->isCommitted[mergedParent]);
  
    assert((xc->t->pendingListPtr[mergedParent] == NULL_LIST) ||
	   (xc->t->lists[xc->t->pendingListPtr[mergedParent]].length == 0));

    assert((xc->t->failedListPtr[mergedParent] == NULL_LIST) ||
	   (xc->t->lists[xc->t->failedListPtr[mergedParent]].length == 0));

    assert(validDepTree(xc->t));
    assert(validDepTreeFreeList(xc->t));
#endif


    //    printf("Id is %d, mergedParent is %d\n", id, mergedParent);
    temp = mergedParent;

    // Scan through each of the transactions between mergedParent and id,
    //   get rid of their lists.
    while (temp != id) {
      //  outputDepTree(t);


      assert((xc->t->pendingListPtr[temp] == NULL_LIST) ||
	   (xc->t->lists[xc->t->pendingListPtr[temp]].length == 0));
      
      if (xc->t->pendingListPtr[temp] != NULL_LIST) {
	//    printf("Calling merge with id %d\n", id);
	//    outputDepTree(t);
	returnFreeDepIndex(xc->t, xc->t->pendingListPtr[temp]);
	xc->t->pendingListPtr[temp] = NULL_LIST;
      }

      assert((xc->t->failedListPtr[temp] == NULL_LIST) ||
	     (xc->t->lists[xc->t->failedListPtr[temp]].length == 0));

      if (xc->t->failedListPtr[temp] != NULL_LIST) {
	//    printf("Calling merge with id. failed ptrs this time %d\n", id);
	//    outputDepTree(t);

	returnFreeDepIndex(xc->t, xc->t->failedListPtr[temp]);
	xc->t->failedListPtr[temp] = NULL_LIST;
      }

      temp = xc->t->next[temp];
      xc->t->isCommitted[temp] = FALSE;
    }

    //  if (!validDepTree(t)) {
    //    printf("Error! not a valid dep tree here... \n");
    //    outputDepTree(t);
    //    assert(FALSE);
    //  }

    //  assert(validDepTreeFreeList(t));

    xc->t->next[mergedParent] = xc->t->next[id];

    if (xc->t->next[id] != NULL_ID) {
      // If there is a element after "id", set its prev. pointer to be "mergedParent"
      //      assert(xc->t->parent[id] == mergedParent);
      xc->t->parent[xc->t->next[id]] = mergedParent;
    }

    xc->t->pendingListPtr[mergedParent] = xc->t->pendingListPtr[id];
    if (xc->t->pendingListPtr[mergedParent] != NULL_LIST) {
      xc->t->lists[xc->t->pendingListPtr[mergedParent]].parent = mergedParent;
    }
    xc->t->pendingListPtr[id] = NULL_LIST;

    xc->t->failedListPtr[mergedParent] = xc->t->failedListPtr[id];
    if (xc->t->failedListPtr[mergedParent] != NULL_LIST) {
      xc->t->lists[xc->t->failedListPtr[mergedParent]].parent = mergedParent;
    }
    xc->t->failedListPtr[id] = NULL_LIST;

    xc->t->isCommitted[id] = FALSE;
    if (xc->t->lastCommitted == id) {
      xc->t->lastCommitted = mergedParent;
    }

#ifdef DO_INV_CHECKS
    assert(validDepTreeFreeList(xc->t));
    assert(validDepTree(xc->t));
#endif

  }
}


int lastCommittedXaction(xDepTree* t) {
  return t->lastCommitted;
}

/* int main(void) { */
/*   int i; */

/*   int n = 10; */
/*   xDepTree h; */
/*   xDepTree* t = &h; */
/*   initDepTree(t); */

  
/*   printf("Trying to check collapseRangeBackwards\n"); */

/*   for (i = 1; i < n; i++) { */
/*     addPending(t, i, 0); */
/*   }   */
/*   printf("Tree before commit\n"); */
/*   outputDepTree(t); */

/*   for (i = 1; i < n; i++) { */
/*     commitXaction(t, i); */
/*   } */
/*   printf("Tree after mass commit.\n"); */
/*   outputDepTree(t); */


/*   for (i = 1; i < n; i+=3) { */
/*     addPending(t, n+i, i); */
/*   } */

/*   printf("Tree after adding more pending stuff.\n"); */
/*   outputDepTree(t); */

/*   for (i = 0; i < n; i++) { */
/*     printf("Backward Query result for i = %d: %d\n", i, backwardActiveChildrenQuery(t, i)); */
/*   } */

/*   for (i = 0; i < n; i++) { */
/*     printf("Forward Query result for i = %d: %d\n", i, forwardActiveChildrenQuery(t, i)); */
/*   } */

/*   printf("About to collapse 7.\n"); */

/*   collapseRangeBackward(t, 7); */
/*   outputDepTree(t); */

/*   addPending(t, 1 + 2*n, 1); */
/*   failXaction(t, 1 + n); */

/*   printf("After adding pending and failing on 1.\n"); */
/*   outputDepTree(t); */



/*   collapseRangeBackward(t, 1); */
/*   printf("After collapsing 1.\n"); */
/*   outputDepTree(t); */

/*   printf("What will 4 collapse backward to?  %d\n", backwardActiveChildrenQuery(t, 4)); */
/*   collapseRangeBackward(t, 4); */
/*   printf("After collapsing 4.\n"); */
/*   outputDepTree(t); */
/*   //  checkValues(); */



  
/*   return 0; */
/* } */
