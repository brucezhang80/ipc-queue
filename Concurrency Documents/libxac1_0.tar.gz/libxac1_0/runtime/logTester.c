/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * logTester.c
 *
 */

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

#include <sys/time.h>
#include <unistd.h>

#include "logTester.h"


//#define LOG_TESTING_PRINT


void emptyLogTestPrint(FILE* file __attribute__((__unused__)), ...);
void emptyLogTestPrint(FILE* file __attribute__((__unused__)), ...) {

}


char emptyArray[PAGESIZE];

#ifdef ENTRY_COUNT_PRINT
#define E_COUNT_PRINT fprintf
#else
#define E_COUNT_PRINT emptyLogTestPrint
#endif


#ifdef LOG_TESTING_PRINT
#define LT_PRINT fprintf
#else
#define LT_PRINT emptyLogTestPrint
#endif




int generateLogEntry(void* buffer, int bufferLength, int myId) {
  
  int finalLength;
  int a;
  int b;
  int i;
  struct timeval t0;
  int numInts;
  int* intBuffer;


  // Structure of the test log entry: 
  //   1.  myId
  //   2.  a
  //   3.  b
  //   4.  numInts
  //    
  //       Ints we are writing
  //  
  //   5.  b
  //   6   a
  //   7.  myId
  //
  // Size of the buffer should be (7+numInts)*sizeof(int);

  gettimeofday(&t0, NULL);
  a = (int)t0.tv_usec + rand();
  b = (myId+1)*(int)t0.tv_sec;


  srand(a);
  numInts = 10+ (int)(1.0*(MAX_TEST_SIZE/sizeof(int))*rand()/(RAND_MAX+1.0));

  finalLength = (7+numInts)*sizeof(int);

  if (finalLength > bufferLength) {
    printf("ERROR!!! Buffer too small.\n");
    printf("Final length is %d\n", finalLength);
    assert(FALSE);
  }
  else {
    intBuffer = (int*)buffer;

    // Fill in the outside stuff
    intBuffer[0] = myId;
    intBuffer[1] = a;
    intBuffer[2] = b;
    intBuffer[3] = numInts;
    intBuffer[numInts+4] = b;
    intBuffer[numInts+5] = a;
    intBuffer[numInts+6] = myId;


    for (i = 0; i < numInts; i++) {
      intBuffer[i+4] = a*i+b;
    }
  }

  return finalLength;  
}



// Creates a bad log entry. :)
static int generateBadLogEntry(void* buffer, int bufferLength, int myId) {
  
  int finalLength;
  int a;
  int b;
  int i;
  struct timeval t0;
  int numInts;
  int* intBuffer;



  // Structure of the log
  //   1.  myId
  //   2.  a
  //   3.  b
  //   4.  numInts
  //   4.5  Ints we are writing
  //   5.  b
  //   6   a
  //   7.  myId

  // Size of the buffer should be (6+numInts)*sizeof(int);

  gettimeofday(&t0, NULL);
  a = (int)t0.tv_usec + rand();
  b = (myId+1)*(int)t0.tv_sec;


  srand(a);
  numInts = 10+ (int)(1.0*(MAX_TEST_SIZE/sizeof(int))*rand()/(RAND_MAX+1.0));

  finalLength = (7+numInts)*sizeof(int);

  if (finalLength > bufferLength) {
    printf("ERROR!!! Buffer too small.\n");
    printf("Final length is %d\n", finalLength);
    assert(FALSE);
  }
  else {
    intBuffer = (int*)buffer;

    // Fill in the outside stuff
    intBuffer[0] = myId;
    intBuffer[1] = a;
    intBuffer[2] = b;
    intBuffer[3] = numInts;
    intBuffer[numInts+4] = b;
    intBuffer[numInts+5] = a;
    intBuffer[numInts+6] = myId;


    for (i = 0; i < numInts; i++) {
      intBuffer[i+4] = b*i+a;
    }
  }

  return finalLength;  
}



//#define PRINT_LOGS_OUT 

static int checkLogEntry(int* array, int length, int a, int b) {
  int correct = TRUE;
  int i;
  assert(length >= 0) ;


#ifdef PRINT_LOGS_OUT
  LT_PRINT(stderr, "Log data: ");
#endif
  for (i = 0; i < length; i++) {
    if (a*i+b != array[i]) {
      LT_PRINT(stderr, "ERROR! At index i, ai+b = %d, but array says %d\n", a*i+b, array[i]);
      correct = FALSE;
    }
#ifdef PRINT_LOGS_OUT
    else {
      LT_PRINT(stderr, "%d, ", array[i]);
    }
#endif
  }


#ifdef PRINT_LOGS_OUT
  LT_PRINT(stderr, "\n");
#endif
  return correct;
}


static int myIdInRange(int myId) {

    return ((myId >= 0) && (myId <= MAX_XACTIONS));
}


static int isFsyncToken(int token) {
    return ((token == FSYNC_START_TOKEN) || (token == FSYNC_END_TOKEN));
}


static int checkForValidLogFileHelper(int fd) {


  off_t currentPosition;
  off_t fileLength;
  char nextEntry[2*MAX_TEST_SIZE + 10];
  int entryCount = 0;
  ssize_t bytesRead;

  int isValidFile = TRUE;
  int* iArrayPtr;
  int numFsyncTokens = 0;
  
  fileLength = lseek(fd, 0, SEEK_END);
  assert(fileLength > 0);


  lseek(fd, 0, SEEK_SET);

  iArrayPtr = (int*)nextEntry;
  
  currentPosition = 0;
  entryCount = 0;

  while (currentPosition < fileLength) {  
    LT_PRINT(stderr, "Reading in entry %d\n", entryCount);

    bytesRead = read(fd, nextEntry, sizeof(int));
    if (bytesRead != sizeof(int)) {

	LT_PRINT(stderr, "What is errno? %d\n", errno);
	perror("What's the error? \n");
      LT_PRINT(stderr, "What is current position? %zd.  What is fileLength? %zd\n",
	     currentPosition, fileLength);
      LT_PRINT(stderr, "How many bytes did we get? %zd\n",bytesRead);
    }
    assert(bytesRead == sizeof(int));
    currentPosition += bytesRead;

    
    if (!isFsyncToken(iArrayPtr[0]))  {
      int myId, a, b, numInts;
      int validEntry;
      bytesRead = read(fd,
		       ( void*) ((size_t)nextEntry + sizeof(int)),
		       3*sizeof(int));
      assert(bytesRead == 3*sizeof(int));
      currentPosition += bytesRead;

      myId = iArrayPtr[0];
      a = iArrayPtr[1];
      b = iArrayPtr[2];
      numInts = iArrayPtr[3];

      LT_PRINT(stderr, "Got entry myId == %d, a = %d, b = %d, numInts = %d\n",
	     myId,
	     a, 
	     b,
	     numInts);

      assert(iArrayPtr[3] > 0);
      
      bytesRead = read(fd,
		      (void*)((size_t)nextEntry + 4*sizeof(int)),
		      sizeof(int)* (numInts + 3));
      currentPosition += bytesRead;


      assert(iArrayPtr[4+numInts] == b);
      assert(iArrayPtr[5+numInts] == a);
      assert(iArrayPtr[6+numInts] == myId);

      assert(myIdInRange(myId));
      validEntry = checkLogEntry(iArrayPtr + 4, numInts, a, b);

      if (validEntry) {
	LT_PRINT(stderr, "Entry %d is correct. \n\n", entryCount);
      }
      else {
	LT_PRINT(stderr, "ERROR! entry %d is invalid. \n", entryCount);
	isValidFile = FALSE;
	assert(FALSE);
      }
      
    }
    else {
      LT_PRINT(stderr, "We got an fsync token here!! \n");
      assert(iArrayPtr[0] == FSYNC_START_TOKEN);
      bytesRead = 0;
      while (bytesRead == 0) {
	  bytesRead = read(fd, &nextEntry, sizeof(int));			   
      }
      currentPosition += bytesRead;

      if (iArrayPtr[0] == FSYNC_END_TOKEN) {
	  LT_PRINT(stderr, "We've got a matching fsync end token here!\n");
	  
      }
      assert(iArrayPtr[0] == FSYNC_END_TOKEN);
      
      numFsyncTokens++;
    }
    entryCount++;

    if (entryCount % 10000 == 0) {
	E_COUNT_PRINT(stderr, "Log Entry %d...\n", entryCount);
    }
  }


  printf("We observed %d fsync tokens.\n", numFsyncTokens);

  return isValidFile;
}




int checkForValidLogFile(const char* fileName)  {

  int fd, error;

  printf("Checking whether log file %s is a valid test log...\n",
	 fileName);
  fd = open(fileName, O_RDONLY, 0666);
  assert(fd != -1);
  assert(checkForValidLogFileHelper(fd));

  printf("We have a valid log file !!! \n");
  error = close(fd);

  assert(error == 0);

  return TRUE;
}


void generateValidLogFileTest(int n) {

  char fileName[] = "logTestFile.dat";
  char buffer[2*MAX_TEST_SIZE + 10];
  int fd;
  int i, error;
  int entryLength;
  ssize_t bytesWritten;
  int myFsyncStartToken = FSYNC_START_TOKEN;
  int myFsyncEndToken = FSYNC_END_TOKEN;

  fd = creat(fileName, 0666);
  assert(fd != -1);

  for (i = 0;  i < n; i++)  {
 
    entryLength = generateLogEntry(buffer, 2*MAX_TEST_SIZE, i % 10);


    assert(entryLength > 0);
    bytesWritten =0;

    while (bytesWritten == 0) {
      bytesWritten = write(fd, (void*)buffer, entryLength);
    }

    LT_PRINT(stderr, "Entry %d:  a = %d, b = %d\n",
	   i%(MAX_XACTIONS+1),
	   ((int*)buffer)[1],
	   ((int*)buffer)[2]);

    if (rand() % 5 == 0) {
	
      do {
	bytesWritten = write(fd, &myFsyncStartToken, sizeof(int));
      } while (bytesWritten == 0);
      do {
	bytesWritten = write(fd, &myFsyncEndToken, sizeof(int));
      } while (bytesWritten == 0);

    }
	   
  }

  error = close(fd);
  assert(error == 0);  
}

void generateInvalidLogFileTest(int n) {

  char fileName[] = "logTestFile.dat";
  char buffer[2*MAX_TEST_SIZE + 10];
  int fd;
  int i, error;
  int entryLength;
  ssize_t bytesWritten;

  fd = creat(fileName, 0666);
  assert(fd != -1);

  for (i = 0;  i < n; i++)  {
 
    entryLength = generateBadLogEntry(buffer, 2*MAX_TEST_SIZE, i % 10);


    assert(entryLength > 0);
    bytesWritten =0;

    while (bytesWritten == 0) {
      bytesWritten = write(fd, (void*)buffer, entryLength);
    }

    LT_PRINT(stderr, "Entry %d:  a = %d, b = %d\n",
	   i%10,
	   ((int*)buffer)[1],
	   ((int*)buffer)[2]);
	   
  }

  error = close(fd);
  assert(error == 0);  
}





/* int main(void) { */
/* //  char fileName[] = "logTestFile.dat"; */

/*   char fileName[] = "foo.data00020.log"; */
/*   //  generateValidLogFileTest(100); */
/*   //  generateInvalidLogFileTest(10); */
/*   printf("Going to verify %s now... \n", fileName); */
/*   checkForValidLogFile(fileName); */
/*   return 0; */
/* } */


