/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004-06    Massachusetts Institute of Technology
 * Copyright (c) 2004-06    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


/**
 * pageMap.h
 *
 *  This file contains functions that represent the interface between
 *  the high level control of Libxac and the functions that actually
 *  open/close files and change the memory map.
 *
 *  The split between high and low levels isn't perfect, and the
 *   design could probably be cleaned up a bit...
 *  See also logFileManager.h
 */

#ifndef __PAGE_MAP_H
#define __PAGE_MAP_H



#include "globalTypes.h"

#include "libxac_client_types.h"
#include "local_file_dir.h"

/**
 * This should be called once, when setting up the initial
 *   control file.
 * xc is the context object that contains pointers into
 *   the control file.
 */
void initializeMmapAndGLF(xactionContext* xc,
			  int isDurable,
			  const char* control_prefix);
/**
 * This function is called by each process, so that we can attach ourselves
 *  to file with the specified name.
 */
void attachMmapToFile(xactionContext* xc,
		      xaction_local_context* xlc,
		      const char* userFileName, int numPages);


// The corresponding detach function.
void detachMmapFromFile(xactionContext* xc,
			xaction_local_context* xlc,
			const char* userFileName);

void finalCleanupAttachForLogFiles(xactionContext* xc,
				   xaction_local_context* xlc,
				   const char* userFileName);

void finalCleanupDetachForLogFiles(xactionContext* xc,
				   xaction_local_context* xlc,
				   const char* userFileName);


/**
 * Changes the memory map so that the current transaction reads the
 *   sourceTrans's copy of the page..
 *
 * Postcondition:
 *  System has mmaped the correct page with protection PROT_READ
 *  Global lock is released if releaseLock flag is TRUE.
 *  Actual mmap call is done after releasing the lock.
 */
void readFrom(xactionContext* xc,
	      xaction_local_context* xlc,
	      int sourceTrans, int pageNumber, int releaseLock);


/**
 * Changes the memory map so that the current transaction makes new
 *  copies of the pages, (indexed starting at pageStart).
 *
 *  memoryRange is a pointer to the data we want to put in these new copies
 *
 * Postcondition:
 *  System has mapped these pages with PROT_READ | PROT_WRITE
 *  Actual mmap calls are done after releasing the lock.
 *
 * Note: Right now, we only really use this function when numPages == 1
 */
void createPageRangeCopy(xactionContext* xc,
			 xaction_local_context* xlc,
			 void* memoryRange,
			 int pageStart,
			 int numPages,
			 int releaseLock);



/**
 * This function copies the current transaction's version of the specified
 *   pages back to the original file (transaction id 0)
 *
 * Precondition:
 *  It must be safe to clobber the page in the original file.
 *
 * Note: Right now, we only really use this function when numPages == 1
 */
void replaceOriginalPageRange(xactionContext* xc,
			      xaction_local_context* xlc,
			      int someTrans, int pageStart, int numPages);


/**
 * This function transfers sourceTrans' disk page
 *   and changes the mmap data structure so that it is
 *   currentTransaction's disk page.
 *
 * currentTrans should not currently be mapping the
 *   transactional page to anything.
 *
 * Precondition:
 *   mmap(currentTrans, pageNumber) == UNMAPPED_PAGE
 *   mmap(sourceTrans, pageNumber) == d (some disk page)
 *
 * Postcondition:
 *   -  mmap(currentTrans, pageNumber) = d
 *   -  mmap(sourceTrans, pageNumber) = UNMAPPED_PAGE
 *   -  system mmap for current process is unchanged.
 *
 */
void transferTo(xactionContext* xc,
		int currentTrans, int sourceTrans, int pageNumber, int parentOwnedXaction);



/**
 * These functions changes the system memory map so
 *   the protection on the current transaction's page
 *   is PROT_NONE.
 * If pageStillUsed is FALSE, then we also unmap the page
 *   in our data structure.
 *
 * Precondition:
 *  -  mmap(currentTrans, pageNumber) == d (some disk page)
 *
 * Postcondition:
 *  -  system has changed process mmap for disk page d to PROT_NONE
 *  -  If isCommit is FALSE, then refCount(d)--, and
 *       mmap(currentTrans, pageNumber) = UNMAPPED_PAGE
 *
 * queuePageUnmap stores a page to be unmapped into the queue
 * processUnmapQueue actually goes through and calls unmap on all the
 *  pages in the queue.
 */
void queuePageUnmap(xactionContext* xc,
		    xaction_local_context* xlc,
		    int pageNumber, int isCommit, int isWrite);

void processUnmapQueue(xactionContext* xc,
		       xaction_local_context* xlc,
		       int isDurable);



void clearSourcePage(xactionContext* xc,
		     xaction_local_context* xlc,
		     int pageNumber);

void storePageDiff(xaction_local_context* xlc,
		   localCommitBuffer* lcbf, int page);

int storeTagToBuffer(xactionContext* xc,
		     localCommitBuffer* lcbf,
		     logPageType lpType,
		     int timeStamp,
		     unsigned long long myLSN);

int flushCommitDataToDisk(xactionContext* xc,
			  xaction_local_context* xlc);

#endif
