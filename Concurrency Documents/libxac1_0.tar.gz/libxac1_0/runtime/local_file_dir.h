/*************************************************************************
 *
 *  Libxac runtime system
 *
 *************************************************************************/
/*
 * Copyright (c) 2004    Massachusetts Institute of Technology
 * Copyright (c) 2004    Jim Sukha 
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * local_file_dir.h
 *
 */

#ifndef __LOCAL_FILE_DIR_H
#define __LOCAL_FILE_DIR_H

#include "file_defs.h"


typedef struct local_file_info {
  FILE_ID fid;
  char name[XFNAME_LENGTH];

  int fd;  // The file descriptor for the open file.
  void* addr;  // The address that the file is memory-mapped to.
  size_t current_length;  // The length of the memory map.  
} local_file_info;


// The file directory is simply a local array of files for now...
typedef struct local_file_directory {
  int num_files;
  local_file_info* farray;
  int farray_size;
  
} local_file_directory;


// Malloc's a local file directory and initializes it.
local_file_directory* create_local_file_directory(void);

// Free the local file directory structure.
void destroy_local_file_directory(local_file_directory* filedir);


// This function takes in the file information 
//  (from the main server), adds it to the directory,
//  opens the file on this process,
//   and memory-maps the region.
// Returns 0 if successful and -1 if error.
int open_user_file(local_file_directory* filedir,
		   global_file_info* finfo);


// Changes the memory-map of the file if necessary to
//  match the new length
// Returns 0 if successful and -1 if error.
//  (i.e., if that file is not in the directory)
int resize_user_file(local_file_directory* filedir,
		     global_file_info* finfo);


// Unmaps the user file, closes the file, and removes the
//  file from the local directory.
int close_user_file(local_file_directory* filedir,
		    global_file_info* finfo);

void print_local_file_directory(local_file_directory* filedir, int show_details);


// Test program for this module.
int local_file_dir_test_code(void);


#endif
